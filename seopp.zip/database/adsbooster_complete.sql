-- =====================================================================
-- ADSBOOSTER.NET — MASTER DATABASE SCHEMA & INITIAL SEED DATA
-- Version: 2.5 (Production Ready)
-- Dialect: MySQL 5.7+ / MySQL 8.0+ / MariaDB 10.3+
-- Engine: InnoDB | Character Set: utf8mb4 | Collation: utf8mb4_unicode_ci
-- Generated Date: 2026-09-25
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


-- -----------------------------------------------------
-- Table structure for `achievements`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `achievements`;
CREATE TABLE `achievements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `achievement_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_achievements_key` (`achievement_key`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `achievements`
INSERT INTO `achievements` (`id`, `achievement_key`, `title`, `description`, `icon`) VALUES
(1, 'first_campaign', 'First Campaign', 'Created your first ad campaign', 'campaign'),
(2, 'first_combo_pack', 'Combo Pack Pioneer', 'Launched your first combo pack campaign', 'combo'),
(3, 'ten_posts_scheduled', 'Content Machine', 'Scheduled 10 posts across platforms', 'calendar'),
(4, 'first_referral_reward', 'Social Butterfly', 'Earned your first referral reward', 'referral'),
(5, 'verified_seller', 'Trusted Seller', 'Became a verified seller on the marketplace', 'badge'),
(6, 'policy_scan_streak', 'Compliance Champion', 'Maintained a perfect policy scan streak', 'shield');


-- -----------------------------------------------------
-- Table structure for `ad_campaign_variants`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ad_campaign_variants`;
CREATE TABLE `ad_campaign_variants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaign_id` int NOT NULL,
  `variant_label` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `headline` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_text` text COLLATE utf8mb4_unicode_ci,
  `creative_media_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `traffic_split_pct` int DEFAULT '25',
  `is_winner` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_campaign_variants_campaign` (`campaign_id`),
  CONSTRAINT `fk_campaign_variants_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `ad_campaigns`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ad_campaigns`;
CREATE TABLE `ad_campaigns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `campaign_name` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_type` enum('meta','instagram','tiktok','google_ads','snapchat','combo_pack') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `objective` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `budget_type` enum('daily','lifetime') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `budget_amount` decimal(10,2) DEFAULT NULL,
  `targeting_spec` json DEFAULT NULL,
  `headline` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_text` text COLLATE utf8mb4_unicode_ci,
  `destination_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `creative_media_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','active','paused','completed','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `autopilot_enabled` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ad_campaigns_user` (`user_id`),
  KEY `idx_ad_campaigns_status` (`status`),
  KEY `idx_ad_campaigns_type` (`campaign_type`),
  KEY `idx_ad_campaigns_created` (`created_at`),
  CONSTRAINT `fk_ad_campaigns_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `agency_client_branding`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `agency_client_branding`;
CREATE TABLE `agency_client_branding` (
  `id` int NOT NULL AUTO_INCREMENT,
  `agency_user_id` int NOT NULL,
  `client_user_id` int NOT NULL,
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accent_color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT '#00FF00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_agency_branding_agency` (`agency_user_id`),
  KEY `idx_agency_branding_client` (`client_user_id`),
  CONSTRAINT `fk_agency_branding_agency` FOREIGN KEY (`agency_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_agency_branding_client` FOREIGN KEY (`client_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `ai_creatives`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ai_creatives`;
CREATE TABLE `ai_creatives` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` enum('text','image','video') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prompt` text COLLATE utf8mb4_unicode_ci,
  `result_output` text COLLATE utf8mb4_unicode_ci,
  `credits_used` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `metadata` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ai_creatives_user` (`user_id`),
  KEY `idx_ai_creatives_type` (`type`),
  CONSTRAINT `fk_ai_creatives_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `ai_creatives`
INSERT INTO `ai_creatives` (`id`, `user_id`, `type`, `prompt`, `result_output`, `credits_used`, `created_at`, `metadata`) VALUES
(1, 1, 'text', 'Create an ad headline for Adsbooster ad management', '**High‑Impact Headlines for Adsbooster Ad Management**\n\n1. **“Turn Clicks into Customers — Automate Your Ads with Adsbooster!”**  \n2. **“Scale Your ROI 3× Faster: Meet the Smartest Ad Manager on the Market.”**  \n3. **“One Platform, Unlimited Wins: Adsbooster’s AI‑Powered Ad Management.”**  \n4. **“Stop Guessing, Start Winning – Let Adsbooster Optimize Every Dollar.”**  \n5. **“From Chaos to Conversions: Automate, Optimize, Dominate with Adsbooster.”**  \n\n*Pick the one that resonates most with your audience, or mix‑and‑match elements to craft the perfect hook for your next campaign.*', 1, '2026-09-25 11:18:22', '{"provider": "groq", "timestamp": 1790335102}'),
(2, 1, 'video', 'UGC Video: Adsbooster Multi-Network Ad Platform (tiktok, viral_hook)', '{\n    "title": "One-Click Ad Empire",\n    "hook_headline": "Stop juggling ads\\u2014click once, dominate all!",\n    "audio_music_mood": "Energetic Lo-Fi Trap",\n    "scenes": [\n        {\n            "scene": 1,\n            "time": "0:00-0:03",\n            "type": "Hook",\n            "visual": "Gen\\u2011Z creator in a bright bedroom, phone in hand. Split\\u2011screen shows Meta, TikTok, Google icons swirling chaotically. Quick zoom\\u2011in on the creator\'s surprised face.",\n            "voiceover": "Ever feel like your ads are a mess?",\n            "overlay_text": "Ads chaos?",\n            "sfx": "whoosh + glitch"\n        },\n        {\n            "scene": 2,\n            "time": "0:03-0:10",\n            "type": "Agitation",\n            "visual": "Creator sighs, flips through multiple browser tabs with high cost numbers and flat sales graphs. Close\\u2011up on a ticking timer and a frustrated expression.",\n            "voiceover": "Spending hours, money, and still getting zero sales?",\n            "overlay_text": "Too many platforms. Too little results.",\n            "sfx": "timer tick + sigh"\n        },\n        {\n            "scene": 3,\n            "time": "0:10-0:20",\n            "type": "Demo\\/Solution",\n            "visual": "Creator taps the Adsbooster app. Animation merges Meta, TikTok, and Google logos into a single sleek dashboard. Sales graph rockets upward, confetti bursts.",\n            "voiceover": "Meet Adsbooster \\u2013 one click, all three giants work for you.",\n            "overlay_text": "Meta + TikTok + Google \\u2192 ONE CLICK",\n            "sfx": "magic chime + swoosh"\n        },\n        {\n            "scene": 4,\n            "time": "0:20-0:25",\n            "type": "Proof\\/Offer",\n            "visual": "Screen split: real\\u2011user testimonial with 3\\u00d7 ROAS badge, and creator holding phone showing a \\"Free 7\\u2011Day Trial\\" banner. Numbers flash: 3\\u00d7 ROAS, 40% time saved.",\n            "voiceover": "Real sellers see 3\\u00d7 ROAS in days. Try it free, no credit card needed.",\n            "overlay_text": "3\\u00d7 ROAS \\u2022 40% Time Saved \\u2022 7\\u2011Day Free",\n            "sfx": "pop"\n        },\n        {\n            "scene": 5,\n            "time": "0:25-0:30",\n            "type": "Call To Action",\n            "visual": "Creator points to a bold CTA button that appears on screen: \\"Start Free Trial\\". Background pulses with brand colors.",\n            "voiceover": "Tap the link, boost your store now!",\n            "overlay_text": "\\ud83d\\ude80 Start Your Free Trial",\n            "sfx": "click"\n        }\n    ],\n    "cta_text": "Start Free Trial",\n    "viral_hashtags": [\n        "#AdsBooster",\n        "#OneClickAds",\n        "#EcomGrowth",\n        "#GenZBiz"\n    ]\n}', 5, '2026-09-25 11:18:25', '{"provider": "groq (openai/gpt-oss-120b)", "timestamp": 1790335105}'),
(3, 3, 'text', 'tech post', '## 🚀 Tech‑Powered Growth: Why Adsbooster .NET Is the Automation Engine Your Marketing Stack Has Been Waiting For\n\n### TL;DR  \n**Adsbooster .NET** blends AI‑driven optimization, real‑time analytics, and a plug‑and‑play API to turn any ad campaign into a self‑learning growth machine. Deploy it in minutes, watch ROAS climb, and let the platform handle the heavy lifting.\n\n---\n\n## 1️⃣ The Architecture That Powers 10× Faster Scaling  \n\n| Layer | Tech Stack | What It Does for You |\n|-------|------------|----------------------|\n| **Data Ingestion** | **Kafka + AWS Kinesis** | Streams billions of impression events with sub‑millisecond latency. |\n| **Processing Engine** | **Apache Flink + Spark Structured Streaming** | Real‑time bid‑price adjustments, audience segmentation, and fraud detection. |\n| **AI‑Core** | **TensorFlow 2.x + PyTorch Lightning** | Multi‑armed bandit models, reinforcement‑learning (RL) agents, and predictive LTV scoring. |\n| **Storage** | **Snowflake + DynamoDB** | Scalable, columnar analytics for historic attribution; low‑latency key‑value lookups for bid‑time decisions. |\n| **API Layer** | **GraphQL + gRPC** | Unified endpoint for campaign creation, rule‑based automation, and custom webhook integrations. |\n| **UI/UX** | **React + Next.js (SSR)** | Drag‑and‑drop funnel builder, live heat‑maps, and instant A/B test results. |\n| **Security** | **OAuth 2.0 + JWT + AWS Shield** | End‑to‑end encryption, role‑based access, and DDoS protection. |\n\n> **Result:** 0.8 ms average bid‑response time, 99.99 % uptime, and a 30 % reduction in CPM across 5‑digit campaigns.\n\n---\n\n## 2️⃣ Core Features That Turn Data Into Dollars  \n\n| Feature | Technical Highlight | Business Impact |\n|---------|---------------------|-----------------|\n| **Dynamic Budget Allocation** | RL agents re‑balance spend across channels every 5 seconds. | ↑ 27 % ROAS, ↓ 15 % wasted spend. |\n| **Predictive Look‑Alike Modeling** | Graph embeddings + cosine similarity on 200M+ user profiles. | ↑ 3× qualified leads. |\n| **Cross‑Channel Attribution** | Multi‑touch Markov chain model with Bayesian smoothing. | Clear ROI per channel, better media mix decisions. |\n| **Auto‑Creative Optimization** | GAN‑generated ad variations, A/B tested in real‑time. | ↑ 12 % CTR, ↓ 8 % CPC. |\n| **Compliance Engine** | Real‑time GDPR/CCPA rule engine with automated consent tagging. | Zero compliance violations. |\n\n---\n\n## 3️⃣ How to Get Started in < 5 Minutes  \n\n```bash\n# 1️⃣ Install the SDK\npip install adsbooster-sdk\n\n# 2️⃣ Authenticate (OAuth2)\nexport ADSBOOSTER_TOKEN=$(adsbooster login --client-id $CLIENT_ID --client-secret $CLIENT_SECRET)\n\n# 3️⃣ Create a campaign (Python example)\nfrom adsbooster import Campaign\n\nmy_campaign = Campaign.create(\n    name="Spring Launch 🚀",\n    budget=5000,\n    objectives=["LEAD", "PURCHASE"],\n    channels=["facebook", "google", "tiktok"]\n)\n\n# 4️⃣ Attach a custom rule (e.g., pause if CPA > $12)\nmy_campaign.add_rule(\n    trigger="cpa_exceeds",\n    threshold=12,\n    action="pause"\n)\n\nprint(f"✅ Campaign {my_campaign.id} is live!")\n```\n\n> **Pro tip:** Pair the SDK with our **Webhooks Playground** to push conversion events directly into your CRM (HubSpot, Salesforce, Zoho) – zero code, zero latency.\n\n---\n\n## 4️⃣ Real‑World Success Stories  \n\n| Company | Spend | 30‑Day ROAS |', 1, '2026-09-25 12:14:00', '{"provider": "groq", "timestamp": 1790338440}'),
(4, 3, 'text', 'tech post', '# 🚀 “The Future of Ad Campaigns is Here—And It’s 100% Automated”  \n\n**Tech Post – Adsbooster.net**  \n\n---  \n\n## 1️⃣ Viral Hook (Social‑Media Ready)  \n\n> **“Stop spending hours on ad copy. Let AI write, test, and optimize for you—overnight.”**  \n\nUse this hook in a 15‑second TikTok or Instagram Reel. Pair it with a split‑screen: left side a tired marketer, right side a dashboard showing skyrocketing ROAS.\n\n---\n\n## 2️⃣ Headlines That Convert  \n\n| Platform | Headline | Sub‑Headline |\n|----------|----------|--------------|\n| **Facebook / LinkedIn** | *“Turn 1% Ad Spend into 15% ROAS in 30 days”* | *“Adsbooster’s AI‑driven automation does the heavy lifting.”* |\n| **Google Search** | *“Automated Ad Campaigns—No Manual Work Required”* | *“Sign up for a 14‑day free trial.”* |\n| **YouTube Shorts** | *“Watch AI Optimize Your Ads in Real Time”* | *“Your competitors are already using it.”* |\n| **Twitter** | *“What if your ads could run themselves? 🤖”* | *“Get started with Adsbooster in minutes.”* |\n\n*Tip:* A/B‑test each headline on the same audience to see which resonates most.\n\n---\n\n## 3️⃣ High‑Converting Ad Copy  \n\n### 3.1 Text Ad (Google Search)\n\n> **Headline 1:** Automate Your Ad Spend  \n> **Headline 2:** AI‑Optimized Campaigns  \n> **Headline 3:** 14‑Day Free Trial  \n> **Description:** “Cut manual workload by 80%. Increase ROAS by up to 20% with our AI‑driven ad automation. No technical skills required. Try it for free today.”  \n> **Path:** /automation  \n\n### 3.2 Carousel Ad (Facebook/Instagram)\n\n1. **Image 1** – Dashboard screenshot  \n   *Caption:* “See your campaigns in real time. No spreadsheet needed.”  \n2. **Image 2** – AI icon + “24/7 Optimization”  \n   *Caption:* “Our algorithms run 24/7, learning what works fastest.”  \n3. **Image 3** – Happy marketer + “+20% ROAS”  \n   *Caption:* “Clients report up to +20% ROAS in the first month.”  \n\n### 3.3 Video Script (30‑Sec)\n\n> **Scene 1 (0‑5 s):** Marketer staring at a cluttered spreadsheet.  \n> **Voice‑over:** “Still juggling ad budgets the old way?”  \n> **Scene 2 (5‑10 s):** Dashboard lights up with AI‑generated copy.  \n> **VO:** “Meet Adsbooster – the AI that writes, tests, and optimizes your ads.”  \n> **Scene 3 (10‑20 s):** Graph spikes upward.  \n> **VO:** “In just 30 days, our users see up to 20% higher ROAS.”  \n> **Scene 4 (20‑25 s):** Smiling marketer sipping coffee.  \n> **VO:** “Spend less time, earn more.”  \n> **Scene 5 (25‑30 s):** CTA overlay.  \n> **VO & Text:** “Start your free 14‑day trial now. Link in bio.”  \n\n---\n\n## 4️⃣ Call‑to‑Action (CTA) Variants  \n\n| Context | CTA Text | Rationale |\n|---------|----------|-----------|\n| **Landing Page** | *“Launch Your AI‑Powered Campaign Now”* | Direct, action‑oriented. |\n| **Email Signature** | *“See How AI Can Boost Your ROAS – Try Adsbooster Today”* | Curiosity‑driven. |\n| **Social Post** | *“Tap to Claim Your', 1, '2026-09-25 12:14:24', '{"provider": "groq", "timestamp": 1790338464}'),
(5, 3, 'video', 'UGC Video: mx web (meta, viral_hook)', '{\n    "title": "Gemini AI Magic",\n    "hook_headline": "Your website just got a brain!",\n    "audio_music_mood": "Upbeat Future Bass",\n    "scenes": [\n        {\n            "scene": 1,\n            "time": "0:00-0:03",\n            "type": "Hook",\n            "visual": "Gen Z creator (early 20s) sits at a desk, phone in hand. Close\\u2011up on a blank website screen. Their eyes widen, quick handheld zoom in. Quick jump\\u2011cut to their surprised expression.",\n            "voiceover": "Ever wish your site could think for you?",\n            "overlay_text": "\\ud83e\\udd2f Website = Brain?",\n            "sfx": "whoosh"\n        },\n        {\n            "scene": 2,\n            "time": "0:03-0:07",\n            "type": "Agitation",\n            "visual": "Creator scrolls through endless template thumbnails, sighs, rolls eyes. Camera pans over cluttered screen, showing confusion.",\n            "voiceover": "Scrolling endless templates, still stuck?",\n            "overlay_text": "Too many choices, zero results.",\n            "sfx": "scroll swipe, sigh"\n        },\n        {\n            "scene": 3,\n            "time": "0:07-0:12",\n            "type": "Demo\\/Solution",\n            "visual": "Creator taps a bright \\"Gemini AI\\" button on mx web. Split\\u2011screen: left side blank, right side transforms into a sleek, fully\\u2011filled website in seconds. Animated text bubbles appear as AI writes copy.",\n            "voiceover": "Meet mx web\\u2019s Gemini AI\\u2014type a vibe, get a site in seconds.",\n            "overlay_text": "Type. Click. Done.",\n            "sfx": "digital pop, AI beep"\n        },\n        {\n            "scene": 4,\n            "time": "0:12-0:14",\n            "type": "Proof\\/Offer",\n            "visual": "Stats flash: \\"3,000+ sites in 24h\\" and \\"98% satisfaction\\". Creator gives a thumbs\\u2011up, background shows other creators on laptops nodding.",\n            "voiceover": "Join 5K creators already leveling up.",\n            "overlay_text": "\\ud83d\\ude80 5K+ creators",\n            "sfx": "rising chime"\n        },\n        {\n            "scene": 5,\n            "time": "0:14-0:15",\n            "type": "Call To Action",\n            "visual": "Full\\u2011screen button pulses: \\"Try Gemini AI FREE\\". Creator points to the button, winks at camera.",\n            "voiceover": "Tap now, get a 7\\u2011day free trial!",\n            "overlay_text": "Tap & Go!",\n            "sfx": "click"\n        }\n    ],\n    "cta_text": "Start Free Trial",\n    "viral_hashtags": [\n        "#GeminiAI",\n        "#MxWebMagic",\n        "#NoCodeRevolution",\n        "#GenZCreators"\n    ]\n}', 5, '2026-09-25 13:48:25', '{"provider": "groq (openai/gpt-oss-120b)", "timestamp": 1790344105}'),
(6, 1, 'text', 'You are an expert HR and talent portfolio parser. Given a user\'s resume, extract and return a valid JSON object only with NO markdown fences, matching this structure:\n{\n  "display_name": "Full Name",\n  "job_title": "Primary Role or Professional Title",\n  "headline": "Impactful 1-sentence value proposition or bio headline",\n  "bio": "2-3 sentence engaging professional summary",\n  "phone": "Contact phone or empty",\n  "email": "Contact email or empty",\n  "location": "City/Country or Remote",\n  "skills": ["Skill 1", "Skill 2", "Skill 3", "Skill 4", "Skill 5"],\n  "services": [\n    {"title": "Service or Core Offering 1", "price": "$1,000/mo or project"},\n    {"title": "Service or Core Offering 2", "price": "$2,500/mo or project"}\n  ],\n  "portfolio_items": [\n    {"title": "Key Accomplishment or Project", "metric": "e.g. 4.2x ROAS or +$150k Revenue", "description": "Brief 1-sentence description"}\n  ]\n}\n\n=== USER RESUME CONTENT ===\nJohn Doe\nPerformance Media Buyer\n5 years experience running Meta & TikTok ads. Managed $2M ad spend at 3.5x ROAS.\nSkills: Meta Ads, TikTok Ads, Creative Strategy, Copywriting.\n\nReturn strictly valid JSON only:', '{\n  "display_name": "John Doe",\n  "job_title": "Performance Media Buyer",\n  "headline": "Performance Media Buyer delivering 3.5x ROAS on $2M ad spend",\n  "bio": "Seasoned performance marketer with 5 years of experience scaling Meta and TikTok campaigns. Expert at turning multimillion‑dollar budgets into high‑return revenue streams through data‑driven creative strategy and copywriting.",\n  "phone": "",\n  "email": "",\n  "location": "",\n  "skills": [\n    "Meta Ads",\n    "TikTok Ads",\n    "Creative Strategy",\n    "Copywriting",\n    "Data Analysis"\n  ],\n  "services": [\n    {\n      "title": "Meta Ads Campaign Management",\n      "price": "$1,200/mo"\n    },\n    {\n      "title": "TikTok Ads Optimization",\n      "price": "$1,000/mo"\n    }\n  ],\n  "portfolio_items": [\n    {\n      "title": "Managed $2M Ad Spend",\n      "metric": "3.5x ROAS",\n      "description": "Led multi‑platform campaigns that generated a 3.5x return on ad spend across Meta and TikTok."\n    }\n  ]\n}', 1, '2026-09-25 15:34:49', '{"provider": "groq", "timestamp": 1790350489}');


-- -----------------------------------------------------
-- Table structure for `api_keys`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `api_keys`;
CREATE TABLE `api_keys` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `key_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `key_prefix` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` json DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_api_keys_user` (`user_id`),
  KEY `idx_api_keys_hash` (`key_hash`),
  CONSTRAINT `fk_api_keys_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `api_keys`
INSERT INTO `api_keys` (`id`, `user_id`, `key_hash`, `key_prefix`, `scopes`, `last_used_at`, `created_at`) VALUES
(2, 3, '$2y$10$URCC4k2vWY9jAxPbSlDQYe.BYKy44muBgamZEAjEvVlLFtAM2UtWK', 'adsb_34864', '["read", "write", "billing"]', NULL, '2026-09-24 17:09:58'),
(3, 1, '7d43129894600935ee45a0b432553a8b338b612903028e7fb718ab587d1fde8f', 'adsb_testk', '["read", "write"]', '2026-09-24 16:50:33', '2026-09-24 17:49:03');


-- -----------------------------------------------------
-- Table structure for `api_rate_limits`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `api_rate_limits`;
CREATE TABLE `api_rate_limits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key_id` int NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `window_minute` int NOT NULL,
  `request_count` int NOT NULL DEFAULT '1',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_key_window` (`key_id`,`window_minute`),
  KEY `idx_window` (`window_minute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table structure for `audience_segments`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `audience_segments`;
CREATE TABLE `audience_segments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `criteria_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `criteria` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_audience_segments_user` (`user_id`),
  CONSTRAINT `fk_audience_segments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `blog_posts`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `blog_posts`;
CREATE TABLE `blog_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `body` longtext COLLATE utf8mb4_unicode_ci,
  `featured_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `author_id` int DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Advertising',
  `tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views_count` int DEFAULT '0',
  `is_featured` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_blog_posts_slug` (`slug`),
  KEY `idx_blog_posts_status` (`status`),
  KEY `idx_blog_posts_author` (`author_id`),
  CONSTRAINT `fk_blog_posts_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `blog_posts`
INSERT INTO `blog_posts` (`id`, `title`, `slug`, `excerpt`, `body`, `featured_image`, `author_id`, `published_at`, `status`, `created_at`, `updated_at`, `category`, `tags`, `views_count`, `is_featured`) VALUES
(1, 'How to Run Ads Across 5 Platforms From One Dashboard', 'run-ads-five-platforms-one-dashboard', 'Managing ad campaigns on Meta, Instagram, TikTok, Google Ads, and Snapchat used to require five different tools. Here is how Adsbooster unifies it all.', '<p>Running ads across multiple platforms has traditionally been a nightmare for marketers and business owners. You needed separate accounts, separate dashboards, and separate strategies for each platform.</p><p>Adsbooster changes that. With a single dashboard, you can create, launch, and manage campaigns across Meta, Instagram, TikTok, Google Ads, and Snapchat. The platform handles budget allocation, creative generation, and performance tracking across all networks simultaneously.</p><p>Whether you are a solo entrepreneur or an agency managing dozens of client accounts, the ability to centralize your advertising workflow saves hours every week and eliminates the risk of inconsistent messaging across platforms.</p>', 'assets/images/thumbs/project-img1.png', 1, '2026-09-01 10:00:00', 'published', '2026-09-16 17:41:50', '2026-09-16 17:41:50', 'Advertising', NULL, '0', '0'),
(2, 'AI-Powered Ad Creatives: Why They Outperform Manual Designs', 'ai-powered-ad-creatives-outperform', 'Artificial intelligence is transforming how ad creatives are generated. Learn why AI-created visuals and copy consistently outperform manual designs.', '<p>The days of spending hours tweaking ad creatives in Photoshop are numbered. AI-powered creative generation tools can now produce high-performing visuals and copy in seconds.</p><p>Studies show that AI-generated ad creatives achieve 20-40% higher click-through rates compared to manually designed alternatives. This is because AI models analyze millions of top-performing ads to understand what resonates with different audiences.</p><p>Adsbooster integrates AI creative generation directly into the campaign creation flow. When you launch a campaign, the platform automatically generates multiple creative variations and tests them to find the highest-performing combination.</p>', 'assets/images/thumbs/project-img2.png', 1, '2026-09-05 10:00:00', 'published', '2026-09-16 17:41:50', '2026-09-16 17:41:50', 'Advertising', NULL, '0', '0'),
(3, 'The Complete Guide to Social Media Scheduling in 2026', 'social-media-scheduling-guide-2026', 'Scheduling social media posts across multiple platforms is essential for consistency. Here is the definitive guide to doing it right.', '<p>Consistency is the backbone of social media success. Posting regularly across Instagram, TikTok, Meta, and other platforms keeps your audience engaged and your brand visible.</p><p>But manually posting to each platform is time-consuming and error-prone. A social media scheduling tool eliminates this friction by letting you plan, write, and schedule posts for multiple platforms from a single interface.</p><p>Adsbooster content calendar lets you drag and drop posts, set optimal posting times based on audience activity data, and auto-publish to all connected accounts. The result is a consistent presence without the daily grind.</p>', 'assets/images/thumbs/project-img3.png', 1, '2026-09-08 10:00:00', 'published', '2026-09-16 17:41:50', '2026-09-25 12:53:49', 'Advertising', NULL, 1, '0'),
(4, 'Meta Ads vs TikTok Ads: Which Platform Delivers Better ROI?', 'meta-ads-vs-tiktok-ads-roi', 'Choosing between Meta and TikTok for your ad spend can be tricky. We break down the strengths of each platform and when to use both.', '<p>Meta and TikTok are the two dominant social advertising platforms in 2026. Each has distinct strengths that make them suitable for different campaign objectives.</p><p>Meta excels at retargeting and conversion campaigns thanks to its mature pixel tracking and lookalike audience capabilities. TikTok, on the other hand, drives exceptional brand awareness and engagement through its algorithm-driven content discovery.</p><p>The smartest advertisers do not choose one over the other. They run complementary campaigns on both platforms, using Meta for bottom-funnel conversions and TikTok for top-funnel awareness. Adsbooster makes this dual-platform strategy effortless with its combo pack feature.</p>', 'assets/images/thumbs/project-img1.png', 1, '2026-09-10 10:00:00', 'published', '2026-09-16 17:41:50', '2026-09-25 12:54:06', 'Advertising', NULL, 2, '0'),
(5, '5 Signs Your Ad Campaign Needs a Performance Audit', 'ad-campaign-performance-audit-signs', 'Not sure if your campaigns are underperforming? These five warning signs indicate it is time for a thorough performance review.', '<p>Running ads is easy. Running ads profitably is hard. Many advertisers waste thousands of dollars on underperforming campaigns without realizing it.</p><p>Here are five signs your campaign needs attention: high impressions but low clicks, a cost-per-acquisition that exceeds your profit margin, declining performance over time, audience fatigue shown by falling engagement rates, and zero conversions despite significant spend.</p><p>Adsbooster Campaign Doctor automatically monitors your campaigns for these issues and generates actionable recommendations. It can pause underperforming ads, reallocate budgets to winners, and suggest targeting adjustments to improve your return on ad spend.</p>', 'assets/images/thumbs/project-img2.png', 1, '2026-09-12 10:00:00', 'published', '2026-09-16 17:41:50', '2026-09-25 12:12:59', 'Advertising', NULL, 1, '0'),
(6, 'How Agencies Scale Client Management With Multi-Network Tools', 'agencies-scale-client-management', 'Managing ads for multiple clients across multiple platforms requires the right tools. Here is how modern agencies scale without hiring more staff.', '<p>Advertising agencies face a unique challenge: managing dozens of client accounts across multiple ad platforms, each with its own interface, billing, and reporting.</p><p>The traditional approach requires dedicated account managers for each platform, leading to bloated teams and fragmented workflows. Multi-network advertising tools like Adsbooster solve this by providing a unified dashboard for all client campaigns.</p><p>With features like team collaboration, role-based access, white-label reporting, and automated campaign monitoring, agencies can scale their client base without proportionally scaling their headcount. The result is higher margins and better client satisfaction.</p>', 'assets/images/thumbs/project-img3.png', 1, '2026-09-15 10:00:00', 'published', '2026-09-16 17:41:50', '2026-09-25 12:53:22', 'Advertising', NULL, 4, '0');


-- -----------------------------------------------------
-- Table structure for `calendar_sync_events`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `calendar_sync_events`;
CREATE TABLE `calendar_sync_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `post_id` int DEFAULT NULL,
  `google_event_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_title` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `event_start` datetime DEFAULT NULL,
  `event_end` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_calendar_sync_user` (`user_id`),
  KEY `idx_calendar_sync_post` (`post_id`),
  CONSTRAINT `fk_calendar_sync_post` FOREIGN KEY (`post_id`) REFERENCES `scheduled_posts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_calendar_sync_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `campaign_metrics_daily`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `campaign_metrics_daily`;
CREATE TABLE `campaign_metrics_daily` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaign_id` int NOT NULL,
  `variant_id` int DEFAULT NULL,
  `date` date NOT NULL,
  `impressions` int DEFAULT '0',
  `clicks` int DEFAULT '0',
  `spend` decimal(10,2) DEFAULT '0.00',
  `conversions` int DEFAULT '0',
  `ctr` decimal(5,2) DEFAULT '0.00',
  `cpc` decimal(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_campaign_metrics` (`campaign_id`,`variant_id`,`date`),
  KEY `idx_campaign_metrics_date` (`date`),
  CONSTRAINT `fk_campaign_metrics_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `campaign_recommendations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `campaign_recommendations`;
CREATE TABLE `campaign_recommendations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaign_id` int NOT NULL,
  `recommendation_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `suggested_action` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','applied','dismissed','auto_applied') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_campaign_rec_campaign` (`campaign_id`),
  KEY `idx_campaign_rec_status` (`status`),
  CONSTRAINT `fk_campaign_rec_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `campaign_run_logs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `campaign_run_logs`;
CREATE TABLE `campaign_run_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaign_id` int NOT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_campaign_run_logs_campaign` (`campaign_id`),
  KEY `idx_campaign_run_logs_created` (`created_at`),
  CONSTRAINT `fk_campaign_run_logs_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `connected_accounts`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `connected_accounts`;
CREATE TABLE `connected_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token` text COLLATE utf8mb4_unicode_ci,
  `refresh_token` text COLLATE utf8mb4_unicode_ci,
  `token_expiry` datetime DEFAULT NULL,
  `platform_user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata_json` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_connected_accounts_user` (`user_id`),
  KEY `idx_connected_accounts_platform` (`platform`),
  CONSTRAINT `fk_connected_accounts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `connected_accounts`
INSERT INTO `connected_accounts` (`id`, `user_id`, `platform`, `access_token`, `refresh_token`, `token_expiry`, `platform_user_id`, `created_at`, `account_name`, `metadata_json`) VALUES
(16, 3, 'google_calendar', 'live_tok_4d50809fdd95b484a34fae0e7b628672', NULL, '2026-11-23 16:18:13', 'google_calendar_8f67fc2e71', '2026-09-24 17:18:13', 'Google Calendar Profile (fc2e71)', '{"connected_at":"2026-09-24 16:18:13","sync_status":"active","realtime":true}'),
(18, 3, 'meta', 'verified_handle_6438d989565c7f4db310dc69767e11e1', NULL, '2026-12-24 13:33:15', 'meta_5cbe4cda', '2026-09-25 14:33:15', 'Meta (Facebook) Profile', '{"connected_at":"2026-09-25 13:33:15","oauth_verified":true,"sync_status":"warning","token_type":"Bearer","latency_ms":833,"handle":"","last_synced_at":"2026-09-25 13:33:21","last_error":"Meta API error (HTTP 400): Invalid OAuth access token - Cannot parse access token"}');


-- -----------------------------------------------------
-- Table structure for `cookie_consents`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `cookie_consents`;
CREATE TABLE `cookie_consents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `consent_uuid` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `necessary` tinyint DEFAULT '1',
  `preferences` tinyint DEFAULT '0',
  `analytics` tinyint DEFAULT '0',
  `marketing` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cookie_consents_ip` (`ip`),
  KEY `idx_cookie_consents_uuid` (`consent_uuid`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `cron_run_logs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `cron_run_logs`;
CREATE TABLE `cron_run_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `job_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `status` enum('running','success','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'running',
  `notes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `idx_cron_logs_job` (`job_name`),
  KEY `idx_cron_logs_status` (`status`),
  KEY `idx_cron_logs_started` (`started_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `dating_blocks`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `dating_blocks`;
CREATE TABLE `dating_blocks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `blocker_id` int NOT NULL,
  `blocked_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dating_blocks` (`blocker_id`,`blocked_id`),
  KEY `idx_dating_blocks_blocked` (`blocked_id`),
  CONSTRAINT `fk_dating_blocks_blocked` FOREIGN KEY (`blocked_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dating_blocks_blocker` FOREIGN KEY (`blocker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `dating_pairs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `dating_pairs`;
CREATE TABLE `dating_pairs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `status` enum('pending','matched','rejected') DEFAULT 'pending',
  `icebreaker_message` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `matched_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pair_unique` (`sender_id`,`receiver_id`),
  KEY `idx_receiver` (`receiver_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `dating_pairs`
INSERT INTO `dating_pairs` (`id`, `sender_id`, `receiver_id`, `status`, `icebreaker_message`, `created_at`, `matched_at`) VALUES
(1, 3, 1, 'pending', '', '2026-09-24 20:19:13', NULL);


-- -----------------------------------------------------
-- Table structure for `dating_profiles`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `dating_profiles`;
CREATE TABLE `dating_profiles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `looking_for` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'everyone',
  `age` int DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `interests` text COLLATE utf8mb4_unicode_ci,
  `photo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_visible` tinyint DEFAULT '1',
  `is_photo_verified` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `photos_json` text COLLATE utf8mb4_unicode_ci,
  `occupation` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `relationship_goals` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified_match` tinyint DEFAULT '0',
  `photo` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_dating_profiles_user` (`user_id`),
  KEY `idx_dating_profiles_gender` (`gender`),
  KEY `idx_dating_profiles_looking` (`looking_for`),
  KEY `idx_dating_profiles_visible` (`is_visible`),
  KEY `idx_dating_profiles_city` (`city`),
  CONSTRAINT `fk_dating_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `dating_profiles`
INSERT INTO `dating_profiles` (`id`, `user_id`, `gender`, `looking_for`, `age`, `city`, `country`, `bio`, `interests`, `photo_url`, `is_visible`, `is_photo_verified`, `created_at`, `updated_at`, `photos_json`, `occupation`, `relationship_goals`, `verified_match`, `photo`) VALUES
(1, 1, 'male', 'everyone', 28, 'Test City', NULL, 'Test bio', NULL, 'uploads/dating/sample.jpg', 1, '0', '2026-09-24 17:45:23', '2026-09-24 18:45:23', NULL, NULL, NULL, '0', 'uploads/dating/sample.jpg');


-- -----------------------------------------------------
-- Table structure for `dating_verification_uploads`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `dating_verification_uploads`;
CREATE TABLE `dating_verification_uploads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `selfie_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_dating_verification_user` (`user_id`),
  KEY `idx_dating_verification_status` (`status`),
  CONSTRAINT `fk_dating_verification_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `dynamic_content`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `dynamic_content`;
CREATE TABLE `dynamic_content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `page_slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `section_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_value` text COLLATE utf8mb4_unicode_ci,
  `media_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dynamic_content` (`page_slug`,`section_key`,`item_key`),
  KEY `idx_dynamic_content_slug` (`page_slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `email_campaign_recipients`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `email_campaign_recipients`;
CREATE TABLE `email_campaign_recipients` (
  `id` int NOT NULL AUTO_INCREMENT,
  `campaign_id` int NOT NULL,
  `user_id` int NOT NULL,
  `opened` tinyint DEFAULT '0',
  `clicked` tinyint DEFAULT '0',
  `sent_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email_recipients_campaign` (`campaign_id`),
  KEY `idx_email_recipients_user` (`user_id`),
  CONSTRAINT `fk_email_recipients_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `email_campaigns` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_email_recipients_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `email_campaigns`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `email_campaigns`;
CREATE TABLE `email_campaigns` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int NOT NULL,
  `subject` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `status` enum('draft','sending','sent') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email_campaigns_admin` (`admin_id`),
  KEY `idx_email_campaigns_status` (`status`),
  CONSTRAINT `fk_email_campaigns_admin` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `email_logs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `email_logs`;
CREATE TABLE `email_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_id` int DEFAULT NULL,
  `recipient` varchar(255) DEFAULT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `body` text,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_email_logs_recipient` (`recipient`),
  KEY `idx_email_logs_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `email_logs`
INSERT INTO `email_logs` (`id`, `sender_id`, `recipient`, `subject`, `body`, `type`, `status`, `sent_at`) VALUES
(1, NULL, 'jmauricennadi@gmail.com', 'Payment Successful', NULL, 'branded', 'failed', '2026-09-22 21:32:37'),
(2, NULL, 'jotahecomng@gmail.com', 'Account Connected', NULL, 'branded', 'sent', '2026-09-24 15:13:02'),
(3, NULL, 'jotahecomng@gmail.com', 'Account Connected', NULL, 'branded', 'sent', '2026-09-24 15:15:59'),
(4, NULL, 'jotahecomng@gmail.com', 'Social Account Connected in Real-Time', NULL, 'branded', 'sent', '2026-09-24 16:17:48'),
(5, NULL, 'jotahecomng@gmail.com', 'Social Account Connected in Real-Time', NULL, 'branded', 'sent', '2026-09-24 16:18:14'),
(6, NULL, 'jotahecomng@gmail.com', 'OAuth Account Connected', NULL, 'branded', 'sent', '2026-09-24 17:30:59'),
(7, NULL, 'admin@adsbooster.net', 'New Message from Jamachi Mauricennadi on Adsbooster', '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class="email-container">\n  <div class="email-header">\n    <a href="https://adsbooster.net" class="email-brand">Adsbooster<span>.net</span></a>\n  </div>\n  <div class="email-body">\n    \n                    <h2>You Have a New Message 💬</h2>\n                    <p>Hi Admin User,</p>\n                    <p><b>Jamachi Mauricennadi</b> sent you a direct message on Adsbooster:</p>\n                    <div style="background:#080c14;border-left:3px solid #c8ff00;border-radius:6px;padding:16px 20px;margin:20px 0;font-style:italic;">\n                        "Thanks for the update!"\n                    </div>\n                    <div style="text-align:center;">\n                        <a href="https://adsbooster.net/p2p-chat.php?user=3" class="btn-action">Reply to Message &rarr;</a>\n                    </div>\n  </div>\n  <div class="email-footer">\n    <p style="margin:0 0 8px;">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style="margin:0;">Need assistance? Contact our team at <a href="mailto:support@adsbooster.net" style="color:#94a3b8;">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'p2p_message', 'sent', '2026-09-25 11:57:27'),
(8, NULL, 'jotahecomng@gmail.com', 'Your Adsbooster Security Verification Code: 817738', '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class="email-container">\n  <div class="email-header">\n    <a href="https://adsbooster.net" class="email-brand">Adsbooster<span>.net</span></a>\n  </div>\n  <div class="email-body">\n    \n                    <h2>Two-Factor Security Verification 🔒</h2>\n                    <p>Hi Jamachi Mauricennadi,</p>\n                    <p>Use the following 6-digit one-time code to complete your login or security confirmation:</p>\n                    <div class="code-box">817738</div>\n                    <p style="color:#94a3b8;font-size:13px;text-align:center;">This code expires in 10 minutes. If you did not attempt to sign in, please update your account password immediately.</p>\n  </div>\n  <div class="email-footer">\n    <p style="margin:0 0 8px;">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style="margin:0;">Need assistance? Contact our team at <a href="mailto:support@adsbooster.net" style="color:#94a3b8;">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'two_factor_code', 'sent', '2026-09-25 12:17:49'),
(9, NULL, 'jotahecomng@gmail.com', 'Your Adsbooster Security Verification Code: 501152', '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class="email-container">\n  <div class="email-header">\n    <a href="https://adsbooster.net" class="email-brand">Adsbooster<span>.net</span></a>\n  </div>\n  <div class="email-body">\n    \n                    <h2>Two-Factor Security Verification 🔒</h2>\n                    <p>Hi Jamachi Mauricennadi,</p>\n                    <p>Use the following 6-digit one-time code to complete your login or security confirmation:</p>\n                    <div class="code-box">501152</div>\n                    <p style="color:#94a3b8;font-size:13px;text-align:center;">This code expires in 10 minutes. If you did not attempt to sign in, please update your account password immediately.</p>\n  </div>\n  <div class="email-footer">\n    <p style="margin:0 0 8px;">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style="margin:0;">Need assistance? Contact our team at <a href="mailto:support@adsbooster.net" style="color:#94a3b8;">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'two_factor_code', 'sent', '2026-09-25 13:12:08'),
(10, NULL, 'jotahecomng@gmail.com', 'Social Account Connected', '<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1.0">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class="email-container">\n  <div class="email-header">\n    <a href="https://adsbooster.net" class="email-brand">Adsbooster<span>.net</span></a>\n  </div>\n  <div class="email-body">\n    <p>Hi Jamachi Mauricennadi,</p><p>Meta (Facebook) Profile was successfully verified and linked to your Meta (Facebook) publishing channel in real time.</p><p><a href="/social-connect.php">View in dashboard →</a></p>\n  </div>\n  <div class="email-footer">\n    <p style="margin:0 0 8px;">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style="margin:0;">Need assistance? Contact our team at <a href="mailto:support@adsbooster.net" style="color:#94a3b8;">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'branded', 'sent', '2026-09-25 13:33:15');


-- -----------------------------------------------------
-- Table structure for `fraud_flags`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `fraud_flags`;
CREATE TABLE `fraud_flags` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `flag_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `severity` enum('low','medium','high') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('flagged','reviewed','dismissed') COLLATE utf8mb4_unicode_ci DEFAULT 'flagged',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fraud_flags_user` (`user_id`),
  KEY `idx_fraud_flags_type` (`flag_type`),
  KEY `idx_fraud_flags_severity` (`severity`),
  KEY `idx_fraud_flags_status` (`status`),
  CONSTRAINT `fk_fraud_flags_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `invoices`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_id` int NOT NULL,
  `invoice_number` varchar(50) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `generated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_invoices_txn` (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table `invoices`
INSERT INTO `invoices` (`id`, `transaction_id`, `invoice_number`, `file_path`, `generated_at`) VALUES
(1, 3, 'INV-TESTVERIFY', 'uploads/invoices/INV-TESTVERIFY.html', '2026-09-22 21:28:29'),
(2, 4, 'INV-TESTVERIFY', 'uploads/invoices/INV-TESTVERIFY.html', '2026-09-22 21:29:39'),
(3, 5, 'INV-TESTVERIFY', 'uploads/invoices/INV-TESTVERIFY.html', '2026-09-22 21:32:37');


-- -----------------------------------------------------
-- Table structure for `jobs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Advertising',
  `job_type` enum('full-time','part-time','contract','freelance','bounty') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'contract',
  `location_type` enum('remote','hybrid','on-site') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'remote',
  `location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salary_min` decimal(12,2) DEFAULT NULL,
  `salary_max` decimal(12,2) DEFAULT NULL,
  `salary_currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `salary_period` enum('hourly','monthly','project','yearly') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'project',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `requirements` text COLLATE utf8mb4_unicode_ci,
  `skills_required` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('open','in_progress','completed','closed','paused') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `views_count` int NOT NULL DEFAULT '0',
  `applications_count` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `jobs`
INSERT INTO `jobs` (`id`, `user_id`, `title`, `slug`, `category`, `job_type`, `location_type`, `location`, `salary_min`, `salary_max`, `salary_currency`, `salary_period`, `description`, `requirements`, `skills_required`, `status`, `featured`, `views_count`, `applications_count`, `created_at`, `updated_at`) VALUES
(1, 1, 'Senior Meta & TikTok Media Buyer (Scaling D2C Brand from $50k to $200k/mo)', 'senior-meta-tiktok-media-buyer-scaling-d2c', 'Media Buying & Ads Scaling', 'contract', 'remote', 'Worldwide / US Timezones', 3000.00, 6000.00, 'USD', 'monthly', 'We are looking for an experienced Media Buyer to manage and scale our paid acquisition across Meta (Facebook/Instagram) and TikTok Ads.\n\nYour primary objective is maintaining a 3.2x+ blended ROAS while aggressively testing ad creative hooks, audience segments, and bid strategies.', '- At least 3 years verifiable experience in paid social media buying.\n- Experience managing accounts with >$30,000 monthly ad spend.\n- Deep understanding of creative testing frameworks and post-iOS14 attribution.', 'Meta Ads, TikTok Ads, ROAS Scaling, Creative Strategy, Triple Whale', 'open', 1, 52, 7, '2026-09-23 12:32:55', '2026-09-25 17:54:08'),
(2, 1, 'UGC Video Creator & Video Editor for TikTok/Reels ($150 per delivered video)', 'ugc-video-creator-editor-tiktok-reels', 'UGC Video & Reel Creation', 'bounty', 'remote', 'Remote', 150.00, 450.00, 'USD', 'project', 'Seeking charismatic, high-energy UGC creators to film and edit 30-45 second authentic vertical video ads for our fitness and wellness products.\n\nScript angles, storyboards, and sample products will be shipped directly to you.', '- Modern smartphone camera with 4K recording.\n- Crisp audio equipment (lavalier mic preferred).\n- Experience with dynamic text captions, fast cuts, and trending b-roll.', 'UGC Video, CapCut, TikTok Trends, On-Camera Talent, Premiere Pro', 'open', 1, 112, 14, '2026-09-24 12:32:55', '2026-09-25 13:32:55'),
(3, 1, 'Direct Response Ad Copywriter for Omnichannel Ad Campaigns', 'direct-response-ad-copywriter-omnichannel', 'Ad Copywriting & Scripts', 'freelance', 'remote', 'Remote', 1200.00, 2500.00, 'USD', 'monthly', 'Looking for a seasoned direct-response copywriter to write compelling ad angles, hook variations, primary text, and advertorial landing pages for our high-growth ecommerce brand.', '- Proven track record writing high-converting Facebook/Instagram ad copy.\n- Ability to rapidly brainstorm 20+ viral hook variations per campaign.\n- Excellent English writing skills with emotional trigger mastery.', 'Direct Response Copy, Hook Generation, Landing Page Copy, Meta Ad Copy', 'open', '0', 31, 5, '2026-09-22 12:32:55', '2026-09-25 13:32:55'),
(4, 1, 'B2B LinkedIn & Google Search Performance Specialist', 'b2b-linkedin-google-search-specialist', 'TikTok & Meta Optimization', 'contract', 'remote', 'US / UK Remote', 2000.00, 4000.00, 'USD', 'project', 'B2B SaaS platform seeking a Google Ads & LinkedIn Campaign Architect to audit existing search campaigns, restructure keyword intent match types, and implement lead form conversion ads.', '- Google Ads Certified with 3+ years managing B2B lead gen accounts.\n- Proven reduction in cost-per-qualified-lead (SQL).\n- LinkedIn Campaign Manager proficiency.', 'Google Ads, LinkedIn Ads, B2B Lead Gen, Tag Manager, Conversion Tracking', 'open', '0', 23, 3, '2026-09-21 12:32:55', '2026-09-25 13:40:26');


-- -----------------------------------------------------
-- Table structure for `jobs_services`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `jobs_services`;
CREATE TABLE `jobs_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('job','service','gig') COLLATE utf8mb4_unicode_ci DEFAULT 'job',
  `category` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget_type` enum('fixed','hourly','bounty') COLLATE utf8mb4_unicode_ci DEFAULT 'fixed',
  `budget_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `skills_required` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_type` enum('remote','onsite','hybrid') COLLATE utf8mb4_unicode_ci DEFAULT 'remote',
  `location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','paused','completed','closed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `views_count` int DEFAULT '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `user_id` (`user_id`),
  KEY `type` (`type`),
  KEY `category` (`category`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `jobs_services`
INSERT INTO `jobs_services` (`id`, `user_id`, `title`, `slug`, `type`, `category`, `budget_type`, `budget_amount`, `description`, `skills_required`, `location_type`, `location`, `contact_email`, `contact_phone`, `status`, `views_count`, `created_at`) VALUES
(1, 1, 'Senior Meta & TikTok Media Buyer for E-commerce DTC Brand', 'senior-meta-tiktok-media-buyer-dtc', 'job', 'Paid Media & Advertising', 'hourly', 65.00, 'Looking for an experienced performance marketer to manage $40k/month Meta and TikTok ad spend. Must be proficient in UGC creative testing, Pixel tracking, and ROAS scaling.', 'Meta Ads, TikTok Ads Manager, UGC Creatives, CBO, Retargeting', 'remote', 'Global / Remote', 'careers@adsbooster.net', '+1 (555) 392-1084', 'active', '0', '2026-09-20 11:47:54'),
(2, 1, 'Custom 9:16 UGC Video Creator & Short-Form Video Producer', 'custom-ugc-video-creator-short-form', 'service', 'Creative & Video Production', 'fixed', 350.00, 'I produce high-converting vertical UGC reels, hooks, and dynamic voiceover videos tailored for TikTok, Reels, and YouTube Shorts. Turnaround in 48 hours with 3 hook variations.', 'UGC Video, CapCut, TikTok Scripting, Hook Optimization, Lighting', 'remote', 'United States / Remote', 'creator@adsbooster.net', '+1 (555) 482-9921', 'active', '0', '2026-09-22 11:47:54'),
(3, 1, 'Google Search & Performance Max Campaign Audit & Rebuild', 'google-search-pmax-audit-rebuild', 'service', 'Search Engine Marketing', 'fixed', 750.00, 'Full account audit, negative keyword lists, conversion tracking verification, and PMax campaign segmentation designed to reduce wasted ad spend and lift conversion rate.', 'Google Ads, Performance Max, GA4, GTM, Conversion Tracking', 'remote', 'London, UK / Remote', 'audit@adsbooster.net', '+44 20 7946 0912', 'active', '0', '2026-09-24 11:47:54');


-- -----------------------------------------------------
-- Table structure for `marketplace_items`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `marketplace_items`;
CREATE TABLE `marketplace_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `item_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'product',
  `listing_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `featured_image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `seller_verified` tinyint DEFAULT '0',
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `featured` tinyint DEFAULT '0',
  `views_count` int DEFAULT '0',
  `rating` decimal(3,2) DEFAULT '0.00',
  `is_boosted` tinyint DEFAULT '0',
  `boost_expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `business_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_maps_url` text COLLATE utf8mb4_unicode_ci,
  `google_maps_embed` text COLLATE utf8mb4_unicode_ci,
  `contact_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'direct',
  `listing_fee` decimal(10,2) DEFAULT '0.00',
  `is_free_with_plan` tinyint DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_marketplace_items_slug` (`slug`),
  KEY `idx_marketplace_items_user` (`user_id`),
  KEY `idx_marketplace_items_type` (`item_type`),
  KEY `idx_marketplace_items_status` (`status`),
  KEY `idx_marketplace_items_category` (`category`),
  KEY `idx_marketplace_items_boosted` (`is_boosted`),
  CONSTRAINT `fk_marketplace_items_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `marketplace_items`
INSERT INTO `marketplace_items` (`id`, `user_id`, `item_type`, `listing_type`, `title`, `slug`, `category`, `price`, `featured_image`, `image_url`, `description`, `seller_verified`, `contact_email`, `website_url`, `status`, `featured`, `views_count`, `rating`, `is_boosted`, `boost_expires_at`, `created_at`, `updated_at`, `business_type`, `address`, `phone`, `whatsapp`, `google_maps_url`, `google_maps_embed`, `contact_method`, `listing_fee`, `is_free_with_plan`) VALUES
(1, 1, 'business', NULL, 'Apex Growth Media & Performance Advertising', 'apex-growth-media-performance-advertising', 'Marketing & Advertising', 299.00, 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=800&auto=format&fit=crop', NULL, 'Full-service omnichannel growth agency specializing in TikTok scaling, Meta ad optimization, and conversion landing pages.', 1, 'contact@apexgrowth.io', NULL, 'active', 1, 842, 4.95, 1, NULL, '2026-09-25 11:53:28', '2026-09-25 11:53:28', 'Agency', '742 Evergreen Terrace, Manhattan, NY', '+1 (555) 019-2831', +15550192831, 'https://maps.google.com/?q=Manhattan,NY', NULL, 'direct', '0.00', 1),
(2, 1, 'place', NULL, 'The Grand Horizon Luxury Suites & Resort', 'grand-horizon-luxury-suites-resort', 'Hotels & Hospitality', 180.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop', NULL, 'Five-star coastal suites featuring oceanview balconies, private infinity pool, executive conference rooms, and 24/7 concierge.', 1, 'reservations@grandhorizon.com', NULL, 'active', 1, 1250, 4.90, 1, NULL, '2026-09-25 11:53:28', '2026-09-25 11:53:28', 'Hotel', '120 Ocean Promenade, Miami Beach, FL', '+1 (555) 014-9922', +15550149922, 'https://maps.google.com/?q=Miami+Beach,FL', NULL, 'direct', '0.00', 1),
(3, 1, 'place', NULL, 'OmniCare Specialist Medical & Wellness Center', 'omnicare-specialist-medical-center', 'Hospitals & Healthcare', 75.00, 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&auto=format&fit=crop', NULL, 'Modern healthcare facility offering comprehensive diagnostics, cardiology, physiotherapy, and 24-hour emergency care.', 1, 'care@omnicareclinic.org', NULL, 'active', '0', 610, 4.85, '0', NULL, '2026-09-25 11:53:28', '2026-09-25 11:53:28', 'Hospital', '450 Health Parkway, Chicago, IL', '+1 (555) 017-4321', +15550174321, 'https://maps.google.com/?q=Chicago,IL', NULL, 'direct', '0.00', 1),
(4, 1, 'place', NULL, 'Grace Fellowship International Worship Center', 'grace-fellowship-international-church', 'Churches & Community', '0.00', 'https://images.unsplash.com/photo-1548625361-195fe579b183?w=800&auto=format&fit=crop', NULL, 'A vibrant faith community offering Sunday services, youth empowerment mentorship, and community food drives.', 1, 'welcome@gracefellowship.org', NULL, 'active', '0', 430, 5.00, '0', NULL, '2026-09-25 11:53:28', '2026-09-25 11:53:28', 'Church', '88 Cathedral Way, Dallas, TX', '+1 (555) 011-8844', +15550118844, 'https://maps.google.com/?q=Dallas,TX', NULL, 'direct', '0.00', 1),
(5, 1, 'place', NULL, 'La Trattoria Artisan Italian Dining', 'la-trattoria-artisan-italian-dining', 'Restaurants & Dining', 45.00, 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop', NULL, 'Authentic woodfired pizza, handmade pasta, and curated Mediterranean wines in an intimate, modern atmosphere.', 1, 'tables@latrattoria.com', NULL, 'active', 1, 980, 4.92, 1, NULL, '2026-09-25 11:53:28', '2026-09-25 11:53:28', 'Restaurant', '210 Little Italy Blvd, San Francisco, CA', '+1 (555) 013-7721', +15550137721, 'https://maps.google.com/?q=San+Francisco,CA', NULL, 'direct', '0.00', 1),
(6, 1, 'product', NULL, 'Adsbooster Omni-Channel AI Campaign Bundle', 'adsbooster-omni-channel-campaign-bundle', 'Software & Tools', 99.00, 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop', NULL, '50+ pre-tested viral ad frameworks, AI prompt templates for Groq/Gemini, and automated budget allocation rules.', 1, 'sales@adsbooster.net', NULL, 'active', 1, 1890, 4.98, 1, NULL, '2026-09-25 11:53:28', '2026-09-25 11:53:28', 'Product', 'Instant Digital Download', '+1 (555) 019-0011', +15550190011, '', NULL, 'direct', '0.00', 1);


-- -----------------------------------------------------
-- Table structure for `marketplace_reviews`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `marketplace_reviews`;
CREATE TABLE `marketplace_reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `reviewer_user_id` int NOT NULL,
  `rating` tinyint DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_marketplace_reviews_item` (`item_id`),
  KEY `idx_marketplace_reviews_reviewer` (`reviewer_user_id`),
  KEY `idx_marketplace_reviews_rating` (`rating`),
  CONSTRAINT `fk_marketplace_reviews_item` FOREIGN KEY (`item_id`) REFERENCES `marketplace_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_marketplace_reviews_reviewer` FOREIGN KEY (`reviewer_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_review_rating` CHECK ((`rating` between 1 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `notifications`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8mb4_unicode_ci,
  `link` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user` (`user_id`),
  KEY `idx_notifications_read` (`is_read`),
  KEY `idx_notifications_type` (`type`),
  KEY `idx_notifications_created` (`created_at`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `notifications`
INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `body`, `link`, `is_read`, `read_at`, `created_at`) VALUES
(4, 3, 'social_connected', 'Account Connected', 'Meta / Facebook has been connected successfully.', '/social-connect.php', 1, '2026-09-24 15:13:18', '2026-09-24 16:13:02'),
(5, 3, 'social_connected', 'Account Connected', 'Google Calendar has been connected successfully.', '/social-connect.php', 1, '2026-09-24 15:16:50', '2026-09-24 16:15:58'),
(6, 3, 'social_connected', 'Social Account Connected in Real-Time', 'Meta (Facebook) is now synced and ready for ad campaigns & scheduling.', '/social-connect.php', 1, '2026-09-24 16:23:04', '2026-09-24 17:17:47'),
(7, 3, 'social_connected', 'Social Account Connected in Real-Time', 'Google Calendar is now synced and ready for ad campaigns & scheduling.', '/social-connect.php', 1, '2026-09-24 16:23:04', '2026-09-24 17:18:13'),
(8, 3, 'social_connected', 'OAuth Account Connected', 'Meta was successfully authorized and connected via OAuth.', '/social-connect.php', 1, '2026-09-24 20:20:31', '2026-09-24 18:30:59'),
(9, 3, 'social_connected', 'Social Account Connected', 'Meta (Facebook) Profile was successfully verified and linked to your Meta (Facebook) publishing channel in real time.', '/social-connect.php', 1, '2026-09-25 13:47:18', '2026-09-25 14:33:15');


-- -----------------------------------------------------
-- Table structure for `p2p_conversations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `p2p_conversations`;
CREATE TABLE `p2p_conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_a` int NOT NULL,
  `user_b` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_a` (`user_a`),
  KEY `user_b` (`user_b`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `p2p_conversations`
INSERT INTO `p2p_conversations` (`id`, `user_a`, `user_b`, `created_at`, `updated_at`) VALUES
(1, 1, 3, '2026-09-24 17:33:59', '2026-09-24 18:33:59'),
(2, 3, 99999, '2026-09-25 11:56:16', '2026-09-25 12:56:16');


-- -----------------------------------------------------
-- Table structure for `p2p_deals`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `p2p_deals`;
CREATE TABLE `p2p_deals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversation_id` int DEFAULT NULL,
  `proposer_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `terms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('proposed','accepted','declined','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'proposed',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `proposer_id` (`proposer_id`),
  KEY `receiver_id` (`receiver_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `p2p_messages`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `p2p_messages`;
CREATE TABLE `p2p_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_id` int NOT NULL,
  `receiver_id` int DEFAULT NULL,
  `conversation_id` int DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `is_read` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_p2p_messages_sender` (`sender_id`),
  KEY `idx_p2p_messages_receiver` (`receiver_id`),
  KEY `idx_p2p_messages_read` (`is_read`),
  KEY `conversation_id` (`conversation_id`),
  CONSTRAINT `fk_p2p_messages_receiver` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_p2p_messages_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `p2p_messages`
INSERT INTO `p2p_messages` (`id`, `sender_id`, `receiver_id`, `conversation_id`, `message`, `is_read`, `created_at`) VALUES
(2, 3, 1, 1, 'Can you share more details?', '0', '2026-09-24 20:19:52'),
(3, 3, 1, 1, 'Thanks for the update!', '0', '2026-09-24 20:20:00'),
(4, 3, 1, 1, '❤️ Nice to meet you! Would love to connect and chat.', '0', '2026-09-24 20:20:07'),
(5, 3, 1, 1, '💼 I saw your marketplace listing and I\'m interested in discussing details.', '0', '2026-09-24 20:20:15'),
(6, 3, 1, 1, '👋 Hi there! Let\'s collaborate on Adsbooster.', '0', '2026-09-24 20:20:19'),
(7, 3, 99999, 2, 'How do I run a multi-platform ad campaign?', '0', '2026-09-25 11:56:16'),
(8, 99999, 3, 2, '**Running a Multi‑Platform Ad Campaign (Meta + TikTok + Google Ads) – Step‑by‑Step Playbook 🚀**\n\n---\n\n## 1️⃣ Define the Core Goal & KPI Stack\n| Goal | Primary KPI | Supporting Metrics |\n|------|------------|---------------------|\n| **Lead gen** | CPL (cost per lead) | Form completions, click‑through rate (CTR) |\n| **E‑commerce sales** | ROAS (return on ad spend) | AOV, add‑to‑cart, purchase‑conversion |\n| **App installs** | CPI (cost per install) | Daily active users (DAU), retention 7d |\n\n> **Action:** Write a one‑sentence campaign brief (e.g., “Drive 200 qualified B2B SaaS demo requests in 30 days at ≤ $45 CPL”).  \n\n---\n\n## 2️⃣ Audience Architecture – One Funnel, Three Platforms\n1. **Top‑of‑Funnel (Awareness)**\n   - Broad interest & look‑alike audiences.\n   - Creative: 15‑30 s video, eye‑catching hook.\n2. **Middle‑of‑Funnel (Consideration)**\n   - Retarget website visitors, video viewers (25‑75 % watched), email list.\n   - Creative: product demo, social proof, carousel.\n3. **Bottom‑of‑Funnel (Conversion)**\n   - High‑intent audiences: cart abandoners, past purchasers, lead‑form completers.\n   - Creative: limited‑time offer, UGC testimonial, direct CTA.\n\n> **Action:** Build the same audience “layers” in each ad manager (Meta Audiences, TikTok Audiences, Google Audiences) so you can compare performance apples‑to‑apples.\n\n---\n\n## 3️⃣ Creative Production Blueprint\n| Asset | Specs (Meta) | Specs (TikTok) | Specs (Google) |\n|-------|--------------|----------------|----------------|\n| **Video** | 4:5 or 1:1, ≤ 15 s (feed) | 9:16, ≤ 9 s (In‑Feed) | 16:9, ≤ 30 s (YouTube) |\n| **Image** | 1080×1080, < 30 KB | 1080×1920, < 30 KB | 1200×628 (Display) |\n| **Copy** | 125 char primary, 30 char headline | 80 char hook, 2‑line CTA | 30 char headline, 90 char description |\n| **CTA** | “Learn More”, “Get Quote” | “Shop Now”, “Sign Up” | “Buy”, “Install” |\n\n> **Action:** Shoot 3‑5 short clips (different hooks) → repurpose across platforms with platform‑specific cropping tools (e.g., Canva, Kapwing). Keep a master folder with raw files for quick edits.\n\n---\n\n## 4️⃣ Budget Allocation Framework\n1. **Test Phase (Week 1‑2) – 30 % total budget**  \n   - Even split across platforms (≈ 10 % each) to gather baseline data.  \n2. **Scale Phase (Week 3‑6) – 60 % total budget**  \n   - Shift budget to the two best‑performing platforms (based on CPA/CPL).  \n3. **Optimization/Retarget Phase', 1, '2026-09-25 11:56:21'),
(9, 3, 1, 1, 'Thanks for the update!', '0', '2026-09-25 11:57:26');


-- -----------------------------------------------------
-- Table structure for `payout_requests`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `payout_requests`;
CREATE TABLE `payout_requests` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(50) NOT NULL,
  `details_json` text NOT NULL,
  `status` enum('pending','approved','paid','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table structure for `policy_rules`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `policy_rules`;
CREATE TABLE `policy_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rule_type` enum('text','image','url') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pattern` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `severity` enum('low','medium','high','critical') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_policy_rules_platform` (`platform`),
  KEY `idx_policy_rules_type` (`rule_type`),
  KEY `idx_policy_rules_severity` (`severity`),
  KEY `idx_policy_rules_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `policy_scan_logs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `policy_scan_logs`;
CREATE TABLE `policy_scan_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `campaign_id` int DEFAULT NULL,
  `post_id` int DEFAULT NULL,
  `compliance_score` int DEFAULT NULL,
  `issues_json` json DEFAULT NULL,
  `scanned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_policy_scan_user` (`user_id`),
  KEY `idx_policy_scan_campaign` (`campaign_id`),
  KEY `idx_policy_scan_post` (`post_id`),
  KEY `idx_policy_scan_score` (`compliance_score`),
  CONSTRAINT `fk_policy_scan_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_policy_scan_post` FOREIGN KEY (`post_id`) REFERENCES `scheduled_posts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_policy_scan_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `post_metrics_daily`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `post_metrics_daily`;
CREATE TABLE `post_metrics_daily` (
  `id` int NOT NULL AUTO_INCREMENT,
  `post_id` int NOT NULL,
  `date` date NOT NULL,
  `reach` int DEFAULT '0',
  `likes` int DEFAULT '0',
  `comments` int DEFAULT '0',
  `shares` int DEFAULT '0',
  `saves` int DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_post_metrics` (`post_id`,`date`),
  KEY `idx_post_metrics_date` (`date`),
  CONSTRAINT `fk_post_metrics_post` FOREIGN KEY (`post_id`) REFERENCES `scheduled_posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `pricing_plan_currency_overrides`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `pricing_plan_currency_overrides`;
CREATE TABLE `pricing_plan_currency_overrides` (
  `id` int NOT NULL AUTO_INCREMENT,
  `plan_id` int NOT NULL,
  `currency_code` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_plan_currency_plan` (`plan_id`),
  KEY `idx_plan_currency_code` (`currency_code`),
  CONSTRAINT `fk_plan_currency_plan` FOREIGN KEY (`plan_id`) REFERENCES `pricing_plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `pricing_plans`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `pricing_plans`;
CREATE TABLE `pricing_plans` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) DEFAULT NULL,
  `ad_credits_included` decimal(10,2) DEFAULT '0.00',
  `ai_credits_included` int DEFAULT '0',
  `duration` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_cycle` enum('monthly','yearly','pay_as_you_go') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `features_json` json DEFAULT NULL,
  `is_featured` tinyint DEFAULT '0',
  `sort_order` int DEFAULT '0',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pricing_plans_status` (`status`),
  KEY `idx_pricing_plans_cycle` (`billing_cycle`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `pricing_plans`
INSERT INTO `pricing_plans` (`id`, `name`, `description`, `price`, `ad_credits_included`, `ai_credits_included`, `duration`, `billing_cycle`, `features_json`, `is_featured`, `sort_order`, `status`, `created_at`) VALUES
(1, 'Starter Booster', 'Ideal for small businesses launching campaigns across key ad networks.', 29.00, 30.00, 150, 'month', 'monthly', '["Meta, Instagram & Google Ads support", "$30.00 Monthly Ad Credits Included", "150 AI Copy & Script Credits", "10 Scheduled Social Posts", "Basic Campaign Analytics", "Standard Email Support"]', '0', 1, 'active', '2026-09-24 16:37:26'),
(2, 'Growth Pro', 'Complete multi-network automation, combo packs, and AI campaign doctor.', 79.00, 95.00, 500, 'month', 'monthly', '["All 5 Networks + All-in-One Combo Pack", "$95.00 Monthly Ad Credits (+$16 Bonus!)", "500 AI UGC Video & Image Credits", "Unlimited Scheduled Posts", "A/B Creative Split Testing", "Lookalike Audience Suggestions", "Priority 24/7 Support"]', 1, 2, 'active', '2026-09-24 16:37:26'),
(3, 'Agency Scaling', 'Full white-label agency sub-accounts, webhook APIs, and auto-pilot optimization.', 199.00, 260.00, 1500, 'month', 'monthly', '["Everything in Growth Pro", "$260.00 Monthly Ad Credits (+$61 Bonus!)", "1,500 AI Generation Credits", "White-label Client Workspaces", "Full REST API & Webhooks Access", "AI Campaign Doctor Auto-Pilot", "Auto-Refill Wallet Protection", "Dedicated Account Manager"]', '0', 3, 'active', '2026-09-24 16:37:26'),
(4, 'Enterprise Omnichannel', 'Custom high-volume enterprise advertising and bespoke integration SLAs.', 499.00, 700.00, 5000, 'month', 'monthly', '["Bespoke High-Volume Infrastructure", "$700.00 Monthly Ad Credits (+$201 Bonus!)", "5,000 AI Credits", "Unlimited Team Members & Sub-accounts", "Custom Ad Policy Pre-Flight Rules", "Direct Slack / WhatsApp Support Bridge", "99.9% Uptime SLA Agreement"]', '0', 4, 'active', '2026-09-24 16:37:26');


-- -----------------------------------------------------
-- Table structure for `referrals`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `referrals`;
CREATE TABLE `referrals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `referrer_id` int NOT NULL,
  `referred_id` int NOT NULL,
  `status` enum('pending','rewarded') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `reward_credits` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_referrals_referrer` (`referrer_id`),
  KEY `idx_referrals_referred` (`referred_id`),
  KEY `idx_referrals_status` (`status`),
  CONSTRAINT `fk_referrals_referred` FOREIGN KEY (`referred_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_referrals_referrer` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `scheduled_posts`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `scheduled_posts`;
CREATE TABLE `scheduled_posts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `platform` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_type` enum('manual','ai_generated') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `caption` text COLLATE utf8mb4_unicode_ci,
  `media_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `media_type` enum('image','ugc_video','reel','text_only','document','pdf') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduled_time` datetime DEFAULT NULL,
  `google_calendar_event_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('scheduled','published','failed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'scheduled',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_scheduled_posts_user` (`user_id`),
  KEY `idx_scheduled_posts_status` (`status`),
  KEY `idx_scheduled_posts_time` (`scheduled_time`),
  CONSTRAINT `fk_scheduled_posts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `scheduled_posts`
INSERT INTO `scheduled_posts` (`id`, `user_id`, `platform`, `post_type`, `caption`, `media_url`, `media_type`, `scheduled_time`, `google_calendar_event_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 3, 'meta', 'ai_generated', '<p>me</p>', NULL, 'image', '2026-09-25 12:00:00', NULL, 'cancelled', '2026-09-24 16:16:16', '2026-09-24 16:23:16');


-- -----------------------------------------------------
-- Table structure for `site_reviews`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `site_reviews`;
CREATE TABLE `site_reviews` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `rating` tinyint NOT NULL DEFAULT '5',
  `review_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `review_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `plan_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'pro',
  `user_role` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Verified Advertiser',
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'approved',
  `is_featured` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `status` (`status`),
  KEY `is_featured` (`is_featured`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `site_reviews`
INSERT INTO `site_reviews` (`id`, `user_id`, `rating`, `review_title`, `review_text`, `plan_type`, `user_role`, `status`, `is_featured`, `created_at`) VALUES
(1, 1, 5, 'Scaled our TikTok & Meta ROAS to 4.2x in 3 Weeks', 'The AI UGC Video Studio combined with direct ad launches has saved our agency dozens of hours every month. The real-time pacing alerts prevented thousands in ad waste.', 'pro', 'Verified Advertiser', 'approved', 1, '2026-09-13 11:47:54'),
(2, 1, 5, 'The Verified Business Directory delivers high-ticket leads daily', 'Having our digital marketing agency listed in the Adsbooster Verified Directory with direct WhatsApp integration generated 14 qualified client inquiries in our first fortnight.', 'enterprise', 'Verified Advertiser', 'approved', 1, '2026-09-18 11:47:54'),
(3, 1, 5, 'Game changer for solo growth marketers & creators', 'Creating multi-scene reels with the smartphone simulator, then queuing straight to Instagram and TikTok without third-party scheduling tools is extraordinary.', 'pro', 'Verified Advertiser', 'approved', 1, '2026-09-23 11:47:54');


-- -----------------------------------------------------
-- Table structure for `site_settings`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `site_settings`;
CREATE TABLE `site_settings` (
  `setting_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_unicode_ci,
  `setting_group` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'general',
  PRIMARY KEY (`setting_key`),
  KEY `idx_site_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `site_settings`
INSERT INTO `site_settings` (`setting_key`, `setting_value`, `setting_group`) VALUES
('auto_refill_reward_credits', 10, 'referrals'),
('consent_mode_default', 'denied', 'privacy'),
('contact_address', 'New York, NY 10002, United States', 'general'),
('contact_email', 'support@adsbooster.net', 'general'),
('contact_phone', '+1 (555) 123-4567', 'general'),
('currency_symbol', '$', 'general'),
('firecrawl_api_key', '', 'general'),
('flutterwave_live_key', 'FLWSECK_LIVE-XXXXXXXXXXXXXXXXXXXX', 'payment'),
('flutterwave_test_key', 'FLWSECK_TEST-XXXXXXXXXXXXXXXXXXXX', 'payment'),
('gemini_api_key', '', 'general'),
('google_client_id', 'YOUR_GOOGLE_CLIENT_ID', 'integrations'),
('google_client_secret', 'YOUR_GOOGLE_CLIENT_SECRET', 'integrations'),
('groq_api_key', '', 'general'),
('openrouter_api_key', '', 'general'),
('paystack_live_key', 'sk_live_XXXXXXXXXXXXXXXXXXXXXXX', 'payment'),
('paystack_test_key', 'sk_test_XXXXXXXXXXXXXXXXXXXXXXX', 'payment'),
('policy_compliance_threshold', 70, 'policies'),
('referral_reward_amount', 50, 'referrals'),
('site_address', 'New York, NY 10002, United States', 'general'),
('site_email', 'support@adsbooster.net', 'general'),
('site_favicon', '/assets/images/logo/favicon.png', 'general'),
('site_logo', '/assets/images/logo/logo-green.png', 'general'),
('site_name', 'Adsbooster.net', 'general'),
('site_phone', '+1 (555) 123-4567', 'general'),
('site_slogan', 'Multi-Network AI Advertising Platform', 'general'),
('social_facebook', 'https://facebook.com/adsbooster', 'social'),
('social_instagram', 'https://instagram.com/adsbooster', 'social'),
('social_linkedin', 'https://linkedin.com/company/adsbooster', 'social'),
('social_twitter', 'https://twitter.com/adsbooster', 'social');


-- -----------------------------------------------------
-- Table structure for `support_tickets`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `support_tickets`;
CREATE TABLE `support_tickets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `ticket_type` enum('support','bug_report','billing') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') COLLATE utf8mb4_unicode_ci DEFAULT 'medium',
  `subject` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('open','in_progress','resolved','closed') COLLATE utf8mb4_unicode_ci DEFAULT 'open',
  `report_target_user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_support_tickets_user` (`user_id`),
  KEY `idx_support_tickets_status` (`status`),
  KEY `idx_support_tickets_type` (`ticket_type`),
  KEY `idx_support_tickets_priority` (`priority`),
  KEY `idx_support_tickets_report_target` (`report_target_user_id`),
  CONSTRAINT `fk_support_tickets_report_target` FOREIGN KEY (`report_target_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_support_tickets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `team_invitations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `team_invitations`;
CREATE TABLE `team_invitations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `owner_id` int NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('admin','editor','viewer') COLLATE utf8mb4_unicode_ci DEFAULT 'viewer',
  `invite_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','accepted','expired') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_team_invitations_token` (`invite_token`),
  KEY `idx_team_invitations_owner` (`owner_id`),
  KEY `idx_team_invitations_email` (`email`),
  KEY `idx_team_invitations_status` (`status`),
  CONSTRAINT `fk_team_invitations_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `team_members`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `team_members`;
CREATE TABLE `team_members` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_user_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('admin','editor','viewer') COLLATE utf8mb4_unicode_ci DEFAULT 'viewer',
  `invite_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invited_at` datetime DEFAULT NULL,
  `status` enum('active','pending','removed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `parent_user_id` (`parent_user_id`),
  KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `ticket_messages`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ticket_messages`;
CREATE TABLE `ticket_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ticket_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `attachment_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ticket_messages_ticket` (`ticket_id`),
  KEY `idx_ticket_messages_sender` (`sender_id`),
  CONSTRAINT `fk_ticket_messages_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ticket_messages_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `tickets`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `tickets`;
;


-- -----------------------------------------------------
-- Table structure for `transactions`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `gateway` enum('paystack','flutterwave') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('plan_subscription','ad_credit_topup','ai_credit_topup') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `status` enum('pending','successful','failed','refunded') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `invoice_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_transactions_invoice` (`invoice_number`),
  KEY `idx_transactions_user` (`user_id`),
  KEY `idx_transactions_status` (`status`),
  KEY `idx_transactions_gateway` (`gateway`),
  KEY `idx_transactions_created` (`created_at`),
  CONSTRAINT `fk_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `transactions`
INSERT INTO `transactions` (`id`, `user_id`, `gateway`, `type`, `amount`, `currency`, `status`, `invoice_number`, `invoice_path`, `gateway_reference`, `reference`, `metadata`, `created_at`, `updated_at`) VALUES
(1, 2, 'flutterwave', 'ad_credit_topup', 5.00, 'USD', 'failed', 'INV-20260922-744DEF', NULL, '23650EDF397640F28CEBA620', '23650EDF397640F28CEBA620', '{"email": "jmauricennadi@gmail.com"}', '2026-09-22 16:40:01', '2026-09-22 16:40:01'),
(6, 2, 'flutterwave', 'ad_credit_topup', 5.00, 'USD', 'failed', 'INV-20260922-ED427B', NULL, 'D4879830074DF529286E69E4', 'D4879830074DF529286E69E4', '{"email": "jmauricennadi@gmail.com"}', '2026-09-22 21:34:33', '2026-09-22 21:34:33'),
(7, 2, 'flutterwave', 'ai_credit_topup', 5.00, 'USD', 'failed', 'INV-20260922-5C8DBE', NULL, '6E3AD583B74933D676FB6DC8', '6E3AD583B74933D676FB6DC8', '{"email": "jmauricennadi@gmail.com"}', '2026-09-22 21:34:43', '2026-09-22 21:34:43'),
(8, 2, 'paystack', 'ad_credit_topup', 5.00, 'USD', 'failed', 'INV-20260923-C253CD', NULL, '5276B988EC79BB9EDB4D6C3D', '5276B988EC79BB9EDB4D6C3D', '{"email": "jmauricennadi@gmail.com"}', '2026-09-23 15:41:01', '2026-09-23 15:41:01'),
(9, 3, 'flutterwave', 'ad_credit_topup', 100.00, 'USD', 'failed', 'INV-20260923-E8A2A5', NULL, '1AB010D38974CDC01A613736', '1AB010D38974CDC01A613736', '{"email": "jotahecomng@gmail.com"}', '2026-09-23 16:08:32', '2026-09-23 16:08:32'),
(10, 3, 'flutterwave', 'ad_credit_topup', 100.00, 'USD', 'failed', 'INV-20260924-2FBBE0', NULL, 'BB6DFD9BE20FC0BBECDA5E33', 'BB6DFD9BE20FC0BBECDA5E33', '{"email": "jotahecomng@gmail.com"}', '2026-09-24 14:55:17', '2026-09-24 14:55:17'),
(11, 3, 'flutterwave', 'ai_credit_topup', 50.00, 'USD', 'failed', 'INV-20260924-DB3A06', NULL, '6D97127AB29A6B87FEEB9332', '6D97127AB29A6B87FEEB9332', '{"email": "jotahecomng@gmail.com"}', '2026-09-24 15:21:20', '2026-09-24 15:21:20'),
(12, 3, 'paystack', 'ad_credit_topup', 100.00, 'USD', 'failed', 'INV-20260924-B571C1', NULL, '4F3100F2C84D821721CA6F03', '4F3100F2C84D821721CA6F03', '{"email": "jotahecomng@gmail.com"}', '2026-09-24 15:21:26', '2026-09-24 15:21:26'),
(13, 3, 'paystack', 'ai_credit_topup', 5.00, 'USD', 'failed', 'INV-20260924-74BD75', NULL, 'CBB46F46EB790F6ED810E738', 'CBB46F46EB790F6ED810E738', '{"email": "jotahecomng@gmail.com"}', '2026-09-24 15:21:30', '2026-09-24 15:21:30'),
(14, 3, 'paystack', 'plan_subscription', 29.00, 'USD', 'failed', 'INV-20260924-6ACD4C', NULL, 'EF5CE783239371E2EBC1A2D7', 'EF5CE783239371E2EBC1A2D7', '{"email": "jotahecomng@gmail.com", "plan_id": 1, "plan_name": "Starter Booster"}', '2026-09-24 16:08:00', '2026-09-24 16:08:00'),
(15, 3, 'flutterwave', 'plan_subscription', 29.00, 'USD', 'failed', 'INV-20260924-B6A8AB', NULL, 'ECFEB932E42602A08C0A01C1', 'ECFEB932E42602A08C0A01C1', '{"email": "jotahecomng@gmail.com", "plan_id": 1, "plan_name": "Starter Booster"}', '2026-09-24 16:08:08', '2026-09-24 16:08:08');


-- -----------------------------------------------------
-- Table structure for `translations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `translations`;
CREATE TABLE `translations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `locale` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `translation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_translations` (`locale`,`translation_key`),
  KEY `idx_translations_locale` (`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `user_achievements`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `user_achievements`;
CREATE TABLE `user_achievements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `achievement_id` int NOT NULL,
  `earned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_achievements_user` (`user_id`),
  KEY `idx_user_achievements_achievement` (`achievement_id`),
  CONSTRAINT `fk_user_achievements_achievement` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_achievements_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `user_deals`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `user_deals`;
CREATE TABLE `user_deals` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversation_id` int NOT NULL,
  `proposer_id` int NOT NULL,
  `recipient_id` int NOT NULL,
  `deal_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deal_scope` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'USD',
  `delivery_days` int DEFAULT '3',
  `status` enum('pending','accepted','declined','completed','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `conversation_id` (`conversation_id`),
  KEY `proposer_id` (`proposer_id`),
  KEY `recipient_id` (`recipient_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `user_follows`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `user_follows`;
CREATE TABLE `user_follows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `follower_id` int NOT NULL,
  `following_id` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_follow` (`follower_id`,`following_id`),
  KEY `follower_id` (`follower_id`),
  KEY `following_id` (`following_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `user_portfolios`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `user_portfolios`;
CREATE TABLE `user_portfolios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `headline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `template_style` enum('dark_luxury','creative_neon','executive_minimal') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'dark_luxury',
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skills_json` text COLLATE utf8mb4_unicode_ci,
  `services_json` text COLLATE utf8mb4_unicode_ci,
  `portfolio_items_json` mediumtext COLLATE utf8mb4_unicode_ci,
  `social_links_json` text COLLATE utf8mb4_unicode_ci,
  `resume_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views_count` int NOT NULL DEFAULT '0',
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `username_2` (`username`),
  KEY `is_public` (`is_public`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `user_recommendations`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `user_recommendations`;
CREATE TABLE `user_recommendations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `recommender_id` int NOT NULL,
  `target_user_id` int NOT NULL,
  `relationship` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT 'Colleague / Client',
  `recommendation_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` tinyint DEFAULT '5',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `recommender_id` (`recommender_id`),
  KEY `target_user_id` (`target_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `user_reports`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `user_reports`;
CREATE TABLE `user_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reporter_id` int NOT NULL,
  `reported_user_id` int NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','reviewed','dismissed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reporter_id` (`reporter_id`),
  KEY `reported_user_id` (`reported_user_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `user_vcards`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `user_vcards`;
CREATE TABLE `user_vcards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `headline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `template` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'cyber_dark',
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `github` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skills_json` json DEFAULT NULL,
  `projects_json` json DEFAULT NULL,
  `experiences_json` json DEFAULT NULL,
  `resume_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views_count` int DEFAULT '0',
  `is_public` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `username_2` (`username`),
  KEY `is_public` (`is_public`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `user_vcards`
INSERT INTO `user_vcards` (`id`, `user_id`, `username`, `headline`, `bio`, `template`, `phone`, `whatsapp`, `company`, `job_title`, `location`, `website`, `linkedin`, `twitter`, `github`, `instagram`, `skills_json`, `projects_json`, `experiences_json`, `resume_file`, `views_count`, `is_public`, `created_at`, `updated_at`) VALUES
(1, 3, 'jamachimauricennadi', '', '', 'cyber_dark', '+1 (555) 019-2834', +15550192834, '', '', '', 'https://adsbooster.net', NULL, NULL, NULL, NULL, '["Meta Ads", "TikTok Media Buying", "ROAS Scaling", "UGC Creative", "Copywriting"]', '[{"link": "https://adsbooster.net", "title": "DTC Fashion Brand Scale", "metric": "4.2x ROAS", "description": "Scaled monthly ad spend from $10k to $120k at 4.2x blended ROAS."}]', '[{"role": "Senior Media Buyer", "period": "2023 - Present", "company": "Growth Agency", "summary": "Directing omnichannel Meta and TikTok ad budgets for fast-growing brands."}]', NULL, '0', 1, '2026-09-25 11:57:33', '2026-09-25 12:01:56');


-- -----------------------------------------------------
-- Table structure for `users`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `headline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('user','team_member','admin') COLLATE utf8mb4_unicode_ci DEFAULT 'user',
  `parent_user_id` int DEFAULT NULL,
  `account_type` enum('individual','agency_owner','agency_client') COLLATE utf8mb4_unicode_ci DEFAULT 'individual',
  `ad_credits` decimal(10,2) DEFAULT '0.00',
  `ai_credits` int DEFAULT '0',
  `ai_preferred_provider` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `billing_cycle` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_expiry` date DEFAULT NULL,
  `onboarding_completed` tinyint DEFAULT '0',
  `status` enum('active','suspended','pending') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `is_verified_seller` tinyint DEFAULT '0',
  `referral_code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referred_by` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_refill_enabled` tinyint DEFAULT '0',
  `auto_refill_threshold` decimal(10,2) DEFAULT '0.00',
  `auto_refill_amount` decimal(10,2) DEFAULT '0.00',
  `auto_refill_gateway` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totp_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `totp_enabled` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `two_factor_enabled` tinyint DEFAULT '0',
  `two_factor_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_type` enum('totp','email','both') COLLATE utf8mb4_unicode_ci DEFAULT 'both',
  `two_factor_backup` text COLLATE utf8mb4_unicode_ci,
  `two_factor_setup_at` datetime DEFAULT NULL,
  `email_2fa_code` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_2fa_expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_referral` (`referral_code`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_parent` (`parent_user_id`),
  KEY `idx_users_plan` (`plan_id`),
  CONSTRAINT `fk_users_parent` FOREIGN KEY (`parent_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_users_plan` FOREIGN KEY (`plan_id`) REFERENCES `pricing_plans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=100000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table `users`
INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `company`, `headline`, `bio`, `password`, `google_id`, `avatar`, `role`, `parent_user_id`, `account_type`, `ad_credits`, `ai_credits`, `ai_preferred_provider`, `plan_id`, `billing_cycle`, `plan_expiry`, `onboarding_completed`, `status`, `is_verified_seller`, `referral_code`, `referred_by`, `auto_refill_enabled`, `auto_refill_threshold`, `auto_refill_amount`, `auto_refill_gateway`, `totp_secret`, `totp_enabled`, `created_at`, `updated_at`, `two_factor_enabled`, `two_factor_secret`, `two_factor_type`, `two_factor_backup`, `two_factor_setup_at`, `email_2fa_code`, `email_2fa_expires_at`) VALUES
(1, 'Admin User', 'admin@adsbooster.net', NULL, NULL, NULL, NULL, '$2y$12$irEt/SvnQZ0W/omxTowevOXehKEWMNucp6PLa0O6MY9H0krgg/cPC', NULL, NULL, 'admin', NULL, 'individual', '0.00', 93, NULL, NULL, NULL, NULL, '0', 'active', '0', '72F27CFC', NULL, '0', '0.00', '0.00', NULL, NULL, '0', '2026-09-16 15:17:16', '2026-09-25 16:34:45', '0', NULL, 'both', NULL, NULL, NULL, NULL),
(2, 'Jamachi Maurice Mauricennadi', 'jmauricennadi@gmail.com', NULL, NULL, NULL, NULL, '$2y$10$ukmrC0oa4oms5wOGH0910e86X4GoSSjZJfzj.m91YZ8JYwYv5Guxy', NULL, NULL, 'user', NULL, 'individual', '0.00', '0', NULL, NULL, NULL, NULL, 1, 'active', '0', '0e076164998d42e9', NULL, '0', '0.00', '0.00', NULL, NULL, '0', '2026-09-16 18:09:42', '2026-09-22 22:32:37', '0', NULL, 'both', NULL, NULL, NULL, NULL),
(3, 'Jamachi Mauricennadi', 'jotahecomng@gmail.com', NULL, NULL, NULL, NULL, '$2y$10$j48dM8evVXJhPQASJrQaxe7YlVN3Yxjij8wzVTwWtfssJjVKDDqsi', NULL, NULL, 'user', NULL, 'individual', '0.00', 93, 'groq', NULL, NULL, NULL, 1, 'active', '0', '0010a2bccc34c1f4', NULL, '0', '0.00', '0.00', NULL, NULL, '0', '2026-09-23 17:06:11', '2026-09-25 14:48:22', '0', NULL, 'both', NULL, NULL, NULL, NULL),
(4, 'Adsbooster AI Growth Assistant', 'ai.assistant@adsbooster.net', NULL, NULL, NULL, NULL, '$2y$12$g.gFN7Ugrq0pF5z1DxJ2ZOyCe8GRDa./jaRwpvIPosjZHogfgh.j6', NULL, NULL, 'admin', NULL, 'individual', '0.00', '0', NULL, NULL, NULL, NULL, '0', 'active', '0', NULL, NULL, '0', '0.00', '0.00', NULL, NULL, '0', '2026-09-24 18:01:34', '2026-09-24 19:01:34', '0', NULL, 'both', NULL, NULL, NULL, NULL),
(99999, 'Adsbooster AI Consultant', 'ai@adsbooster.net', NULL, NULL, NULL, NULL, 'ai_bot_protected', NULL, NULL, 'admin', NULL, 'individual', '0.00', '0', NULL, NULL, NULL, NULL, '0', 'active', '0', NULL, NULL, '0', '0.00', '0.00', NULL, NULL, '0', '2026-09-25 12:56:09', '2026-09-25 12:56:09', '0', NULL, 'both', NULL, NULL, NULL, NULL);


-- -----------------------------------------------------
-- Table structure for `visitor_logs`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `visitor_logs`;
CREATE TABLE `visitor_logs` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `browser` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` enum('desktop','mobile') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_uri` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_visitor_logs_user` (`user_id`),
  KEY `idx_visitor_logs_ip` (`ip`),
  KEY `idx_visitor_logs_created` (`created_at`),
  CONSTRAINT `fk_visitor_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -----------------------------------------------------
-- Table structure for `webhooks`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `webhooks`;
CREATE TABLE `webhooks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `event_type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_webhooks_user` (`user_id`),
  KEY `idx_webhooks_event` (`event_type`),
  KEY `idx_webhooks_active` (`is_active`),
  CONSTRAINT `fk_webhooks_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
-- =====================================================================
-- End of Master Dump for Adsbooster.net
-- =====================================================================
