-- Adsbooster migration 2026-10: live multi-network ad dispatch
-- Widens transactions.gateway / transactions.type so wallet-funded ad
-- campaign launches can be recorded (previously MySQL strict mode rejected
-- the insert with "Data truncated for column 'gateway'" and the launch
-- rolled back entirely).
-- Safe to re-run; run on any database created before 2026-10-18.

ALTER TABLE `transactions`
    MODIFY `gateway` ENUM('paystack','flutterwave','wallet','internal') COLLATE utf8mb4_unicode_ci DEFAULT NULL;

ALTER TABLE `transactions`
    MODIFY `type` ENUM('plan_subscription','ad_credit_topup','ai_credit_topup','ad_campaign_fee','referral_reward','payout') COLLATE utf8mb4_unicode_ci DEFAULT NULL;
