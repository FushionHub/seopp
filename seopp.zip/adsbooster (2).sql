-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 18, 2026 at 07:35 PM
-- Server version: 8.4.3
-- PHP Version: 8.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES latin1 */;

--
-- Database: `adsbooster`
--

-- --------------------------------------------------------

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
CREATE TABLE `achievements` (
  `id` int NOT NULL,
  `achievement_key` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `title` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `description` text COLLATE latin1_swedish_ci,
  `icon` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `achievements`
--

INSERT INTO `achievements` (`id`, `achievement_key`, `title`, `description`, `icon`) VALUES
(1, 'first_campaign', 'First Campaign', 'Created your first ad campaign', 'campaign'),
(2, 'first_combo_pack', 'Combo Pack Pioneer', 'Launched your first combo pack campaign', 'combo'),
(3, 'ten_posts_scheduled', 'Content Machine', 'Scheduled 10 posts across platforms', 'calendar'),
(4, 'first_referral_reward', 'Social Butterfly', 'Earned your first referral reward', 'referral'),
(5, 'verified_seller', 'Trusted Seller', 'Became a verified seller on the marketplace', 'badge'),
(6, 'policy_scan_streak', 'Compliance Champion', 'Maintained a perfect policy scan streak', 'shield');

-- --------------------------------------------------------

--
-- Table structure for table `ad_campaigns`
--

DROP TABLE IF EXISTS `ad_campaigns`;
CREATE TABLE `ad_campaigns` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `campaign_name` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `campaign_type` enum('meta','instagram','tiktok','google_ads','snapchat','combo_pack') COLLATE latin1_swedish_ci DEFAULT NULL,
  `objective` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `budget_type` enum('daily','lifetime') COLLATE latin1_swedish_ci DEFAULT NULL,
  `budget_amount` decimal(10,2) DEFAULT NULL,
  `targeting_spec` json DEFAULT NULL,
  `headline` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `primary_text` text COLLATE latin1_swedish_ci,
  `destination_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `creative_media_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('pending','active','paused','completed','rejected') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `autopilot_enabled` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ad_campaign_variants`
--

DROP TABLE IF EXISTS `ad_campaign_variants`;
CREATE TABLE `ad_campaign_variants` (
  `id` int NOT NULL,
  `campaign_id` int NOT NULL,
  `variant_label` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `headline` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `primary_text` text COLLATE latin1_swedish_ci,
  `creative_media_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `traffic_split_pct` int DEFAULT '25',
  `is_winner` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `agency_client_accounts`
--

DROP TABLE IF EXISTS `agency_client_accounts`;
CREATE TABLE `agency_client_accounts` (
  `id` int NOT NULL,
  `agency_user_id` int NOT NULL,
  `client_user_id` int DEFAULT NULL,
  `client_name` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `client_email` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `client_company` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `monthly_retainer` decimal(10,2) DEFAULT '0.00',
  `currency` varchar(10) COLLATE latin1_swedish_ci DEFAULT 'USD',
  `access_token` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `status` enum('active','paused','pending') COLLATE latin1_swedish_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `agency_client_accounts`
--

INSERT INTO `agency_client_accounts` (`id`, `agency_user_id`, `client_user_id`, `client_name`, `client_email`, `client_company`, `monthly_retainer`, `currency`, `access_token`, `status`, `created_at`) VALUES
(1, 2, NULL, 'Jamachi Mauricennadi', 'jmauricennadi@gmail.com', 'CEO, CTO & FOUNDER', 2000.00, 'USD', 'client_b1d7fc10572fe5b64efb3e991bd69a00', 'active', '2026-10-05 17:13:13');

-- --------------------------------------------------------

--
-- Table structure for table `agency_client_approvals`
--

DROP TABLE IF EXISTS `agency_client_approvals`;
CREATE TABLE `agency_client_approvals` (
  `id` int NOT NULL,
  `agency_user_id` int NOT NULL,
  `client_account_id` int NOT NULL,
  `item_type` enum('ad_campaign','social_post','ugc_video','report') COLLATE latin1_swedish_ci NOT NULL,
  `item_id` int DEFAULT NULL,
  `title` varchar(500) COLLATE latin1_swedish_ci NOT NULL,
  `preview_data` json DEFAULT NULL,
  `approval_status` enum('pending','approved','rejected_revision') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `client_feedback` text COLLATE latin1_swedish_ci,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `agency_client_branding`
--

DROP TABLE IF EXISTS `agency_client_branding`;
CREATE TABLE `agency_client_branding` (
  `id` int NOT NULL,
  `agency_user_id` int NOT NULL,
  `client_user_id` int NOT NULL,
  `logo_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `accent_color` varchar(7) COLLATE latin1_swedish_ci DEFAULT '#00FF00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `agency_portals`
--

DROP TABLE IF EXISTS `agency_portals`;
CREATE TABLE `agency_portals` (
  `id` int NOT NULL,
  `agency_user_id` int NOT NULL,
  `custom_subdomain` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `custom_domain` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `portal_name` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `portal_logo_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `brand_primary_color` varchar(20) COLLATE latin1_swedish_ci DEFAULT '#c8ff00',
  `brand_secondary_color` varchar(20) COLLATE latin1_swedish_ci DEFAULT '#080c14',
  `welcome_headline` varchar(255) COLLATE latin1_swedish_ci DEFAULT 'Welcome to Your Client Growth Portal',
  `is_whitelabel_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `agency_portals`
--

INSERT INTO `agency_portals` (`id`, `agency_user_id`, `custom_subdomain`, `custom_domain`, `portal_name`, `portal_logo_url`, `brand_primary_color`, `brand_secondary_color`, `welcome_headline`, `is_whitelabel_active`, `created_at`) VALUES
(1, 2, 'jmn', NULL, 'Jamachi Maurice Mauricennadi Marketing Agency', 'assets/images/logo/logo.png', '#c8ff00', '#080c14', 'Welcome to Your Client Growth & ROI Dashboard', 1, '2026-10-05 17:12:55'),
(2, 1, 'agency-1', NULL, 'Admin User Marketing Agency', 'assets/images/logo/logo.png', '#c8ff00', '#080c14', 'Welcome to Your Client Growth & ROI Dashboard', 1, '2026-10-05 17:51:56'),
(3, 100000, 'agency-100000', NULL, 'E2E Tester Marketing Agency', 'assets/images/logo/logo.png', '#c8ff00', '#080c14', 'Welcome to Your Client Growth & ROI Dashboard', 1, '2026-10-12 20:37:21');

-- --------------------------------------------------------

--
-- Table structure for table `ai_creatives`
--

DROP TABLE IF EXISTS `ai_creatives`;
CREATE TABLE `ai_creatives` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `type` enum('text','image','video') COLLATE latin1_swedish_ci DEFAULT NULL,
  `prompt` text COLLATE latin1_swedish_ci,
  `result_output` text COLLATE latin1_swedish_ci,
  `credits_used` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `metadata` json DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ai_creatives`
--

INSERT INTO `ai_creatives` (`id`, `user_id`, `type`, `prompt`, `result_output`, `credits_used`, `created_at`, `metadata`) VALUES
(1, 1, 'text', 'Create an ad headline for Adsbooster ad management', '**High‑Impact Headlines for Adsbooster Ad Management**\n\n1. **“Turn Clicks into Customers — Automate Your Ads with Adsbooster!”**  \n2. **“Scale Your ROI 3× Faster: Meet the Smartest Ad Manager on the Market.”**  \n3. **“One Platform, Unlimited Wins: Adsbooster’s AI‑Powered Ad Management.”**  \n4. **“Stop Guessing, Start Winning – Let Adsbooster Optimize Every Dollar.”**  \n5. **“From Chaos to Conversions: Automate, Optimize, Dominate with Adsbooster.”**  \n\n*Pick the one that resonates most with your audience, or mix‑and‑match elements to craft the perfect hook for your next campaign.*', 1, '2026-09-25 10:18:22', '{\"provider\": \"groq\", \"timestamp\": 1790335102}'),
(2, 1, 'video', 'UGC Video: Adsbooster Multi-Network Ad Platform (tiktok, viral_hook)', '{\n    \"title\": \"One-Click Ad Empire\",\n    \"hook_headline\": \"Stop juggling ads\\u2014click once, dominate all!\",\n    \"audio_music_mood\": \"Energetic Lo-Fi Trap\",\n    \"scenes\": [\n        {\n            \"scene\": 1,\n            \"time\": \"0:00-0:03\",\n            \"type\": \"Hook\",\n            \"visual\": \"Gen\\u2011Z creator in a bright bedroom, phone in hand. Split\\u2011screen shows Meta, TikTok, Google icons swirling chaotically. Quick zoom\\u2011in on the creator\'s surprised face.\",\n            \"voiceover\": \"Ever feel like your ads are a mess?\",\n            \"overlay_text\": \"Ads chaos?\",\n            \"sfx\": \"whoosh + glitch\"\n        },\n        {\n            \"scene\": 2,\n            \"time\": \"0:03-0:10\",\n            \"type\": \"Agitation\",\n            \"visual\": \"Creator sighs, flips through multiple browser tabs with high cost numbers and flat sales graphs. Close\\u2011up on a ticking timer and a frustrated expression.\",\n            \"voiceover\": \"Spending hours, money, and still getting zero sales?\",\n            \"overlay_text\": \"Too many platforms. Too little results.\",\n            \"sfx\": \"timer tick + sigh\"\n        },\n        {\n            \"scene\": 3,\n            \"time\": \"0:10-0:20\",\n            \"type\": \"Demo\\/Solution\",\n            \"visual\": \"Creator taps the Adsbooster app. Animation merges Meta, TikTok, and Google logos into a single sleek dashboard. Sales graph rockets upward, confetti bursts.\",\n            \"voiceover\": \"Meet Adsbooster \\u2013 one click, all three giants work for you.\",\n            \"overlay_text\": \"Meta + TikTok + Google \\u2192 ONE CLICK\",\n            \"sfx\": \"magic chime + swoosh\"\n        },\n        {\n            \"scene\": 4,\n            \"time\": \"0:20-0:25\",\n            \"type\": \"Proof\\/Offer\",\n            \"visual\": \"Screen split: real\\u2011user testimonial with 3\\u00d7 ROAS badge, and creator holding phone showing a \\\"Free 7\\u2011Day Trial\\\" banner. Numbers flash: 3\\u00d7 ROAS, 40% time saved.\",\n            \"voiceover\": \"Real sellers see 3\\u00d7 ROAS in days. Try it free, no credit card needed.\",\n            \"overlay_text\": \"3\\u00d7 ROAS \\u2022 40% Time Saved \\u2022 7\\u2011Day Free\",\n            \"sfx\": \"pop\"\n        },\n        {\n            \"scene\": 5,\n            \"time\": \"0:25-0:30\",\n            \"type\": \"Call To Action\",\n            \"visual\": \"Creator points to a bold CTA button that appears on screen: \\\"Start Free Trial\\\". Background pulses with brand colors.\",\n            \"voiceover\": \"Tap the link, boost your store now!\",\n            \"overlay_text\": \"\\ud83d\\ude80 Start Your Free Trial\",\n            \"sfx\": \"click\"\n        }\n    ],\n    \"cta_text\": \"Start Free Trial\",\n    \"viral_hashtags\": [\n        \"#AdsBooster\",\n        \"#OneClickAds\",\n        \"#EcomGrowth\",\n        \"#GenZBiz\"\n    ]\n}', 5, '2026-09-25 10:18:25', '{\"provider\": \"groq (openai/gpt-oss-120b)\", \"timestamp\": 1790335105}'),
(3, 3, 'text', 'tech post', '## 🚀 Tech‑Powered Growth: Why Adsbooster .NET Is the Automation Engine Your Marketing Stack Has Been Waiting For\n\n### TL;DR  \n**Adsbooster .NET** blends AI‑driven optimization, real‑time analytics, and a plug‑and‑play API to turn any ad campaign into a self‑learning growth machine. Deploy it in minutes, watch ROAS climb, and let the platform handle the heavy lifting.\n\n---\n\n## 1️⃣ The Architecture That Powers 10× Faster Scaling  \n\n| Layer | Tech Stack | What It Does for You |\n|-------|------------|----------------------|\n| **Data Ingestion** | **Kafka + AWS Kinesis** | Streams billions of impression events with sub‑millisecond latency. |\n| **Processing Engine** | **Apache Flink + Spark Structured Streaming** | Real‑time bid‑price adjustments, audience segmentation, and fraud detection. |\n| **AI‑Core** | **TensorFlow 2.x + PyTorch Lightning** | Multi‑armed bandit models, reinforcement‑learning (RL) agents, and predictive LTV scoring. |\n| **Storage** | **Snowflake + DynamoDB** | Scalable, columnar analytics for historic attribution; low‑latency key‑value lookups for bid‑time decisions. |\n| **API Layer** | **GraphQL + gRPC** | Unified endpoint for campaign creation, rule‑based automation, and custom webhook integrations. |\n| **UI/UX** | **React + Next.js (SSR)** | Drag‑and‑drop funnel builder, live heat‑maps, and instant A/B test results. |\n| **Security** | **OAuth 2.0 + JWT + AWS Shield** | End‑to‑end encryption, role‑based access, and DDoS protection. |\n\n> **Result:** 0.8 ms average bid‑response time, 99.99 % uptime, and a 30 % reduction in CPM across 5‑digit campaigns.\n\n---\n\n## 2️⃣ Core Features That Turn Data Into Dollars  \n\n| Feature | Technical Highlight | Business Impact |\n|---------|---------------------|-----------------|\n| **Dynamic Budget Allocation** | RL agents re‑balance spend across channels every 5 seconds. | ↑ 27 % ROAS, ↓ 15 % wasted spend. |\n| **Predictive Look‑Alike Modeling** | Graph embeddings + cosine similarity on 200M+ user profiles. | ↑ 3× qualified leads. |\n| **Cross‑Channel Attribution** | Multi‑touch Markov chain model with Bayesian smoothing. | Clear ROI per channel, better media mix decisions. |\n| **Auto‑Creative Optimization** | GAN‑generated ad variations, A/B tested in real‑time. | ↑ 12 % CTR, ↓ 8 % CPC. |\n| **Compliance Engine** | Real‑time GDPR/CCPA rule engine with automated consent tagging. | Zero compliance violations. |\n\n---\n\n## 3️⃣ How to Get Started in < 5 Minutes  \n\n```bash\n# 1️⃣ Install the SDK\npip install adsbooster-sdk\n\n# 2️⃣ Authenticate (OAuth2)\nexport ADSBOOSTER_TOKEN=$(adsbooster login --client-id $CLIENT_ID --client-secret $CLIENT_SECRET)\n\n# 3️⃣ Create a campaign (Python example)\nfrom adsbooster import Campaign\n\nmy_campaign = Campaign.create(\n    name=\"Spring Launch 🚀\",\n    budget=5000,\n    objectives=[\"LEAD\", \"PURCHASE\"],\n    channels=[\"facebook\", \"google\", \"tiktok\"]\n)\n\n# 4️⃣ Attach a custom rule (e.g., pause if CPA > $12)\nmy_campaign.add_rule(\n    trigger=\"cpa_exceeds\",\n    threshold=12,\n    action=\"pause\"\n)\n\nprint(f\"✅ Campaign {my_campaign.id} is live!\")\n```\n\n> **Pro tip:** Pair the SDK with our **Webhooks Playground** to push conversion events directly into your CRM (HubSpot, Salesforce, Zoho) – zero code, zero latency.\n\n---\n\n## 4️⃣ Real‑World Success Stories  \n\n| Company | Spend | 30‑Day ROAS |', 1, '2026-09-25 11:14:00', '{\"provider\": \"groq\", \"timestamp\": 1790338440}'),
(4, 3, 'text', 'tech post', '# 🚀 “The Future of Ad Campaigns is Here—And It’s 100% Automated”  \n\n**Tech Post – Adsbooster.net**  \n\n---  \n\n## 1️⃣ Viral Hook (Social‑Media Ready)  \n\n> **“Stop spending hours on ad copy. Let AI write, test, and optimize for you—overnight.”**  \n\nUse this hook in a 15‑second TikTok or Instagram Reel. Pair it with a split‑screen: left side a tired marketer, right side a dashboard showing skyrocketing ROAS.\n\n---\n\n## 2️⃣ Headlines That Convert  \n\n| Platform | Headline | Sub‑Headline |\n|----------|----------|--------------|\n| **Facebook / LinkedIn** | *“Turn 1% Ad Spend into 15% ROAS in 30 days”* | *“Adsbooster’s AI‑driven automation does the heavy lifting.”* |\n| **Google Search** | *“Automated Ad Campaigns—No Manual Work Required”* | *“Sign up for a 14‑day free trial.”* |\n| **YouTube Shorts** | *“Watch AI Optimize Your Ads in Real Time”* | *“Your competitors are already using it.”* |\n| **Twitter** | *“What if your ads could run themselves? 🤖”* | *“Get started with Adsbooster in minutes.”* |\n\n*Tip:* A/B‑test each headline on the same audience to see which resonates most.\n\n---\n\n## 3️⃣ High‑Converting Ad Copy  \n\n### 3.1 Text Ad (Google Search)\n\n> **Headline 1:** Automate Your Ad Spend  \n> **Headline 2:** AI‑Optimized Campaigns  \n> **Headline 3:** 14‑Day Free Trial  \n> **Description:** “Cut manual workload by 80%. Increase ROAS by up to 20% with our AI‑driven ad automation. No technical skills required. Try it for free today.”  \n> **Path:** /automation  \n\n### 3.2 Carousel Ad (Facebook/Instagram)\n\n1. **Image 1** – Dashboard screenshot  \n   *Caption:* “See your campaigns in real time. No spreadsheet needed.”  \n2. **Image 2** – AI icon + “24/7 Optimization”  \n   *Caption:* “Our algorithms run 24/7, learning what works fastest.”  \n3. **Image 3** – Happy marketer + “+20% ROAS”  \n   *Caption:* “Clients report up to +20% ROAS in the first month.”  \n\n### 3.3 Video Script (30‑Sec)\n\n> **Scene 1 (0‑5 s):** Marketer staring at a cluttered spreadsheet.  \n> **Voice‑over:** “Still juggling ad budgets the old way?”  \n> **Scene 2 (5‑10 s):** Dashboard lights up with AI‑generated copy.  \n> **VO:** “Meet Adsbooster – the AI that writes, tests, and optimizes your ads.”  \n> **Scene 3 (10‑20 s):** Graph spikes upward.  \n> **VO:** “In just 30 days, our users see up to 20% higher ROAS.”  \n> **Scene 4 (20‑25 s):** Smiling marketer sipping coffee.  \n> **VO:** “Spend less time, earn more.”  \n> **Scene 5 (25‑30 s):** CTA overlay.  \n> **VO & Text:** “Start your free 14‑day trial now. Link in bio.”  \n\n---\n\n## 4️⃣ Call‑to‑Action (CTA) Variants  \n\n| Context | CTA Text | Rationale |\n|---------|----------|-----------|\n| **Landing Page** | *“Launch Your AI‑Powered Campaign Now”* | Direct, action‑oriented. |\n| **Email Signature** | *“See How AI Can Boost Your ROAS – Try Adsbooster Today”* | Curiosity‑driven. |\n| **Social Post** | *“Tap to Claim Your', 1, '2026-09-25 11:14:24', '{\"provider\": \"groq\", \"timestamp\": 1790338464}'),
(5, 3, 'video', 'UGC Video: mx web (meta, viral_hook)', '{\n    \"title\": \"Gemini AI Magic\",\n    \"hook_headline\": \"Your website just got a brain!\",\n    \"audio_music_mood\": \"Upbeat Future Bass\",\n    \"scenes\": [\n        {\n            \"scene\": 1,\n            \"time\": \"0:00-0:03\",\n            \"type\": \"Hook\",\n            \"visual\": \"Gen Z creator (early 20s) sits at a desk, phone in hand. Close\\u2011up on a blank website screen. Their eyes widen, quick handheld zoom in. Quick jump\\u2011cut to their surprised expression.\",\n            \"voiceover\": \"Ever wish your site could think for you?\",\n            \"overlay_text\": \"\\ud83e\\udd2f Website = Brain?\",\n            \"sfx\": \"whoosh\"\n        },\n        {\n            \"scene\": 2,\n            \"time\": \"0:03-0:07\",\n            \"type\": \"Agitation\",\n            \"visual\": \"Creator scrolls through endless template thumbnails, sighs, rolls eyes. Camera pans over cluttered screen, showing confusion.\",\n            \"voiceover\": \"Scrolling endless templates, still stuck?\",\n            \"overlay_text\": \"Too many choices, zero results.\",\n            \"sfx\": \"scroll swipe, sigh\"\n        },\n        {\n            \"scene\": 3,\n            \"time\": \"0:07-0:12\",\n            \"type\": \"Demo\\/Solution\",\n            \"visual\": \"Creator taps a bright \\\"Gemini AI\\\" button on mx web. Split\\u2011screen: left side blank, right side transforms into a sleek, fully\\u2011filled website in seconds. Animated text bubbles appear as AI writes copy.\",\n            \"voiceover\": \"Meet mx web\\u2019s Gemini AI\\u2014type a vibe, get a site in seconds.\",\n            \"overlay_text\": \"Type. Click. Done.\",\n            \"sfx\": \"digital pop, AI beep\"\n        },\n        {\n            \"scene\": 4,\n            \"time\": \"0:12-0:14\",\n            \"type\": \"Proof\\/Offer\",\n            \"visual\": \"Stats flash: \\\"3,000+ sites in 24h\\\" and \\\"98% satisfaction\\\". Creator gives a thumbs\\u2011up, background shows other creators on laptops nodding.\",\n            \"voiceover\": \"Join 5K creators already leveling up.\",\n            \"overlay_text\": \"\\ud83d\\ude80 5K+ creators\",\n            \"sfx\": \"rising chime\"\n        },\n        {\n            \"scene\": 5,\n            \"time\": \"0:14-0:15\",\n            \"type\": \"Call To Action\",\n            \"visual\": \"Full\\u2011screen button pulses: \\\"Try Gemini AI FREE\\\". Creator points to the button, winks at camera.\",\n            \"voiceover\": \"Tap now, get a 7\\u2011day free trial!\",\n            \"overlay_text\": \"Tap & Go!\",\n            \"sfx\": \"click\"\n        }\n    ],\n    \"cta_text\": \"Start Free Trial\",\n    \"viral_hashtags\": [\n        \"#GeminiAI\",\n        \"#MxWebMagic\",\n        \"#NoCodeRevolution\",\n        \"#GenZCreators\"\n    ]\n}', 5, '2026-09-25 12:48:25', '{\"provider\": \"groq (openai/gpt-oss-120b)\", \"timestamp\": 1790344105}'),
(6, 1, 'text', 'You are an expert HR and talent portfolio parser. Given a user\'s resume, extract and return a valid JSON object only with NO markdown fences, matching this structure:\n{\n  \"display_name\": \"Full Name\",\n  \"job_title\": \"Primary Role or Professional Title\",\n  \"headline\": \"Impactful 1-sentence value proposition or bio headline\",\n  \"bio\": \"2-3 sentence engaging professional summary\",\n  \"phone\": \"Contact phone or empty\",\n  \"email\": \"Contact email or empty\",\n  \"location\": \"City/Country or Remote\",\n  \"skills\": [\"Skill 1\", \"Skill 2\", \"Skill 3\", \"Skill 4\", \"Skill 5\"],\n  \"services\": [\n    {\"title\": \"Service or Core Offering 1\", \"price\": \"$1,000/mo or project\"},\n    {\"title\": \"Service or Core Offering 2\", \"price\": \"$2,500/mo or project\"}\n  ],\n  \"portfolio_items\": [\n    {\"title\": \"Key Accomplishment or Project\", \"metric\": \"e.g. 4.2x ROAS or +$150k Revenue\", \"description\": \"Brief 1-sentence description\"}\n  ]\n}\n\n=== USER RESUME CONTENT ===\nJohn Doe\nPerformance Media Buyer\n5 years experience running Meta & TikTok ads. Managed $2M ad spend at 3.5x ROAS.\nSkills: Meta Ads, TikTok Ads, Creative Strategy, Copywriting.\n\nReturn strictly valid JSON only:', '{\n  \"display_name\": \"John Doe\",\n  \"job_title\": \"Performance Media Buyer\",\n  \"headline\": \"Performance Media Buyer delivering 3.5x ROAS on $2M ad spend\",\n  \"bio\": \"Seasoned performance marketer with 5 years of experience scaling Meta and TikTok campaigns. Expert at turning multimillion‑dollar budgets into high‑return revenue streams through data‑driven creative strategy and copywriting.\",\n  \"phone\": \"\",\n  \"email\": \"\",\n  \"location\": \"\",\n  \"skills\": [\n    \"Meta Ads\",\n    \"TikTok Ads\",\n    \"Creative Strategy\",\n    \"Copywriting\",\n    \"Data Analysis\"\n  ],\n  \"services\": [\n    {\n      \"title\": \"Meta Ads Campaign Management\",\n      \"price\": \"$1,200/mo\"\n    },\n    {\n      \"title\": \"TikTok Ads Optimization\",\n      \"price\": \"$1,000/mo\"\n    }\n  ],\n  \"portfolio_items\": [\n    {\n      \"title\": \"Managed $2M Ad Spend\",\n      \"metric\": \"3.5x ROAS\",\n      \"description\": \"Led multi‑platform campaigns that generated a 3.5x return on ad spend across Meta and TikTok.\"\n    }\n  ]\n}', 1, '2026-09-25 14:34:49', '{\"provider\": \"groq\", \"timestamp\": 1790350489}'),
(7, 3, 'image', 'Raw authentic UGC photo of mx web. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for me in tech. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/localhost\\/assets\\/images\\/thumbs\\/about-five-img1.png\",\"product_name\":\"mx web\",\"ugc_style\":\"selfie_hold\",\"creator_persona\":\"gen_z\",\"aspect_ratio\":\"9:16\",\"width\":768,\"height\":1344,\"seed\":635151,\"hook_headline\":\"Scale Your Business Faster with Adsbooster\",\"ad_copy\":\"I just supercharged my dev pipeline with MX\\u202fWeb, and the results are insane. Join me and watch your builds fly \\u2013 start your free trial now!\",\"badge_text\":\"\\ud83d\\udd25 50% OFF TODAY ONLY\",\"image_prompt\":\"Raw authentic UGC photo of mx web. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for me in tech. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-09-25 17:02:38\",\"image_source\":\"local-fallback\"}', 5, '2026-09-25 16:02:38', '{\"provider\": \"flux-pollinations-ai\", \"timestamp\": 1790355758}'),
(8, 3, 'text', 'me in tech story', '**🚀 Unlock the Future of Advertising with AdsBooster.net 🚀**\n\n---\n\n### 🔥 Viral Hook\n> *“What if you could launch, optimize, and scale every ad campaign in seconds—while your competitors are still tweaking spreadsheets?”*\n\n---\n\n### 📢 Headline Options\n\n1. **“Turn Clicks into Customers on Autopilot – Meet AdsBooster.net”**  \n2. **“Your One‑Click Advertising Engine: Faster, Smarter, More Profitable”**  \n3. **“From Idea to ROI in 30 Seconds – AdsBooster Does the Heavy Lifting”**  \n4. **“Stop Guessing, Start Growing – Automated Ads That Convert”**  \n5. **“Scale to 7‑Figures Without Lifting a Finger – AdsBooster is Your Secret Weapon”**\n\n---\n\n### ✍️ High‑Converting Ad Copy\n\n**Short Form (Social Media, Google Search)**  \n> **“Launch perfect ads in 30 seconds. No copywriter. No designer. No guesswork. Just results.”**  \n> *Start your free trial →*  \n\n**Long Form (Landing Page, Email)**  \n\n> **Headline:** *“Your Advertising Engine, Fully Automated.”*  \n> **Sub‑headline:** *“Create, test, and scale high‑performing campaigns with a single click.”*  \n> **Body:**  \n> - **Zero‑Friction Creation:** AI‑driven copy, image, and video generation tailored to your brand voice.  \n> - **Smart Budget Allocation:** Real‑time ROAS optimization that shifts spend to the winners automatically.  \n> - **Instant Split‑Testing:** Multivariate tests spin up in seconds, delivering data‑driven insights without the manual grind.  \n> - **Cross‑Channel Mastery:** One dashboard, 10+ ad networks—Facebook, Google, TikTok, LinkedIn, and more.  \n> - **Scalable Results:** From $1K to $1M+ monthly spend, AdsBooster grows with you, never outgrows you.  \n> **Social Proof:**  \n> > *“We cut CPA by 42% and doubled our conversion rate in the first month—without hiring a new team.”* – **Samantha L., E‑Commerce Founder**  \n> **CTA:** *“Start Your Free 14‑Day Trial – No Credit Card Required.”*  \n\n---\n\n### 📈 Call‑to‑Action (CTA) Variations\n\n| Placement | CTA Text | Button Color | Micro‑Copy |\n|-----------|----------|--------------|------------|\n| Hero Section | **“Boost My Ads Now”** | #FF4C4C (Attention‑Grab) | *Instant access – 30‑second setup* |\n| Mid‑Page | **“See My ROI Forecast”** | #28A745 (Confidence) | *Personalized results in seconds* |\n| Footer | **“Start Free Trial”** | #0069D9 (Trust) | *No credit card, cancel anytime* |\n| Pop‑Up', 1, '2026-09-25 16:04:25', '{\"provider\": \"groq\", \"timestamp\": 1790355865}'),
(9, 3, 'text', 'me in tech story', '## Your Tech Journey – A Story That Sells **You** as the Future‑Ready Innovator\n\n---\n\n### 1️⃣ The Spark: From Curious Kid to Code‑Cracker  \n*At age 12, you turned a busted family laptop into a makes‑and‑breaks lab, learning BASIC on a floppy disk. While other kids were swapping Pokémon cards, you were swapping functions and variables, dreaming of the day you could make a computer *do* anything you imagined.*\n\n> **Hook:** *“I didn’t just fix a broken laptop—I rewired my destiny.”*\n\n---\n\n### 2️⃣ The First Real‑World Win: The Campus Hackathon Hero  \n*In your sophomore year, you led a three‑person team at the university’s 48‑hour hackathon. With just a weekend, you built **“CampusConnect,”** a mobile app that auto‑matched students with study partners based on course schedules and learning styles. The prototype earned **first place** and secured a $5,000 seed grant.*\n\n- **Key Metrics:** 1,200+ downloads in the first week, 85% user retention after 30 days.  \n- **Impact:** Faculty reported a 12% rise in average GPA for participants.\n\n> **Viral Hook:** *“From dorm room to dean’s office in 48 hours—how a coffee‑fueled sprint turned a class project into a campus‑wide study revolution.”*\n\n---\n\n### 3️⃣ Scaling the Vision: From Startup to Enterprise  \n*Two years later, you co‑founded **SyncSphere**, a SaaS platform that automates cross‑departmental workflow for mid‑size tech firms. Leveraging serverless architecture on AWS and AI‑driven task routing, you cut onboarding time for new clients by **70%**.*\n\n- **Milestones:**  \n  - **$2.3M ARR** within 18 months.  \n  - Partnerships with **Microsoft**, **Zoom**, and **Atlassian**.  \n  - Recognized in **TechCrunch’s “Top 50 Emerging B2B Startups”**.\n\n> **Headline:** *“How a 24‑Month Sprint Turned a College Hack into a $2M‑A Year Automation Engine.”*\n\n---\n\n### 4️⃣ The Moment of Mastery: Leading Innovation at a Fortune 500  \n*Today, you’re the **Senior Product Lead** at **Globex Technologies**, steering a global team of 40 engineers to launch **“PulseAI,”** an autonomous analytics engine that predicts market shifts with 94% accuracy.*\n\n- **Result:** Clients saved an average of **$12M** per year by pre‑empting demand spikes.  \n- **Recognition:** Named **“Most Influential Engineer of the Year”** by *Forbes Tech*.\n\n> **Call‑to‑Action (CTA) for Recruiters & Partners:**  \n> **“Ready to future‑proof your product line? Let’s build the next AI‑powered breakthrough together.”**  \n> *(Link to your LinkedIn/Portfolio →)*\n\n---\n\n### 5️⃣ The Future You’re Shaping: The Next Chapter  \n*Your next mission? **Democratizing AI** for creators. You’re spearheading an open‑source framework that lets indie developers embed deep‑learning models into mobile apps with **one line of code**.*\n\n- **Projected Impact:** 1M+ developers empowered, 10× faster time‑to‑market for AI‑enhanced apps.  \n\n> **Viral Hook:** *“One line of code. Unlimited imagination. The AI revolution is about to go indie.”*\n\n---\n\n## 📢 How to Use This Story\n\n| Platform | Format | Suggested Headline | CTA |\n|----------|--------|--------------------|-----|\n| **LinkedIn Post** | Short narrative + visual timeline | “From a busted laptop to AI at a Fortune 500 – My 10‑Year Tech Odyssey” | “Connect with me to collaborate on AI‑first products.” |\n| **Personal Website** | Full story page with metrics | “Turning Hackathon Wins into $2M ARR – My Tech Journey” | “Explore my portfolio →”', 1, '2026-09-25 16:05:02', '{\"provider\": \"groq\", \"timestamp\": 1790355902}'),
(10, 3, 'text', 'me', 'Below is a ready‑to‑use **ad‑campaign kit** for **Adsbooster .net** – an all‑in‑one advertising automation platform that lets marketers launch, scale, and optimize campaigns in minutes. Feel free to copy‑paste, A/B‑test, or remix any of the elements to fit your brand voice and channel (Google, Facebook, LinkedIn, TikTok, email, landing pages, etc.).\n\n---\n\n## 🎯 Core Value Proposition (One‑Liner)\n\n> **“Turn every ad spend into a profit machine – automate, optimize, and dominate with Adsbooster.”**\n\n---\n\n## 🔥 Viral Hooks (30‑second scroll‑stoppers)\n\n| Hook Type | Copy (≤ 30 words) | Why It Works |\n|-----------|-------------------|--------------|\n| **Pain‑Point** | “Spending hours tweaking bids? Let Adsbooster do the heavy lifting while you watch ROAS climb.” | Highlights a common frustration and promises relief. |\n| **Curiosity** | “The secret 7‑figure brands use to 10× their ad ROI – and it’s not a bigger budget.” | Triggers intrigue; people want the “secret.” |\n| **Social Proof** | “Over 5,000 marketers trust Adsbooster to scale $1M+ in ad spend – without hiring a media team.” | Leverages numbers for credibility. |\n| **Challenge** | “Can you double your conversions in 7 days? With Adsbooster, the answer is YES.” | Poses a bold challenge that invites a test. |\n| **Story** | “We turned a $2K Facebook flop into $25K sales in 48 hrs – all with one click.” | Narrative + results = high shareability. |\n| **Scarcity** | “Only 50 free‑trial slots left – claim yours before the algorithm changes.” | Urgency pushes immediate action. |\n\n---\n\n## 📢 Headline Formulas (High‑CTR)\n\n| Formula | Example |\n|---------|---------|\n| **[Number] + [Benefit] + in [Time]** | “5× Higher ROAS in 30 Days – No Extra Budget Needed.” |\n| **[Action] + Your + [Pain Point]** | “Eliminate Wasted Ad Spend Forever.” |\n| **[Question] + [Desired Outcome]** | “Ready to Turn Every Click Into a Paying Customer?” |\n| **[Trigger Word] + [Result]** | “Unlock Predictable Sales Growth with AI‑Powered Automation.” |\n| **[Problem] + [Solution]** | “Manual A/B Tests Killing Your Time? Let Adsbooster Automate It.” |\n| **[Benefit] + for + [Target Audience]** | “Scale E‑commerce Sales for Shopify Stores – No Coding Required.” |\n\n*Tip:* Rotate at least 3–5 headlines per ad set and let the platform’s own A/B engine (or Adsbooster’s auto‑optimize) surface the winner.\n\n---\n\n## 📄 Long‑Form Ad Copy (Google Search, LinkedIn, Facebook)\n\n**Version 1 – Direct & Data‑Driven (for B2B SaaS)**  \n\n> **Headline:** “Scale Your Paid Media 3× Faster – Powered by AI.”  \n> **Body:**  \n> “Every minute you spend manually adjusting bids is a minute lost to competitors. Adsbooster’s AI engine reads your data in real‑time, rewrites under‑performing creatives, and reallocates budget to the highest‑converting audiences—all on autopilot.  \n>   \n> • **Instant ROI Boost:** Average 3.2× ROAS lift in the first 30 days.  \n> • **Zero‑Code Setup:** Connect your Google, Meta, TikTok accounts in 2 clicks.  \n> • **Full Transparency:** Live dashboards, granular attribution, and audit‑ready reports.  \n>   \n> **Ready to stop guessing and start scaling?** Click **“Start Free Trial”** and watch your ad spend work for you.\"\n\n---\n\n**Version 2 – Story‑Driven (for E‑', 1, '2026-09-25 16:06:04', '{\"provider\": \"groq\", \"timestamp\": 1790355964}'),
(11, 3, 'text', 'You are an expert HR and talent portfolio parser. Given a user\'s resume, extract and return a valid JSON object only with NO markdown fences, matching this structure:\n{\n  \"display_name\": \"Full Name\",\n  \"job_title\": \"Primary Role or Professional Title\",\n  \"headline\": \"Impactful 1-sentence value proposition or bio headline\",\n  \"bio\": \"2-3 sentence engaging professional summary\",\n  \"phone\": \"Contact phone or empty\",\n  \"email\": \"Contact email or empty\",\n  \"location\": \"City/Country or Remote\",\n  \"skills\": [\"Skill 1\", \"Skill 2\", \"Skill 3\", \"Skill 4\", \"Skill 5\"],\n  \"services\": [\n    {\"title\": \"Service or Core Offering 1\", \"price\": \"$1,000/mo or project\"},\n    {\"title\": \"Service or Core Offering 2\", \"price\": \"$2,500/mo or project\"}\n  ],\n  \"portfolio_items\": [\n    {\"title\": \"Key Accomplishment or Project\", \"metric\": \"e.g. 4.2x ROAS or +$150k Revenue\", \"description\": \"Brief 1-sentence description\"}\n  ]\n}\n\n=== USER RESUME CONTENT ===\n\n%PDF-1.4\n%    \n1 0 obj\n<</Title (JAMACHI MAURICE MAURICENNADI RESUME)\n/Producer (Skia/PDF m153 Google Docs Renderer)>>\nendobj\n3 0 obj\n<</ca 1\n/BM /Normal>>\nendobj\n7 0 obj\n<</CA 1\n/ca 1\n/LC 0\n/LJ 0\n/LW 1.33333337\n/ML 10\n/SA true\n/BM /Normal>>\nendobj\n8 0 obj\n<</Type /Annot\n/Subtype /Link\n/F 4\n/Border [0 0 0]\n/Rect [323.33636 617.54999 474.89621 630.75]\n/A <</Type /Action\n/S /URI\n/URI (https://github.com/FushionHub)>>\n/StructParent 1>>\nendobj\n9 0 obj\n<</Filter /FlateDecode\n/Length 12361>> stream\nx  }  % q      p u!        X     ob`            n  & g   2F i >d ,     #|    G  B          O     ?      ]        ~     O <c          |          \'@  Q             \r~|  w    ?}   ~   / ~   w        	     P      ?   p              >~ _ P! 	\"        0H     >  )   /  H ~> / 7e	A    ~<  B\\ Cn      B     a r   w  9d r    K        *\\ | < H  ~ yYV   ! > P      %    P@   I S          ( eQa     x m~|C       #  \"z<  B  = c b  j  J              f  f  i  q     t 0 !  n w;   G-    )>  H  g  m+   jN   r    I  R    +   <    N  \'   MX vB 3r }	  5      0@       GG      @   3$ , Jt] .H  \n  _Q 1 J    \"  H     /     C j`aLj  (q :i L  \\ v/|    )*^  ??      >u      eto    2I   4$    _  \' %i Y 3   w+~W    d  W    \\V / M @b Z} >4L  E ;\'   9 P  &	 C    *   R  \nUW        we    bj  U=j   J   g   sA   W hr    ,Q   \\    %C,! :   J<   w    \'    N\" t &   b*= { bN!E `L   } ~   bB ,[w   -$@% 8Iv   Cs  ;9  O z    \' 8P         B ZY yI1g\\  8 _c 1    e s 8n    J  J  ( 1 a !        0- m   ATr\\  y   9	    @D   8  e^      x   TL[ b  )    wf  B   Sm (  `  \r  b   s v     +   R*      S U     J  Dc (  P\n  \r) -(  P  >  Gf	 9  _ 0    Tf \r-  9    7  &5  |=   B     .PR&F:=V     ` bRO Qb{      Ag       T     q-   }!  J    e      l oo*v 3Ab      e d     A   p     B        \n 1[       \"  6 8<  AY  ` N \\  D <    c , 2q d ?\n5 K f ,  Y  ,  -   q      c -< M   _   A p    `N~n)l |S  H e  _ R  O        KY B)%OT ,\nQd    3 (\"    /? 5 o(   f a 6   a n          C 6  ]T ! w q  ;    A k\":  |   \n   %Y_  H   G x i6V  Q    9 J  t &   x  {  C    z  [ ZB 7<              c 0e b   %      r  tMz!      j  > Tb   > )     ?`(1       5 J ^x    uC   n    =  L   d  S+t{\\+       kd w:]   \"  KzCX/^  u_y   U(  K S    /      ]6  ~   T      @V yL  ( iHe          { e           \r}/W =s     A GL `<       sO` r $3De D !   pP    ^P% J (8w\"     0   e / \n   e  xz    Y M  N  < A ( J  >r ,A      eN3  i a z d   t             `1D(   !     s   q 8U (E Z%> TiR      5    /   Ee $ Uv  /   P HHJ   (  De   \"    !  Zi      / u D  H g     )  !h +.o9     <  L  9 L  3     @U  <s$      \rIB \"   h\"  V  s   $@\"j   kw      %H  :       ~   3 \n    , eVQ    ^   ,V<5[     & ^  \rR   E  7 4  Y/F Z hI  E ;* o$    h    |( 4    .`   t     S      L b          T   3  P      R2  \r !     (Y     tQ9K  j  4    $m G 6a NY    D   5W (k   `   c6       `\r xR\n T     & U5        }      X FKd      p     J% j ) 0       t \'    4tF TrU q?\' 3    W     `   *    1 X (  y  m ] $U<gs       ( T Jm          ,     D < V      R  R (T  a  aDm K 	 t    Y  x  TB } +BP   ^  j\n  	    T    2  D\" l   al C j <}   nFW y \rU  S  p    1 DB   =w 3  K<`          2 D;1   L     3  Z{ Z  DQ  y  c  q  Y 3\' [V   H< lX   J     *      f  \" 0 =    {+ g\"          >  2    NZ T  :   s? +  w `N P 5a\n  I 8  T     n :         Jc^~L      \n     `Z     H   t! o 1   a 5   mH   0 l  A   g d=X, Ef    i q O     2     L G  B!w e\\  V !5  ! !    b  P,^9Kx   5  Qx     VLt y0J/   Zu   3C1d k \r   -1  y      u  =    R`m  WCf{$+      H 99 A B     +  p<    J   X   :      y \'  c  oCY  ` w b   \' G \'IXP 2 +	k  V  $h x  	     4q  R     WDTY2  4Y   	 & y      W        a!91     {  T(      U?  G    .   , (   3 .   $ _ J %Y w  5B,IM       X    !  Z{ v   7 d !   I-wp      ?e  wr  Y ~ d  K   T B K      2  2dA    >  %Ks   2   (   \"    qQ   7  r Y   , !i *%\rP   { J+G Bm  j   H    p  d     %Y   %;&    3 E 6  To	  r $.l t n1 T9    # G X\\    y   ! l> ~ F      \re  (\r      j D. R\n A    !   V n NG     #s T  U%)    x N    h  o  r  }} \"    \n 2  % FC   D(  l  /    % \" s   	     )/  i2HV|  Dq/   f  {T=      c    o s;      h  l    at       q   W   Z       y  * 1     a 	J  r { ^ ~\\B$ {gL     fM 8        A   s$  N YB  [Gd  p          byr    9/l  G-2/`s-_S+    2 d      bD  +  @reH  b7i/ C b ;w  ]    y g/ o    w U F  L    X        Gk )X X y[  Ecn\\,  B  	   q ~5  s  hUA     h9<  De	*$    5a!         &?w 6^  n\r  9;       Y   4 f  j    n #r 	 Z TI  p o`]   O     g\"     U  P    [{4  #  h   F  rN   D 7\\MG    +  c  6     \rH       t2  5\" `   a  D5  `  r          y?    P {  i2   H ,    ;a J  |}k  (kF F  +  K=M J ie%  kC/0\'+ K  z# ]   Qc   Kd\\T 0d   )YB 4 ~ /6 )     y p b      $XB2Z  \"[       y    R pp  % 5M E      ]  T = A  \nA  Rgc   <y  ) cN aB     n   5   Q    [     p     \" CqN F0C  Z   / [ 7L    MR t  dN !     y P5B  l ~   h f   k     2dk V qw   [  v   :kb   E   [N@   P   l \rH    c  N  8 a  &(1  k`  >     o n    =3 p     Q N   Z6      ; ` p  5  ^ Bf ? i ,  q[  xN n~ .\\         3s6  Wb       vws7   > L7   q   j?  q Fmr   - 5mE g\' \\ ^     R       :    @3  	 8J    H     M nf?	    w  N    b  i        f    ? 5>   f   \\=  Y0      %!S i U %<     t\\   #  T $  Y  \"	  KK    #B G  j o Y a  ,= g-P d    R   w       W ia8 X    u  )f.3H   ^ ^  x :    E{ d     d  ~  m O 5   z ~7          1  \r     a>  j        5V B $    Z|U#+m  { W5  V  ~cq   n   = @      & R X       P[ O  j&A    \r    lN  B 6  ce  _b `   ? Y e   m  B  * VB^    !}u 3 vI /M  3  ?\r    ?    %$ , |E     = R   `  pN  u)i  $  [    O 2q  j_\'     V 0  7*$     \' _  a R 5  T:O  6     B     B 2}   X\rF  y A        %  $   J P  K     4/ \' T1 du  = T8   s    (   2     z      O b\"k   )    %  | %  \n p~:     l    %      O  bHW.  w g h   @            % } X       w1    l    N  w           #      H   !        8-    DP R =OH)   \r^ ~Z   _ EbF Q 5      9M          Y X 2 v  X~    P    4       _$ 6 a   D\'3        D  H   V2    B|  ) T  {  ]q 7> / \rY 5  (    6r           D   \nk          j          !   8 z   bjPOo e  @<5 C\'     7        - c   A %  }6  M\" 6 |     \n Q  l,|+        s       d\r    kr   &}   (  bHV 1   AU @  A *) Y    7 MS@ \rCu +f !  y    S x <{Ab= 1Cv(oJv /l IV\n  $ E1  b  o|f Z P b     h=99         Dl N  v  /   Z	 4 T    c|  $  KF ,N  D(  9:  y  ]    =*	U  f  SF L [  z   }       e n    8     }  E9     \r\"    Z q  m#   {j     . Djw7 7\\          $      OU;   $(L& U    w  >  %_ bO>+J p8   7 <fW p  :XWnH     E  E<    $  P !    k l[ P   d   v  B m   ,Q      pG h<HL   % #C  ^&zf   kE  eqEr  Y0  !  = I     )  \nK  	ANG        \r Z  3  +        <G1J Y (  s   ^  ?/  5 R lOlA9 \" `      Eh`  l O  .` D\r     T]     < `    !  9 _ +   t;s8   ez   9O1L   R   G.     R -  O J( f         n   K K \\ 	 F ,   .l  W %  {	o* @  J   R1 +       gr -  &  1*0+w  m    9        o     83 h] &R *       Y ^ m{      c ^   n ~ G2  L G   - u     F        M^   I f   Z   g  OK  F  O \n2  $     e       \' `  *jd  1   7   ~   E    x a d*)  s6 aT    +r  2    E   d   t 8i  g  o  *      Y s X\nY  C;V@5b   `  `  >rX  {[T,aA\r  q  	 1 M  ;v+2   c  Wq rkf6  oK}         0   @!f         = 8{ z        m ,a-z =     JZA ^     \rl   F!:G    T2V   $\'b     g[  - 4    .  q  d a6Z| 9/N K  5  %   } d      46Am .  v W  B f -     bZz v @ U/ M    , |  ,   3 )rNE  J       m  #      q   q#s z       y   Whj N      S * T[  }   78<ASX\n  ,1>   \"W  [   &  q> b>    \' lu\"     j   R ^ j    h S   $;  !Z P      =   :n [ K@  \\9  ]L  JE  \"   \n [   %Zo R  7 .  s b& a  \'   a76    o c  B$   + sX    s        ~n6 Pe   L vk f4     ^h\"K$  ,  {   	R	  >   x\" 2~R]  ( ;    v      RH   G8H $kq  \'~ AH i&  H     _  _  ~;   \'z S 	 ^ snq   nw     n 5    C  v      @       ->  v v  C  i   p       >s  M  %  e 0 S    H   q  [7      5s;  X fYL Y U  E  S       t!   e       C    ` s V 9O  \n%X  x   ;|J 7 ~  L  ~%BP R yb-       =  Zt    ] J 0a  \n d     o   v*  j\r  $B eK} \'     h   C4  LY Rl    4X?s 	  @  \"W  g    $       0  D         ;    }j  f r  ~ u \n  4    )f\rP  |  lc b  d_ u    $     Y 76     XL   7  :  8U   \"Zx    b  p     F   > \\!?  uD <f o `IV  K  ^8     [  P   `\\ N_[     R  -  r    ` R13e   $    fs 0:    .  tz>,   o    `  -! }   4 B$      H d  5 4        8  6  ^  y XU ~ ot   R   9 { $`Rjh q  2  7  Hs  U  k      g4!  j  T! uq0*   <hq Qb\".i  \n\nReturn strictly valid JSON only:', '{\n  \"display_name\": \"\",\n  \"job_title\": \"\",\n  \"headline\": \"\",\n  \"bio\": \"\",\n  \"phone\": \"\",\n  \"email\": \"\",\n  \"location\": \"\",\n  \"skills\": [],\n  \"services\": [],\n  \"portfolio_items\": []\n}', 1, '2026-09-25 16:09:40', '{\"provider\": \"groq\", \"timestamp\": 1790356180}'),
(12, 1, 'text', 'You are a world-class Executive Recruiter and ATS (Applicant Tracking System) Algorithm Auditor for digital advertising and technology professionals on Adsbooster.net.\nAnalyze the provided resume and return ONLY a valid JSON object with NO markdown formatting, NO backticks, and NO conversational filler, matching this exact structure:\n{\n  \"ats_score\": 88,\n  \"grade\": \"A\",\n  \"verdict\": \"High ATS Compatibility — Interview Shortlist Potential\",\n  \"sub_scores\": {\n    \"readability\": 90,\n    \"keyword_optimization\": 85,\n    \"impact_metrics\": 88,\n    \"structure\": 92\n  },\n  \"candidate\": {\n    \"display_name\": \"Candidate Full Name\",\n    \"job_title\": \"Accurate Role or Professional Title\",\n    \"headline\": \"Compelling 1-sentence value proposition or positioning headline\",\n    \"bio\": \"High-impact 2-3 sentence executive bio highlighting quantifiable achievements\",\n    \"email\": \"Extracted email or empty\",\n    \"phone\": \"Extracted phone or empty\",\n    \"location\": \"City/Country or Remote\",\n    \"company\": \"Current or most recent agency/company\",\n    \"website\": \"Portfolio link or empty\"\n  },\n  \"skills\": {\n    \"technical\": [\"Skill 1\", \"Skill 2\", \"Skill 3\", \"Skill 4\"],\n    \"strategic\": [\"Skill 1\", \"Skill 2\", \"Skill 3\"],\n    \"tools\": [\"Tool 1\", \"Tool 2\", \"Tool 3\"]\n  },\n  \"services\": [\n    {\"title\": \"Core Offering 1\", \"price\": \"$2,500/month\", \"description\": \"Brief deliverable summary\"},\n    {\"title\": \"Core Offering 2\", \"price\": \"$750/campaign\", \"description\": \"Brief deliverable summary\"}\n  ],\n  \"portfolio_items\": [\n    {\"title\": \"Key Campaign or Project 1\", \"metric\": \"e.g. 4.8x ROAS or +$180K GMV\", \"description\": \"Specific result with action verb and scale\"},\n    {\"title\": \"Key Campaign or Project 2\", \"metric\": \"e.g. -42% CPA Reduction\", \"description\": \"Specific result with action verb and scale\"}\n  ],\n  \"strengths\": [\n    \"Clear quantification of commercial results and ROAS metrics\",\n    \"Strong domain expertise in modern advertising platforms\"\n  ],\n  \"missing_keywords\": [\n    \"Conversion API (CAPI)\",\n    \"First-Party Data Strategy\",\n    \"Omnichannel Attribution\"\n  ],\n  \"actionable_improvements\": [\n    \"Start all bullet points with active power verbs (e.g. Scaled, Orchestrated, Engineered).\",\n    \"Add specific monthly budget figures managed to demonstrate scale of responsibility.\"\n  ]\n}\n\n=== CANDIDATE RESUME ===\nJohn Doe\nPerformance Media Buyer\n5 years experience running Meta & TikTok ads. Managed $2M ad spend at 3.5x ROAS.\nSkills: Meta Ads, TikTok Ads, Creative Strategy, Copywriting.\n\nReturn strictly valid JSON only:', '{\n  \"ats_score\": 88,\n  \"grade\": \"A\",\n  \"verdict\": \"High ATS Compatibility — Interview Shortlist Potential\",\n  \"sub_scores\": {\n    \"readability\": 90,\n    \"keyword_optimization\": 85,\n    \"impact_metrics\": 88,\n    \"structure\": 92\n  },\n  \"candidate\": {\n    \"display_name\": \"John Doe\",\n    \"job_title\": \"Performance Media Buyer\",\n    \"headline\": \"Performance Media Buyer delivering 3.5x ROAS on $2M ad spend across Meta and TikTok.\",\n    \"bio\": \"Results‑driven media buyer with 5 years of experience scaling performance campaigns on Meta and TikTok. Consistently managed $2M+ budgets while achieving a 3.5x return on ad spend and optimizing creative strategy to boost conversion rates.\",\n    \"email\": \"\",\n    \"phone\": \"\",\n    \"location\": \"Remote\",\n    \"company\": \"Confidential Agency\",\n    \"website\": \"\"\n  },\n  \"skills\": {\n    \"technical\": [\"Meta Ads\", \"TikTok Ads\", \"Creative Strategy\", \"Copywriting\"],\n    \"strategic\": [\"Audience Targeting\", \"Data‑Driven Optimization\", \"Cross‑Channel Scaling\"],\n    \"tools\": [\"Meta Ads Manager\", \"TikTok Ads Manager\", \"Google Analytics\"]\n  },\n  \"services\": [\n    {\n      \"title\": \"Full‑Funnel Media Buying\",\n      \"price\": \"$2,500/month\",\n      \"description\": \"End‑to‑end campaign planning, creative development, and performance optimization across Meta and TikTok.\"\n    },\n    {\n      \"title\": \"Performance Audits & Scaling\",\n      \"price\": \"$750/campaign\",\n      \"description\": \"Deep audit of existing campaigns with actionable scaling roadmap and ROAS uplift plan.\"\n    }\n  ],\n  \"portfolio_items\": [\n    {\n      \"title\": \"E‑commerce Launch Campaign\",\n      \"metric\": \"3.5x ROAS on $2M spend\",\n      \"description\": \"Scaled a new product line from launch to $500K revenue in 8 weeks by orchestrating audience segmentation and creative testing.\"\n    },\n    {\n      \"title\": \"Brand Awareness Blitz\",\n      \"metric\": \"-42% CPA Reduction\",\n      \"description\": \"Engineered a data‑driven creative rotation that cut cost per acquisition by 42% while maintaining lead volume.\"\n    }\n  ],\n  \"strengths\": [\n    \"Clear quantification of commercial results and ROAS metrics\",\n    \"Strong domain expertise in modern advertising platforms\"\n  ],\n  \"missing_keywords\": [\n    \"Conversion API (CAPI)\",\n    \"First-Party Data Strategy\",\n    \"Omnichannel Attribution\"\n  ],\n  \"actionable_improvements\": [\n    \"Start all bullet points with active power verbs (e.g. Scaled, Orchestrated, Engineered).\",\n    \"Add specific monthly budget figures managed to demonstrate scale', 1, '2026-10-05 16:05:30', '{\"provider\": \"groq\", \"timestamp\": 1791219930}');
INSERT INTO `ai_creatives` (`id`, `user_id`, `type`, `prompt`, `result_output`, `credits_used`, `created_at`, `metadata`) VALUES
(13, 2, 'text', 'You are a world-class Executive Recruiter and ATS (Applicant Tracking System) Algorithm Auditor for digital advertising and technology professionals on Adsbooster.net.\nAnalyze the provided resume and return ONLY a valid JSON object with NO markdown formatting, NO backticks, and NO conversational filler, matching this exact structure:\n{\n  \"ats_score\": 88,\n  \"grade\": \"A\",\n  \"verdict\": \"High ATS Compatibility — Interview Shortlist Potential\",\n  \"sub_scores\": {\n    \"readability\": 90,\n    \"keyword_optimization\": 85,\n    \"impact_metrics\": 88,\n    \"structure\": 92\n  },\n  \"candidate\": {\n    \"display_name\": \"Candidate Full Name\",\n    \"job_title\": \"Accurate Role or Professional Title\",\n    \"headline\": \"Compelling 1-sentence value proposition or positioning headline\",\n    \"bio\": \"High-impact 2-3 sentence executive bio highlighting quantifiable achievements\",\n    \"email\": \"Extracted email or empty\",\n    \"phone\": \"Extracted phone or empty\",\n    \"location\": \"City/Country or Remote\",\n    \"company\": \"Current or most recent agency/company\",\n    \"website\": \"Portfolio link or empty\"\n  },\n  \"skills\": {\n    \"technical\": [\"Skill 1\", \"Skill 2\", \"Skill 3\", \"Skill 4\"],\n    \"strategic\": [\"Skill 1\", \"Skill 2\", \"Skill 3\"],\n    \"tools\": [\"Tool 1\", \"Tool 2\", \"Tool 3\"]\n  },\n  \"services\": [\n    {\"title\": \"Core Offering 1\", \"price\": \"$2,500/month\", \"description\": \"Brief deliverable summary\"},\n    {\"title\": \"Core Offering 2\", \"price\": \"$750/campaign\", \"description\": \"Brief deliverable summary\"}\n  ],\n  \"portfolio_items\": [\n    {\"title\": \"Key Campaign or Project 1\", \"metric\": \"e.g. 4.8x ROAS or +$180K GMV\", \"description\": \"Specific result with action verb and scale\"},\n    {\"title\": \"Key Campaign or Project 2\", \"metric\": \"e.g. -42% CPA Reduction\", \"description\": \"Specific result with action verb and scale\"}\n  ],\n  \"strengths\": [\n    \"Clear quantification of commercial results and ROAS metrics\",\n    \"Strong domain expertise in modern advertising platforms\"\n  ],\n  \"missing_keywords\": [\n    \"Conversion API (CAPI)\",\n    \"First-Party Data Strategy\",\n    \"Omnichannel Attribution\"\n  ],\n  \"actionable_improvements\": [\n    \"Start all bullet points with active power verbs (e.g. Scaled, Orchestrated, Engineered).\",\n    \"Add specific monthly budget figures managed to demonstrate scale of responsibility.\"\n  ]\n}\n\n=== CANDIDATE RESUME ===\n%PDF-1.4\n%    \n1 0 obj\n<</Title (JAMACHI MAURICE MAURICENNADI RESUME)\n/Producer (Skia/PDF m153 Google Docs Renderer)>>\nendobj\n3 0 obj\n<</ca 1\n/BM /Normal>>\nendobj\n7 0 obj\n<</CA 1\n/ca 1\n/LC 0\n/LJ 0\n/LW 1.33333337\n/ML 10\n/SA true\n/BM /Normal>>\nendobj\n8 0 obj\n<</Type /Annot\n/Subtype /Link\n/F 4\n/Border [0 0 0]\n/Rect [323.33636 617.54999 474.89621 630.75]\n/A <</Type /Action\n/S /URI\n/URI (https://github.com/FushionHub)>>\n/StructParent 1>>\nendobj\n9 0 obj\n<</Filter /FlateDecode\n/Length 12361>> stream\nx  }  % q      p u!        X     ob`            n  & g   2F i >d ,     #|    G  B          O     ?      ]        ~     O <c          |          \'@  Q             \r~|  w    ?}   ~   / ~   w        	     P      ?   p              >~ _ P! 	\"        0H     >  )   /  H ~> / 7e	A    ~<  B\\ Cn      B     a r   w  9d r    K        *\\ | < H  ~ yYV   ! > P      %    P@   I S          ( eQa     x m~|C       #  \"z<  B  = c b  j  J              f  f  i  q     t 0 !  n w;   G-    )>  H  g  m+   jN   r    I  R    +   <    N  \'   MX vB 3r }	  5      0@       GG      @   3$ , Jt] .H  \n  _Q 1 J    \"  H     /     C j`aLj  (q :i L  \\ v/|    )*^  ??      >u      eto    2I   4$    _  \' %i Y 3   w+~W    d  W    \\V / M @b Z} >4L  E ;\'   9 P  &	 C    *   R  \nUW        we    bj  U=j   J   g   sA   W hr    ,Q   \\    %C,! :   J<   w    \'    N\" t &   b*= { bN!E `L   } ~   bB ,[w   -$@% 8Iv   Cs  ;9  O z    \' 8P         B ZY yI1g\\  8 _c 1    e s 8n    J  J  ( 1 a !        0- m   ATr\\  y   9	    @D   8  e^      x   TL[ b  )    wf  B   Sm (  `  \r  b   s v     +   R*      S U     J  Dc (  P\n  \r) -(  P  >  Gf	 9  _ 0    Tf \r-  9    7  &5  |=   B     .PR&F:=V     ` bRO Qb{      Ag       T     q-   }!  J    e      l oo*v 3Ab      e d     A   p     B        \n 1[       \"  6 8<  AY  ` N \\  D <    c , 2q d ?\n5 K f ,  Y  ,  -   q      c -< M   _   A p    `N~n)l |S  H e  _ R  O        KY B)%OT ,\nQd    3 (\"    /? 5 o(   f a 6   a n          C 6  ]T ! w q  ;    A k\":  |   \n   %Y_  H   G x i6V  Q    9 J  t &   x  {  C    z  [ ZB 7<              c 0e b   %      r  tMz!      j  > Tb   > )     ?`(1       5 J ^x    uC   n    =  L   d  S+t{\\+       kd w:]   \"  KzCX/^  u_y   U(  K S    /      ]6  ~   T      @V yL  ( iHe          { e           \r}/W =s     A GL `<       sO` r $3De D !   pP    ^P% J (8w\"     0   e / \n   e  xz    Y M  N  < A ( J  >r ,A      eN3  i a z d   t             `1D(   !     s   q 8U (E Z%> TiR      5    /   Ee $ Uv  /   P HHJ   (  De   \"    !  Zi      / u D  H g     )  !h +.o9     <  L  9 L  3     @U  <s$      \rIB \"   h\"  V  s   $@\"j   kw      %H  :       ~   3 \n    , eVQ    ^   ,V<5[     & ^  \rR   E  7 4  Y/F Z hI  E ;* o$    h    |( 4    .`   t     S      L b          T   3  P      R2  \r !     (Y     tQ9K  j  4    $m G 6a NY    D   5W (k   `   c6       `\r xR\n T     & U5        }      X FKd      p     J% j ) 0       t \'    4tF TrU q?\' 3    W     `   *    1 X (  y  m ] $U<gs       ( T Jm          ,     D < V      R  R (T  a  aDm K 	 t    Y  x  TB } +BP   ^  j\n  	    T    2  D\" l   al C j <}   nFW y \rU  S  p    1 DB   =w 3  K<`          2 D;1   L     3  Z{ Z  DQ  y  c  q  Y 3\' [V   H< lX   J     *      f  \" 0 =    {+ g\"          >  2    NZ T  :   s? +  w `N P 5a\n  I 8  T     n :         Jc^~L      \n     `Z     H   t! o 1   a 5   mH   0 l  A   g d=X, Ef    i q O     2     L G  B!w e\\  V !5  ! !    b  P,^9Kx   5  Qx     VLt y0J/   Zu   3C1d k \r   -1  y      u  =    R`m  WCf{$+      H 99 A B     +  p<    J   X   :      y \'  c  oCY  ` w b   \' G \'IXP 2 +	k  V  $h x  	     4q  R     WDTY2  4Y   	 & y      W        a!91     {  T(      U?  G    .   , (   3 .   $ _ J %Y w  5B,IM       X    !  Z{ v   7 d !   I-wp      ?e  wr  Y ~ d  K   T B K      2  2dA    >  %Ks   2   (   \"    qQ   7  r Y   , !i *%\rP   { J+G Bm  j   H    p  d     %Y   %;&    3 E 6  To	  r $.l t n1 T9    # G X\\    y   ! l> ~ F      \re  (\r      j D. R\n A    !   V n NG     #s T  U%)    x N    h  o  r  }} \"    \n 2  % FC   D(  l  /    % \" s   	     )/  i2HV|  Dq/   f  {T=      c    o s;      h  l    at       q   W   Z       y  * 1     a 	J  r { ^ ~\\B$ {gL     fM 8        A   s$  N YB  [Gd  p          byr    9/l  G-2/`s-_S+    2 d      bD  +  @reH  b7i/ C b ;w  ]    y g/ o    w U F  L    X        Gk )X X y[  Ecn\\,  B  	   q ~5  s  hUA     h9<  De	*$    5a!         &?w 6^  n\r  9;       Y   4 f  j    n #r 	 Z TI  p o`]   O     g\"     U  P    [{4  #  h   F  rN   D 7\\MG    +  c  6     \rH       t2  5\" `   a  D5  `  r          y?    P {  i2   H ,    ;a J  |}k  (kF F  +  K=M J ie%  kC/0\'+ K  z# ]   Qc   Kd\\T 0d   )YB 4 ~ /6 )     y p b      $XB2Z  \"[       y    R pp  % 5M E      ]  T = A  \nA  Rgc   <y  ) cN aB     n   5   Q    [     p     \" CqN F0C  Z   / [ 7L    MR t  dN !     y P5B  l ~   h f   k     2dk V qw   [  v   :kb   E   [N@   P   l \rH    c  N  8 a  &(1  k`  >     o n    =3 p     Q N   Z6      ; ` p  5  ^ Bf ? i ,  q[  xN n~ .\\         3s6  Wb       vws7   > L7   q   j?  q Fmr   - 5mE g\' \\ ^     R       :    @3  	 8J    H     M nf?	    w  N    b  i        f    ? 5>   f   \\=  Y0      %!S i U %<     t\\   #  T $  Y  \"	  KK    #B G  j o Y a  ,= g-P d    R   w       W ia8 X    u  )f.3H   ^ ^  x :    E{ d     d  ~  m O 5   z ~7          1  \r     a>  j        5V B $    Z|U#+m  { W5  V  ~cq   n   = @      & R X       P[ O  j&A    \r    lN  B 6  ce  _b `   ? Y e   m  B  * VB^    !}u 3 vI /M  3  ?\r    ?    %$ , |E     = R   `  pN  u)i  $  [    O 2q  j_\'     V 0  7*$     \' _  a R 5  T:O  6     B     B 2}   X\rF  y A        %  $   J P  K     4/ \' T1 du  = T8   s    (   2     z      O b\"k   )    %  | %  \n p~:     l    %      O  bHW.  w g h   @            % } X       w1    l    N  w           #      H   !        8-    DP R =OH)   \r^ ~Z   _ EbF Q 5      9M          Y X 2 v  X~    P    4       _$ 6 a   D\'3        D  H   V2    B|  ) T  {  ]q 7> / \rY 5  (    6r           D   \nk          j          !   8 z   bjPOo e  @<5 C\'     7        - c   A %  }6  M\" 6 |     \n Q  l,|+        s       d\r    kr   &}   (  bHV 1   AU @  A *) Y    7 MS@ \rCu +f !  y    S x <{Ab= 1Cv(oJv /l IV\n  $ E1  b  o|f Z P b     h=99         Dl N  v  /   Z	 4 T    c|  $  KF ,N  D(  9:  y  ]    =*	U  f  SF L [  z   }       e n    8     }  E9     \r\"    Z q  m#   {j     . Djw7 7\\          $      OU;   $(L& U    w  >  %_ bO>+J p8   7 <fW p  :XWnH     E  E<    $  P !    k l[ P   d   v  B m   ,Q      pG h<HL   % #C  ^&zf   kE  eqEr  Y0  !  = I     )  \nK  	ANG        \r Z  3  +        <G1J Y (  s   ^  ?/  5 R lOlA9 \" `      Eh`  l O  .` D\r     T]     < `    !  9 _ +   t;s8   ez   9O1L   R   G.     R -  O J( f         n   K K \\ 	 F ,   .l  W %  {	o* @  J   R1 +       gr -  &  1*0+w  m    9        o     83 h] &R *       Y ^ m{      c ^   n ~ G2  L G   - u     F        M^   I f   Z   g  OK  F  O \n2  $     e       \' `  *jd  1   7   ~   E    x a d*)  s6 aT    +r  2    E   d   t 8i  g  o  *      Y s X\nY  C;V@5b   `  `  >rX  {[T,aA\r  q  	 1 M  ;v+2   c  Wq rkf6  oK}         0   @!f         = 8{ z        m ,a-z =     JZA ^     \rl   F!:G    T2V   $\'b     g[  - 4    .  q  d a6Z| 9/N K  5  %   } d      46Am .  v W  B f -     bZz v @ U/ M    , |  ,   3 )rNE  J       m  #      q   q#s z       y   Whj N      S * T[  }   78<ASX\n  ,1>   \"W  [   &  q> b>    \' lu\"     j   R ^ j    h S   $;  !Z P      =   :n [ K@  \\9  ]L  JE  \"   \n [   %Zo R  7 .  s b& a  \'   a76    o c  B$   + sX    s        ~n6 Pe   L vk f4     ^h\"K$  ,  {   	R	  >   x\" 2~R]  ( ;    v      RH   G8H $kq  \'~ AH i&  H     _  _  ~;   \'z S 	 ^ snq   nw     n 5    C  v      @       ->  v v  C  i   p       >s  M  %  e 0 S    H   q  [7      5s;  X fYL Y U  E  S  \n\nReturn strictly valid JSON only:', '{\n  \"ats_score\": 0,\n  \"grade\": \"F\",\n  \"verdict\": \"Low ATS Compatibility — Insufficient Data\",\n  \"sub_scores\": {\n    \"readability\": 0,\n    \"keyword_optimization\": 0,\n    \"impact_metrics\": 0,\n    \"structure\": 0\n  },\n  \"candidate\": {\n    \"display_name\": \"\",\n    \"job_title\": \"\",\n    \"headline\": \"\",\n    \"bio\": \"\",\n    \"email\": \"\",\n    \"phone\": \"\",\n    \"location\": \"\",\n    \"company\": \"\",\n    \"website\": \"\"\n  },\n  \"skills\": {\n    \"technical\": [],\n    \"strategic\": [],\n    \"tools\": []\n  },\n  \"services\": [],\n  \"portfolio_items\": [],\n  \"strengths\": [],\n  \"missing_keywords\": [],\n  \"actionable_improvements\": []\n}', 1, '2026-10-05 16:09:30', '{\"provider\": \"groq\", \"timestamp\": 1791220170}'),
(14, 2, 'text', 'You are a world-class Executive Recruiter and ATS (Applicant Tracking System) Algorithm Auditor for digital advertising and technology professionals on Adsbooster.net.\nAnalyze the provided resume and return ONLY a valid JSON object with NO markdown formatting, NO backticks, and NO conversational filler, matching this exact structure:\n{\n  \"ats_score\": 88,\n  \"grade\": \"A\",\n  \"verdict\": \"High ATS Compatibility — Interview Shortlist Potential\",\n  \"sub_scores\": {\n    \"readability\": 90,\n    \"keyword_optimization\": 85,\n    \"impact_metrics\": 88,\n    \"structure\": 92\n  },\n  \"candidate\": {\n    \"display_name\": \"Candidate Full Name\",\n    \"job_title\": \"Accurate Role or Professional Title\",\n    \"headline\": \"Compelling 1-sentence value proposition or positioning headline\",\n    \"bio\": \"High-impact 2-3 sentence executive bio highlighting quantifiable achievements\",\n    \"email\": \"Extracted email or empty\",\n    \"phone\": \"Extracted phone or empty\",\n    \"location\": \"City/Country or Remote\",\n    \"company\": \"Current or most recent agency/company\",\n    \"website\": \"Portfolio link or empty\"\n  },\n  \"skills\": {\n    \"technical\": [\"Skill 1\", \"Skill 2\", \"Skill 3\", \"Skill 4\"],\n    \"strategic\": [\"Skill 1\", \"Skill 2\", \"Skill 3\"],\n    \"tools\": [\"Tool 1\", \"Tool 2\", \"Tool 3\"]\n  },\n  \"services\": [\n    {\"title\": \"Core Offering 1\", \"price\": \"$2,500/month\", \"description\": \"Brief deliverable summary\"},\n    {\"title\": \"Core Offering 2\", \"price\": \"$750/campaign\", \"description\": \"Brief deliverable summary\"}\n  ],\n  \"portfolio_items\": [\n    {\"title\": \"Key Campaign or Project 1\", \"metric\": \"e.g. 4.8x ROAS or +$180K GMV\", \"description\": \"Specific result with action verb and scale\"},\n    {\"title\": \"Key Campaign or Project 2\", \"metric\": \"e.g. -42% CPA Reduction\", \"description\": \"Specific result with action verb and scale\"}\n  ],\n  \"strengths\": [\n    \"Clear quantification of commercial results and ROAS metrics\",\n    \"Strong domain expertise in modern advertising platforms\"\n  ],\n  \"missing_keywords\": [\n    \"Conversion API (CAPI)\",\n    \"First-Party Data Strategy\",\n    \"Omnichannel Attribution\"\n  ],\n  \"actionable_improvements\": [\n    \"Start all bullet points with active power verbs (e.g. Scaled, Orchestrated, Engineered).\",\n    \"Add specific monthly budget figures managed to demonstrate scale of responsibility.\"\n  ]\n}\n\n=== CANDIDATE RESUME ===\n%PDF-1.4 % 1 0 obj <</Title (JAMACHI MAURICE MAURICENNADI RESUME) /Producer (Skia/PDF m153 Google Docs Renderer)>> endobj 3 0 obj <</ca 1 /BM /Normal>> endobj 7 0 obj <</CA 1 /ca 1 /LC 0 /LJ 0 /LW 1.33333337 /ML 10 /SA true /BM /Normal>> endobj 8 0 obj <</Type /Annot /Subtype /Link /F 4 /Border [0 0 0] /Rect [323.33636 617.54999 474.89621 630.75] /A <</Type /Action /S /URI /URI (https://github.com/FushionHub)>> /StructParent 1>> endobj 9 0 obj <</Filter /FlateDecode /Length 12361>> stream x } % q p u! X ob` n & g 2F i >d , #| G B O ? ] ~ O <c | \'@ Q ~| w ?} ~ / ~ w P ? p >~ _ P! \" 0H > ) / H ~> / 7e A ~< B\\ Cn B a r w 9d r K *\\ | < H ~ yYV ! > P % P@ I S ( eQa x m~|C # \"z< B = c b j J f f i q t 0 ! n w; G- )> H g m+ jN r I R + < N \' MX vB 3r } 5 0@ GG @ 3$ , Jt] .H _Q 1 J \" H / C j`aLj (q :i L \\ v/| )*^ ?? >u eto 2I 4$ _ \' %i Y 3 w+~W d W \\V / M @b Z} >4L E ;\' 9 P & C * R UW we bj U=j J g sA W hr ,Q \\ %C,! : J< w \' N\" t & b*= { bN!E `L } ~ bB ,[w -$@% 8Iv Cs ;9 O z \' 8P B ZY yI1g\\ 8 _c 1 e s 8n J J ( 1 a ! 0- m ATr\\ y 9 @D 8 e^ x TL[ b ) wf B Sm ( ` b s v + R* S U J Dc ( P ) -( P > Gf 9 _ 0 Tf - 9 7 &5 |= B .PR&F:=V ` bRO Qb{ Ag T q- }! J e l oo*v 3Ab e d A p B 1[ \" 6 8< AY ` N \\ D < c , 2q d ? 5 K f , Y , - q c -< M _ A p `N~n)l |S H e _ R O KY B)%OT , Qd 3 (\" /? 5 o( f a 6 a n C 6 ]T ! w q ; A k\": | %Y_ H G x i6V Q 9 J t & x { C z [ ZB 7< c 0e b % r tMz! j > Tb > ) ?`(1 5 J ^x uC n = L d S+t{\\+ kd w:] \" KzCX/^ u_y U( K S / ]6 ~ T @V yL ( iHe { e }/W =s A GL `< sO` r $3De D ! pP ^P% J (8w\" 0 e / e xz Y M N < A ( J >r ,A eN3 i a z d t `1D( ! s q 8U (E Z%> TiR 5 / Ee $ Uv / P HHJ ( De \" ! Zi / u D H g ) !h +.o9 < L 9 L 3 @U <s$ IB \" h\" V s $@\"j kw %H : ~ 3 , eVQ ^ ,V<5[ & ^ R E 7 4 Y/F Z hI E ;* o$ h |( 4 .` t S L b T 3 P R2 ! (Y tQ9K j 4 $m G 6a NY D 5W (k ` c6 ` xR T & U5 } X FKd p J% j ) 0 t \' 4tF TrU q?\' 3 W ` * 1 X ( y m ] $U<gs ( T Jm , D < V R R (T a aDm K t Y x TB } +BP ^ j T 2 D\" l al C j <} nFW y U S p 1 DB =w 3 K<` 2 D;1 L 3 Z{ Z DQ y c q Y 3\' [V H< lX J * f \" 0 = {+ g\" > 2 NZ T : s? + w `N P 5a I 8 T n : Jc^~L `Z H t! o 1 a 5 mH 0 l A g d=X, Ef i q O 2 L G B!w e\\ V !5 ! ! b P,^9Kx 5 Qx VLt y0J/ Zu 3C1d k -1 y u = R`m WCf{$+ H 99 A B + p< J X : y \' c oCY ` w b \' G \'IXP 2 + k V $h x 4q R WDTY2 4Y & y W a!91 { T( U? G . , ( 3 . $ _ J %Y w 5B,IM X ! Z{ v 7 d ! I-wp ?e wr Y ~ d K T B K 2 2dA > %Ks 2 ( \" qQ 7 r Y , !i *% P { J+G Bm j H p d %Y %;& 3 E 6 To r $.l t n1 T9 # G X\\ y ! l> ~ F e ( j D. R A ! V n NG #s T U%) x N h o r }} \" 2 % FC D( l / % \" s )/ i2HV| Dq/ f {T= c o s; h l at q W Z y * 1 a J r { ^ ~\\B$ {gL fM 8 A s$ N YB [Gd p byr 9/l G-2/`s-_S+ 2 d bD + @reH b7i/ C b ;w ] y g/ o w U F L X Gk )X X y[ Ecn\\, B q ~5 s hUA h9< De *$ 5a! &?w 6^ n 9; Y 4 f j n #r Z TI p o`] O g\" U P [{4 # h F rN D 7\\MG + c 6 H t2 5\" ` a D5 ` r y? P { i2 H , ;a J |}k (kF F + K=M J ie% kC/0\'+ K z# ] Qc Kd\\T 0d )YB 4 ~ /6 ) y p b $XB2Z \"[ y R pp % 5M E ] T = A A Rgc <y ) cN aB n 5 Q [ p \" CqN F0C Z / [ 7L MR t dN ! y P5B l ~ h f k 2dk V qw [ v :kb E [N@ P l H c N 8 a &(1 k` > o n =3 p Q N Z6 ; ` p 5 ^ Bf ? i , q[ xN n~ .\\ 3s6 Wb vws7 > L7 q j? q Fmr - 5mE g\' \\ ^ R : @3 8J H M nf? w N b i f ? 5> f \\= Y0 %!S i U %< t\\ # T $ Y \" KK #B G j o Y a ,= g-P d R w W ia8 X u )f.3H ^ ^ x : E{ d d ~ m O 5 z ~7 1 a> j 5V B $ Z|U#+m { W5 V ~cq n = @ & R X P[ O j&A lN B 6 ce _b ` ? Y e m B * VB^ !}u 3 vI /M 3 ? ? %$ , |E = R ` pN u)i $ [ O 2q j_\' V 0 7*$ \' _ a R 5 T:O 6 B B 2} X F y A % $ J P K 4/ \' T1 du = T8 s ( 2 z O b\"k ) % | % p~: l % O bHW. w g h @ % } X w1 l N w # H ! 8- DP R =OH) ^ ~Z _ EbF Q 5 9M Y X 2 v X~ P 4 _$ 6 a D\'3 D H V2 B| ) T { ]q 7> / Y 5 ( 6r D k j ! 8 z bjPOo e @<5 C\' 7 - c A % }6 M\" 6 | Q l,|+ s d kr &} ( bHV 1 AU @ A *) Y 7 MS@ Cu +f ! y S x <{Ab= 1Cv(oJv /l IV $ E1 b o|f Z P b h=99 Dl N v / Z 4 T c| $ KF ,N D( 9: y ] =* U f SF L [ z } e n 8 } E9 \" Z q m# {j . Djw7 7\\ $ OU; $(L& U w > %_ bO>+J p8 7 <fW p :XWnH E E< $ P ! k l[ P d v B m ,Q pG h<HL % #C ^&zf kE eqEr Y0 ! = I ) K ANG Z 3 + <G1J Y ( s ^ ?/ 5 R lOlA9 \" ` Eh` l O .` D T] < ` ! 9 _ + t;s8 ez 9O1L R G. R - O J( f n K K \\ F , .l W % { o* @ J R1 + gr - & 1*0+w m 9 o 83 h] &R * Y ^ m{ c ^ n ~ G2 L G - u F M^ I f Z g OK F O 2 $ e \' ` *jd 1 7 ~ E x a d*) s6 aT +r 2 E d t 8i g o * Y s X Y C;V@5b ` ` >rX {[T,aA q 1 M ;v+2 c Wq rkf6 oK} 0 @!f = 8{ z m ,a-z = JZA ^ l F!:G T2V $\'b g[ - 4 . q d a6Z| 9/N K 5 % } d 46Am . v W B f - bZz v @ U/ M , | , 3 )rNE J m # q q#s z y Whj N S * T[ } 78<ASX ,1> \"W [ & q> b> \' lu\" j R ^ j h S $; !Z P = :n [ K@ \\9 ]L JE \" [ %Zo R 7 . s b& a \' a76 o c B$ + sX s ~n6 Pe L vk f4 ^h\"K$ , { R > x\" 2~R] ( ; v RH G8H $kq \'~ AH i& H _ _ ~; \'z S ^ snq nw n 5 C v @ -> v v C i p >s M % e 0 S H q [7 5s; X fYL Y U E S t! e C ` s V 9O %X x ;|J 7 ~ L ~%BP R yb- = Zt ] J 0a d o v* j $B eK} \' h C4 LY Rl 4X?s @ \"W g $ 0 D ; }j f r ~ u 4 )f P | lc b d_ u $ Y 76 XL 7 : 8U \"Zx b p F > \\!? uD <f o `IV K ^8 [ P `\\ N_[ R - r ` R13e $ fs 0: . tz>, o ` -! } 4 B$ H d 5 4 8 6 ^ y XU ~ ot R 9 { $`Rjh q 2 7 Hs U k g4! j T! uq0* <hq Qb\".i s $ f |^> [} Aw 4O y f- n O \\\' 2KH o ^o S 1Esk V \" \'n hxi& {WQ % lto 5k R ~w7 h Q /I X 0P= 7 /| b d 2j 9 6qi ; ;a w b ( sp hLsW f \\ D 5 vWh r % M M[ B K d \\f# k( Mr / $ 5 h b xT FA [ > &x B $Oa ? t \\_ It f T . V T % $8 [ s{ Z*\" v @, y $ JY L& fn f ; A d.{ 0F Hrk <E i V 7 ,l ^ F (1 r+ I$J yJO _= }9 u ?D j[( fl d 7 KZ4 <^C ! 1 Ik ><, 7 Y r % 3 s2 n o (j1 O ,{ k M 8 . Y ) I % L Q X y.H a g ~ o 7b F zn L !~ ! c r ,z-| > f H > ? ?| | o ? i a v] w z` _n\"T X Q*J TU w d4 $E5 zHG Q ; \\ sf & V 7 \\ D SF \\Red ; 2 ; JeS \\*T : / 2 # J / & Y% l * K { K ?^ hlp \\ 6 F ) 2 , KY $ L v D !hVyO B R #n s L .5n % }|* R V@ RC G* hz , v N ]5: =97 ~@ $< & T o ` zz o }| B! ?| /^ 9 j lxD ~ ~ c e p = 4 I j Y wD k | 3 MX~ qg b7 lA 2 Q S u| ` rj H5AV 4V I T sr cV^ ;\\ i i P L z \\ I b ^ [ M [ G ( + 6 Mo L9 R}vX ;J (X}?M - q A w F 3bZ) _ >{ O $%\\e =@V? ^w * 3 M BV C . % X O HkP j 7 U R /y 2(AA3 t F TE 6b / - q P H || / #- i 3 #- r X b B kw Q W] e ; p_ SO ~ = s n !ZXe tX QQ7\" jc ! $ ,X i [ | Ic3 s cyF 1 % pW ; $6N X )a D - % V n ; g@ <DH )M A X> _QOaU8 ^% @]} s 0 \" 9X *K % ] W g y- { a_ $k Jh* R XL a Vs !H 1-N t^M 5 4 Ih6v f %o (! h) T>?d ;/dk) h1 ![ ` u i x~ : \"B&3nfN 1 X w{[ p9o, q \\ . 5W $ D ! o XY\\ F 7 :[wtNi J } KgLQ X Y/ w.]J C$ IL ! <1 K p bOop p f: v D ; b h$D{p jJgM j=[ 2 Z ZI 7 9@\"Z e 9 O z cLS & Y* - C Q 4 D y Z Pb vy GC~}w \\ #i sy . P )P<um 1 z? r o \'^ 4 9) 4 f s s ] br = 7 7 j P s+ N B~ , o v E @ < a v uU !\' z < \' + 7 \' , < (K U^ G/ s ; _v KWwG 7l| d 6> V K _ F 1F <WH)CD P ) d X S ; I m,K F s 2 b C o u oz %L sa ] u% f \\ ` MC W VI w 5 [c >o-w\' h / N n \"hN O X W^ y a l ( r - }ukG &D S33\'dx di 9 ) w X D ] z P ]j m] J* 7 n1 % N{O % gb q y P a q X K a [Q\\ ]k 2rWO 1 X D +cz} Cr w CP[ ; { a 0 [$ K z 2 L * ` j` / KU t v?* z !v 7 =V~ Zw aq [ S l, Yz h =/ &w 79[5 P= 0 =f ` \" wSr H z / %.\\A_ PU h Wl I t6d o \' B { > 1*c - L E wXx * \\ Io Q ta y ^ j h < PJ o1 @ 8+ 6 6 B yH @ Z k y u {R2 aV7 4=x L od \". v ) h ku \\1 j7q^Z l G 9* / B o &s R 7\\> dHK\"b B e [ 4@K \" u I ? sU^ ~ [ X J ( xf U h * W \', G M \" f] Q N ULw ;% & f I ` YV ?n A #< ] ZV .= F =/ L D R + *h c \\ y} S vH: |P; d A L E b AU Et 4D\' fI ; +U >n Z$r 8 \" \' 7 - p yn Y ~9 2 ? cf B y p j YB a Zs C B ;^ - )z I 0 C yn J PA?v ~ B+b i,A uCU xP HZK a\" X x nb ? m_E 0 7 R >} 3 e w k _S2K r E?I7 K 3 , :~^ D6 V t ` ) N d H iK e AV E {V a kQ4F[ d. Y^ : { + [i $ . M` ( ] Eg 5y[ R U . + k)17 . R I ( T s =Fl ( 0 q w b %b W ; Nm kb M Hw2$ 5 2 kF (3 b X \' R @C 8 @N f_ ]% + l5 n _ 7 a t\" R; ZPARX d_ \\ .R : )]-[ 2 L Z\\c O B 5 (15 }9ug \\fZ u U w \'ON2(D u6} / s J& 8 kR B , . Y . X \n\nReturn strictly valid JSON only:', '{\n  \"ats_score\": 45,\n  \"grade\": \"C\",\n  \"verdict\": \"Low ATS Compatibility — Needs Optimization\",\n  \"sub_scores\": {\n    \"readability\": 30,\n    \"keyword_optimization\": 20,\n    \"impact_metrics\": 10,\n    \"structure\": 20\n  },\n  \"candidate\": {\n    \"display_name\": \"Jamachi Maurice Mauricennadi\",\n    \"job_title\": \"Digital Advertising Professional\",\n    \"headline\": \"Digital advertising specialist with experience in campaign execution\",\n    \"bio\": \"Seasoned professional with background in digital ad operations. Proven ability to manage campaigns across platforms.\",\n    \"email\": \"\",\n    \"phone\": \"\",\n    \"location\": \"Remote\",\n    \"company\": \"Freelance\",\n    \"website\": \"https://github.com/FushionHub\"\n  },\n  \"skills\": {\n    \"technical\": [],\n    \"strategic\": [],\n    \"tools\": []\n  },\n  \"services\": [],\n  \"portfolio_items\": [],\n  \"strengths\": [\n    \"Potential domain expertise in digital advertising\"\n  ],\n  \"missing_keywords\": [\n    \"Conversion API (CAPI)\",\n    \"First-Party Data Strategy\",\n    \"Omnichannel Attribution\"\n  ],\n  \"actionable_improvements\": [\n    \"Convert PDF to text and include clear bullet points with quantifiable results.\",\n    \"Add contact information and specific platform experience.\"\n  ]\n}', 1, '2026-10-05 16:10:34', '{\"provider\": \"groq\", \"timestamp\": 1791220234}'),
(15, 3, 'text', 'You are a world-class Executive Recruiter and ATS (Applicant Tracking System) Algorithm Auditor for digital advertising and technology professionals on Adsbooster.net.\nAnalyze the provided resume and return ONLY a valid JSON object with NO markdown formatting, NO backticks, and NO conversational filler, matching this exact structure:\n{\n  \"ats_score\": 88,\n  \"grade\": \"A\",\n  \"verdict\": \"High ATS Compatibility — Interview Shortlist Potential\",\n  \"sub_scores\": {\n    \"readability\": 90,\n    \"keyword_optimization\": 85,\n    \"impact_metrics\": 88,\n    \"structure\": 92\n  },\n  \"candidate\": {\n    \"display_name\": \"Candidate Full Name\",\n    \"job_title\": \"Accurate Role or Professional Title\",\n    \"headline\": \"Compelling 1-sentence value proposition or positioning headline\",\n    \"bio\": \"High-impact 2-3 sentence executive bio highlighting quantifiable achievements\",\n    \"email\": \"Extracted email or empty\",\n    \"phone\": \"Extracted phone or empty\",\n    \"location\": \"City/Country or Remote\",\n    \"company\": \"Current or most recent agency/company\",\n    \"website\": \"Portfolio link or empty\"\n  },\n  \"skills\": {\n    \"technical\": [\"Skill 1\", \"Skill 2\", \"Skill 3\", \"Skill 4\"],\n    \"strategic\": [\"Skill 1\", \"Skill 2\", \"Skill 3\"],\n    \"tools\": [\"Tool 1\", \"Tool 2\", \"Tool 3\"]\n  },\n  \"services\": [\n    {\"title\": \"Core Offering 1\", \"price\": \"$2,500/month\", \"description\": \"Brief deliverable summary\"},\n    {\"title\": \"Core Offering 2\", \"price\": \"$750/campaign\", \"description\": \"Brief deliverable summary\"}\n  ],\n  \"portfolio_items\": [\n    {\"title\": \"Key Campaign or Project 1\", \"metric\": \"e.g. 4.8x ROAS or +$180K GMV\", \"description\": \"Specific result with action verb and scale\"},\n    {\"title\": \"Key Campaign or Project 2\", \"metric\": \"e.g. -42% CPA Reduction\", \"description\": \"Specific result with action verb and scale\"}\n  ],\n  \"strengths\": [\n    \"Clear quantification of commercial results and ROAS metrics\",\n    \"Strong domain expertise in modern advertising platforms\"\n  ],\n  \"missing_keywords\": [\n    \"Conversion API (CAPI)\",\n    \"First-Party Data Strategy\",\n    \"Omnichannel Attribution\"\n  ],\n  \"actionable_improvements\": [\n    \"Start all bullet points with active power verbs (e.g. Scaled, Orchestrated, Engineered).\",\n    \"Add specific monthly budget figures managed to demonstrate scale of responsibility.\"\n  ]\n}\n\n=== CANDIDATE RESUME ===\nAlex Rivera\nSenior Omnichannel Media Buyer & Creative Strategist\nEmail: alex.rivera@adsbooster.net | Phone: +1 (555) 019-2831 | New York, NY / Remote\nPortfolio: https://adsbooster.net/portfolio.php?u=alexrivera\n\nSUMMARY:\nResults-driven Performance Marketing Director with 6+ years orchestrating profitable omnichannel ad campaigns across Meta Ads, TikTok Ads, and Google Ads. Managed over $3.2M in annual ad spend, delivering an average blended ROAS of 4.4x for fast-growing DTC eCommerce and B2B SaaS brands. Expert in UGC creative iteration, Landing Page CRO, and full-funnel attribution modeling.\n\nCORE SKILLS:\nMeta Ads Manager, TikTok Ads Manager, Google Performance Max, UGC Creative Testing, Copywriting, Conversion Rate Optimization (CRO), Shopify Plus, Triple Whale Attribution, Klaviyo Retention Marketing, Budget Allocation.\n\nPROVEN CAMPAIGN HIGHLIGHTS:\n1. Omnichannel DTC Apparel Brand Scaling: Scaled monthly ad spend from $14k to $145k across Meta and TikTok while increasing blended ROAS from 3.1x to 4.8x.\n2. B2B SaaS Acquisition Sprint: Revamped creative hooks and landing page sales copy, slashing cost-per-qualified-lead (CPA) by 41% and driving $320k in pipeline value.\n\nSERVICES OFFERED:\n- Full Omnichannel Media Buying Retainer: $2,500/month\n- High-Converting UGC Creative Testing Sprint: $750/campaign\n- Paid Ads Account & CRO Audit: $450/audit\n\nReturn strictly valid JSON only:', '{\n  \"ats_score\": 90,\n  \"grade\": \"A\",\n  \"verdict\": \"High ATS Compatibility — Interview Shortlist Potential\",\n  \"sub_scores\": {\n    \"readability\": 92,\n    \"keyword_optimization\": 86,\n    \"impact_metrics\": 90,\n    \"structure\": 94\n  },\n  \"candidate\": {\n    \"display_name\": \"Alex Rivera\",\n    \"job_title\": \"Senior Omnichannel Media Buyer & Creative Strategist\",\n    \"headline\": \"Driving 4.4x blended ROAS across Meta, TikTok, and Google for DTC and SaaS brands.\",\n    \"bio\": \"Performance Marketing Director with 6+ years of experience scaling ad spend to $3.2M annually while delivering an average 4.4x ROAS. Expert at orchestrating omnichannel campaigns, UGC creative iteration, and full‑funnel attribution that generate multimillion‑dollar pipeline and cut CPA by 41%. Proven leader in CRO, budget allocation, and data‑driven creative strategy.\",\n    \"email\": \"alex.rivera@adsbooster.net\",\n    \"phone\": \"+1 (555) 019-2831\",\n    \"location\": \"New York, NY / Remote\",\n    \"company\": \"Adsbooster.net\",\n    \"website\": \"https://adsbooster.net/portfolio.php?u=alexrivera\"\n  },\n  \"skills\": {\n    \"technical\": [\"Meta Ads Manager\", \"TikTok Ads Manager\", \"Google Performance Max\", \"UGC Creative Testing\"],\n    \"strategic\": [\"Full‑funnel Attribution Modeling\", \"Creative Strategy\", \"Budget Allocation\"],\n    \"tools\": [\"Meta Ads Manager\", \"TikTok Ads Manager\", \"Google Ads\", \"Triple Whale\", \"Klaviyo\"]\n  },\n  \"services\": [\n    {\n      \"title\": \"Full Omnichannel Media Buying Retainer\",\n      \"price\": \"$2,500/month\",\n      \"description\": \"End‑to‑end media buying, budget scaling, and performance optimization across Meta, TikTok, and Google.\"\n    },\n    {\n      \"title\": \"High-Converting UGC Creative Testing Sprint\",\n      \"price\": \"$750/campaign\",\n      \"description\": \"Rapid ideation, production, and A/B testing of user‑generated content to boost ROAS.\"\n    }\n  ],\n  \"portfolio_items\": [\n    {\n      \"title\": \"Omnichannel DTC Apparel Brand Scaling\",\n      \"metric\": \"4.8x ROAS (+45% YoY)\",\n      \"description\": \"Scaled monthly spend from $14K to $145K while increasing blended ROAS from 3.1x to 4.', 1, '2026-10-05 16:25:06', '{\"provider\": \"groq\", \"timestamp\": 1791221106}'),
(16, 2, 'image', 'Raw authentic UGC photo of me. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for women from 23-28. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/localhost\\/assets\\/images\\/thumbs\\/team-details-img2.png\",\"product_name\":\"me\",\"ugc_style\":\"selfie_hold\",\"creator_persona\":\"gen_z\",\"aspect_ratio\":\"1:1\",\"width\":1024,\"height\":1024,\"seed\":719991,\"hook_headline\":\"Fullstack Software Engineer, AI \\/ ML Engineer.\",\"ad_copy\":\"Grab yours today with fast shipping and 100% satisfaction guarantee!\",\"badge_text\":\"\\ud83d\\udd25 50% OFF TODAY ONLY\",\"image_prompt\":\"Raw authentic UGC photo of me. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for women from 23-28. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-10-05 18:49:33\",\"image_source\":\"local-fallback\"}', 5, '2026-10-05 17:49:33', '{\"provider\": \"flux-pollinations-ai\", \"timestamp\": 1791226173}'),
(17, 2, 'text', 'me okay', '✨ **High-Converting Ad Campaign Copy:**\n\n🎯 **Headline:** Unlock Unstoppable Growth with me okay\n\n📢 **Primary Text:** Stop burning marketing budget on low-converting clicks. With Adsbooster.net, launch high-ROAS campaigns across Meta, TikTok, and Google Ads from one unified dashboard.\n\n🔥 **Key Hook:** Guaranteed lower CPA, 1-click creative split testing, and verified audience segments.\n\n👉 **Call to Action:** Tap below to claim your verified listing or boost your first campaign today!', 1, '2026-10-05 19:15:46', '{\"provider\": \"adsbooster-heuristic\", \"timestamp\": 1791231346}'),
(18, 2, 'text', 'me okay', '✨ **High-Converting Ad Campaign Copy:**\n\n🎯 **Headline:** Unlock Unstoppable Growth with me okay\n\n📢 **Primary Text:** Stop burning marketing budget on low-converting clicks. With Adsbooster.net, launch high-ROAS campaigns across Meta, TikTok, and Google Ads from one unified dashboard.\n\n🔥 **Key Hook:** Guaranteed lower CPA, 1-click creative split testing, and verified audience segments.\n\n👉 **Call to Action:** Tap below to claim your verified listing or boost your first campaign today!', 1, '2026-10-05 19:16:08', '{\"provider\": \"adsbooster-heuristic\", \"timestamp\": 1791231368}'),
(19, 1, 'image', 'Raw authentic UGC photo of AuraWave ANC Pro Wireless Earbuds. tech enthusiast in modern ambient LED studio with sleek gear. chic content creator desk setup, glowing monitor in background, trendy ring light reflection, high-end creator reviewing the product with passion. Targeted for Audiophiles & remote workers needing active noise cancellation. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/localhost\\/assets\\/images\\/thumbs\\/blog-details-img2.png\",\"product_name\":\"AuraWave ANC Pro Wireless Earbuds\",\"ugc_style\":\"influencer_desk\",\"creator_persona\":\"tech_reviewer\",\"aspect_ratio\":\"9:16\",\"width\":768,\"height\":1344,\"seed\":315894,\"hook_headline\":\"I threw out my $300 headphones for these\",\"ad_copy\":\"Grab yours today with fast shipping and 100% satisfaction guarantee!\",\"badge_text\":\"\\ud83c\\udfc6 #1 Bestseller in 2026\",\"image_prompt\":\"Raw authentic UGC photo of AuraWave ANC Pro Wireless Earbuds. tech enthusiast in modern ambient LED studio with sleek gear. chic content creator desk setup, glowing monitor in background, trendy ring light reflection, high-end creator reviewing the product with passion. Targeted for Audiophiles & remote workers needing active noise cancellation. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-10-11 16:14:22\",\"image_source\":\"local-fallback\"}', 5, '2026-10-11 15:14:22', '{\"provider\": \"flux-pollinations-ai\", \"timestamp\": 1791735262}'),
(20, 1, 'image', 'Raw authentic UGC photo of AuraWave ANC Pro Wireless Earbuds. tech enthusiast in modern ambient LED studio with sleek gear. chic content creator desk setup, glowing monitor in background, trendy ring light reflection, high-end creator reviewing the product with passion. Targeted for Audiophiles & remote workers needing active noise cancellation. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/localhost\\/assets\\/images\\/thumbs\\/about-five-img1.png\",\"product_name\":\"AuraWave ANC Pro Wireless Earbuds\",\"ugc_style\":\"influencer_desk\",\"creator_persona\":\"tech_reviewer\",\"aspect_ratio\":\"9:16\",\"width\":768,\"height\":1344,\"seed\":875350,\"hook_headline\":\"I threw out my $300 headphones for these\",\"ad_copy\":\"Grab yours today with fast shipping and 100% satisfaction guarantee!\",\"badge_text\":\"\\ud83c\\udfc6 #1 Bestseller in 2026\",\"image_prompt\":\"Raw authentic UGC photo of AuraWave ANC Pro Wireless Earbuds. tech enthusiast in modern ambient LED studio with sleek gear. chic content creator desk setup, glowing monitor in background, trendy ring light reflection, high-end creator reviewing the product with passion. Targeted for Audiophiles & remote workers needing active noise cancellation. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-10-11 16:14:27\",\"image_source\":\"local-fallback\"}', 5, '2026-10-11 15:14:27', '{\"provider\": \"flux-pollinations-ai\", \"timestamp\": 1791735267}'),
(21, 100000, 'image', 'Raw authentic UGC photo of Lumina Glow Serum. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for Adults 25-45. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/localhost\\/assets\\/images\\/thumbs\\/team-details-img2.png\",\"product_name\":\"Lumina Glow Serum\",\"ugc_style\":\"selfie_hold\",\"creator_persona\":\"gen_z\",\"aspect_ratio\":\"9:16\",\"width\":768,\"height\":1344,\"seed\":439974,\"hook_headline\":\"My skin in 14 days\",\"ad_copy\":\"Capture the glow you deserve\\u2014just snap a selfie holding Lumina Glow Serum and watch your skin shine brighter than ever. Say goodbye to dullness and hello to a flawless, Instagram\\u2011ready complexion in just weeks.\",\"badge_text\":\"Top Rated\",\"image_prompt\":\"Raw authentic UGC photo of Lumina Glow Serum. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for Adults 25-45. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-10-12 12:43:58\",\"image_source\":\"local-fallback\"}', 5, '2026-10-12 11:43:58', '{\"provider\": \"flux-pollinations-ai\", \"timestamp\": 1791809038}'),
(22, 100000, 'image', 'Raw authentic UGC photo of Lumina Glow Serum. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for Adults 25-45. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/localhost\\/assets\\/images\\/thumbs\\/blog-details-img2.png\",\"product_name\":\"Lumina Glow Serum\",\"ugc_style\":\"selfie_hold\",\"creator_persona\":\"gen_z\",\"aspect_ratio\":\"9:16\",\"width\":768,\"height\":1344,\"seed\":228134,\"hook_headline\":\"My skin in 14 days\",\"ad_copy\":\"Grab yours today with fast shipping and 100% satisfaction guarantee!\",\"badge_text\":\"Top Rated\",\"image_prompt\":\"Raw authentic UGC photo of Lumina Glow Serum. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for Adults 25-45. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-10-12 12:50:23\",\"image_source\":\"local-fallback\"}', 5, '2026-10-12 11:50:23', '{\"provider\": \"flux-pollinations-ai\", \"timestamp\": 1791809423}'),
(23, 100000, 'image', 'Raw authentic UGC photo of AquaBottle Pro. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. satisfying tabletop unboxing aesthetic on a modern wooden desk, crisp studio lighting, unboxed product in focus, aesthetically pleasing minimal arrangement, high conversion e-commerce creative. Targeted for Students. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/localhost\\/assets\\/images\\/thumbs\\/about-five-img1.png\",\"product_name\":\"AquaBottle Pro\",\"ugc_style\":\"unboxing\",\"creator_persona\":\"gen_z\",\"aspect_ratio\":\"9:16\",\"width\":768,\"height\":1344,\"seed\":447096,\"hook_headline\":\"My skin in 14 days\",\"ad_copy\":\"I just ripped open the AquaBottle Pro and the sleek, leak\\u2011proof design blew my mind\\u2014perfect for marathon study sessions and campus workouts. Stay refreshed, stay focused, and let every sip power your next A+.\",\"badge_text\":\"Top Rated\",\"image_prompt\":\"Raw authentic UGC photo of AquaBottle Pro. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. satisfying tabletop unboxing aesthetic on a modern wooden desk, crisp studio lighting, unboxed product in focus, aesthetically pleasing minimal arrangement, high conversion e-commerce creative. Targeted for Students. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-10-12 12:50:59\",\"image_source\":\"local-fallback\"}', 5, '2026-10-12 11:50:59', '{\"provider\": \"flux-pollinations-ai\", \"timestamp\": 1791809459}'),
(24, 1, 'image', 'Raw authentic UGC photo of me. modern entrepreneur in minimalist smart casual attire, modern office atmosphere. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for . Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/localhost\\/assets\\/images\\/thumbs\\/team-details-img2.png\",\"product_name\":\"me\",\"ugc_style\":\"selfie_hold\",\"creator_persona\":\"saas_founder\",\"aspect_ratio\":\"1:1\",\"width\":1024,\"height\":1024,\"seed\":391558,\"hook_headline\":\"Why everyone on my feed is obsessing over this right now \\ud83d\\udc47\",\"ad_copy\":\"Grab yours today with fast shipping and 100% satisfaction guarantee!\",\"badge_text\":\"\\ud83d\\ude9a Free Express Shipping Worldwide\",\"image_prompt\":\"Raw authentic UGC photo of me. modern entrepreneur in minimalist smart casual attire, modern office atmosphere. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for . Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-10-13 16:21:19\",\"image_source\":\"local-fallback\"}', 5, '2026-10-13 15:21:19', '{\"provider\": \"flux-pollinations-ai\", \"timestamp\": 1791908479}'),
(25, 100000, 'text', 'Reply with the single word: ok', '✨ **High-Converting Ad Campaign Copy:**\n\n🎯 **Headline:** Unlock Unstoppable Growth with Reply with the single word: ok\n\n📢 **Primary Text:** Stop burning marketing budget on low-converting clicks. With Adsbooster.net, launch high-ROAS campaigns across Meta, TikTok, and Google Ads from one unified dashboard.\n\n🔥 **Key Hook:** Guaranteed lower CPA, 1-click creative split testing, and verified audience segments.\n\n👉 **Call to Action:** Tap below to claim your verified listing or boost your first campaign today!', 1, '2026-10-13 16:32:47', '{\"provider\": \"adsbooster-heuristic\", \"timestamp\": 1791912767}'),
(26, 100000, 'text', 'Reply with the single word: ok', 'ok', 1, '2026-10-13 16:37:32', '{\"provider\": \"groq\", \"timestamp\": 1791913052}'),
(27, 100000, 'image', 'Raw authentic UGC photo of TestWidget. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for Young adults. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.', '{\"image_url\":\"http:\\/\\/127.0.0.1\\/seopp\\/assets\\/images\\/thumbs\\/about-five-img1.png\",\"product_name\":\"TestWidget\",\"ugc_style\":\"selfie_hold\",\"creator_persona\":\"gen_z\",\"aspect_ratio\":\"1:1\",\"width\":1024,\"height\":1024,\"seed\":12345,\"hook_headline\":\"Stop scrolling\",\"ad_copy\":\"Just grabbed my TestWidget and it turned my ordinary selfie game into a vibe\\u2014instant glow, zero hassle. Grab yours now and level up your feed.\",\"badge_text\":\"Top Rated\",\"image_prompt\":\"Raw authentic UGC photo of TestWidget. trendy Gen-Z creator with casual streetwear, energetic vibrant vibe. authentic UGC iPhone selfie angle of a satisfied customer smiling and holding the product in hand, natural sunlight, depth of field, real skin texture, authentic organic social media photo. Targeted for Young adults. Hyper-detailed, photorealistic, cinematic commercial lighting, 8k resolution, shot on 35mm lens, award-winning ad creative.\",\"provider\":\"local-fallback\",\"created_at\":\"2026-10-17 04:25:26\"}', 5, '2026-10-17 03:25:26', '{\"provider\": \"local-fallback\", \"timestamp\": 1792211126}'),
(28, 100000, 'text', 'Write a punchy Instagram caption for our new eco-friendly water bottle that keeps drinks cold 24 hours', '💧❄️ Stay cool, stay green! Our eco‑friendly bottle keeps your drink ice‑cold for 24️⃣ hours—no waste, no worries. 🌿✨ Sip sustainably, slay the heat. #ColdAllDay #EcoHydration #ZeroWaste #StayRefreshed 🌎💙 Tap the link in bio to grab yours!', 1, '2026-10-17 17:14:15', '{\"provider\": \"groq\", \"timestamp\": 1792260855}'),
(29, 100000, 'text', 'Short Twitter take: AI ads save small businesses 10 hours a week', '🚀 **AI‑Powered Ads = +10 hrs/week for your small biz!**  \nNo more endless copy‑writing, split‑testing, or budget guesswork—our smart platform does it all in seconds.  \n\n🔹 Create, launch & optimize in 1 click  \n🔹 Free up time for customers, products, YOU  \n🔹 Boost ROI while you reclaim your day  \n\n💡 **Ready to win back 10 hours?** Try AdsBooster free for 14 days → [adsbooster.net/quickstart]  \n\n#SmallBiz #AIAds #TimeIsMoney #MarketingAutomation 🚀', 1, '2026-10-17 17:15:29', '{\"provider\": \"groq\", \"timestamp\": 1792260929}');

-- --------------------------------------------------------

--
-- Table structure for table `ai_media_buyer_logs`
--

DROP TABLE IF EXISTS `ai_media_buyer_logs`;
CREATE TABLE `ai_media_buyer_logs` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `campaign_id` int DEFAULT NULL,
  `rule_id` int DEFAULT NULL,
  `action_taken` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `details` text COLLATE latin1_swedish_ci,
  `metrics_snapshot` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ai_media_buyer_rules`
--

DROP TABLE IF EXISTS `ai_media_buyer_rules`;
CREATE TABLE `ai_media_buyer_rules` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `campaign_id` int DEFAULT NULL,
  `rule_name` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `condition_metric` enum('cpa','ctr','roas','spend_without_conv','frequency') COLLATE latin1_swedish_ci NOT NULL,
  `condition_operator` enum('>','<','>=','<=') COLLATE latin1_swedish_ci NOT NULL,
  `condition_value` decimal(10,2) NOT NULL,
  `action_type` enum('pause_campaign','scale_budget_pct','reduce_budget_pct','trigger_creative_refresh','notify_only') COLLATE latin1_swedish_ci NOT NULL,
  `action_value` decimal(10,2) DEFAULT '0.00',
  `is_active` tinyint(1) DEFAULT '1',
  `last_triggered_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ai_media_buyer_rules`
--

INSERT INTO `ai_media_buyer_rules` (`id`, `user_id`, `campaign_id`, `rule_name`, `condition_metric`, `condition_operator`, `condition_value`, `action_type`, `action_value`, `is_active`, `last_triggered_at`, `created_at`) VALUES
(1, 2, NULL, '🚨 Anti-Burn: Pause if CPA > $30 after spend', 'cpa', '>', 30.00, 'pause_campaign', 0.00, 1, NULL, '2026-10-05 17:19:36'),
(2, 2, NULL, '⚡ Auto-Scale: Boost Winner Budget +20% if ROAS > 3.0', 'roas', '>=', 3.00, 'scale_budget_pct', 20.00, 1, NULL, '2026-10-05 17:19:36'),
(3, 2, NULL, '📉 Stop Fatigue: Reduce Budget -25% if CTR < 0.8%', 'ctr', '<', 0.80, 'reduce_budget_pct', 25.00, 1, NULL, '2026-10-05 17:19:36'),
(4, 2, NULL, '🔄 Creative Refresh: Trigger AI Variant if Spend > $50 with 0 Conv', 'spend_without_conv', '>=', 50.00, 'trigger_creative_refresh', 0.00, 1, NULL, '2026-10-05 17:19:36'),
(5, 1, NULL, '🚨 Anti-Burn: Pause if CPA > $30 after spend', 'cpa', '>', 30.00, 'pause_campaign', 0.00, 1, NULL, '2026-10-15 08:29:16'),
(6, 1, NULL, '⚡ Auto-Scale: Boost Winner Budget +20% if ROAS > 3.0', 'roas', '>=', 3.00, 'scale_budget_pct', 20.00, 1, NULL, '2026-10-15 08:29:16'),
(7, 1, NULL, '📉 Stop Fatigue: Reduce Budget -25% if CTR < 0.8%', 'ctr', '<', 0.80, 'reduce_budget_pct', 25.00, 1, NULL, '2026-10-15 08:29:16');

-- --------------------------------------------------------

--
-- Table structure for table `ai_video_creatives`
--

DROP TABLE IF EXISTS `ai_video_creatives`;
CREATE TABLE `ai_video_creatives` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `avatar_id` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `voice_id` varchar(100) COLLATE latin1_swedish_ci DEFAULT 'en_female_energetic',
  `hook_text` varchar(500) COLLATE latin1_swedish_ci NOT NULL,
  `script_body` text COLLATE latin1_swedish_ci NOT NULL,
  `cta_text` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `caption_style` varchar(100) COLLATE latin1_swedish_ci DEFAULT 'tiktok_glow',
  `broll_keyword` varchar(255) COLLATE latin1_swedish_ci DEFAULT 'lifestyle unboxing',
  `audio_track` varchar(255) COLLATE latin1_swedish_ci DEFAULT 'viral_lofi_beat',
  `video_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `thumbnail_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `aspect_ratio` varchar(20) COLLATE latin1_swedish_ci DEFAULT '9:16',
  `duration_seconds` int DEFAULT '20',
  `status` enum('queued','generating','rendering_client','completed','failed') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'queued',
  `credits_used` int DEFAULT '3',
  `error_message` text COLLATE latin1_swedish_ci,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `completed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ai_video_creatives`
--

INSERT INTO `ai_video_creatives` (`id`, `user_id`, `avatar_id`, `voice_id`, `hook_text`, `script_body`, `cta_text`, `caption_style`, `broll_keyword`, `audio_track`, `video_url`, `thumbnail_url`, `aspect_ratio`, `duration_seconds`, `status`, `credits_used`, `error_message`, `metadata`, `created_at`, `completed_at`) VALUES
(1, 1, 'commercial_cinematic', 'en_female_energetic', 'jmn — Cinematic Commercial', 'Here is the truth: It saves hours of frustration and delivers exactly what it promised without any guesswork.', 'Order Now at jmn', 'tiktok_glow', 'lifestyle unboxing', 'viral_lofi_beat', 'assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', 'assets/images/thumbs/project-details-img1.png', '9:16', 30, 'completed', 3, NULL, '{\"vibe\": \"High-Production Commercial\", \"frame_rate\": 60, \"resolution\": \"1080x1920\", \"video_type\": \"commercial_cinematic\", \"avatar_name\": \"Cinematic AI Director\", \"generated_at\": \"2026-10-05T18:36:51+00:00\"}', '2026-10-05 18:36:51', NULL),
(2, 2, 'lexi_genz', 'en_female_energetic', 'Okay, honest review time. Is creame actually worth the hype?', 'Let me break down why this is blowing up. Problem one: traditional methods take hours and cost a fortune. Problem two: they fail when you need them most. But with creame, . First, setup is under 60 seconds. Second, the automated workflow is so smooth it runs in the background. Third, you get 24/7 dedicated support that actually answers.', 'Check out the link in bio right now for an exclusive discount!', 'tiktok_glow', 'lifestyle unboxing', 'viral_lofi_beat', 'assets/videos/ugc_9cf5e4d10c9ebc2f2d7d4addbdab1712.mp4', 'assets/images/thumbs/client-img1.png', '9:16', 60, 'completed', 5, NULL, '{\"vibe\": \"Energetic, authentic, fast-paced, high energy\", \"frame_rate\": 60, \"resolution\": \"1080x1920\", \"video_type\": \"ugc_talking_head\", \"avatar_name\": \"Lexi R.\", \"generated_at\": \"2026-10-05T18:38:32+00:00\"}', '2026-10-05 18:38:32', NULL),
(3, 1, 'commercial_cinematic', 'en_female_energetic', 'jmn — Cinematic Commercial', 'Here is the truth: It saves hours of frustration and delivers exactly what it promised without any guesswork.', 'Order Now at jmn', 'tiktok_glow', 'lifestyle unboxing', 'viral_lofi_beat', 'assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', 'assets/images/thumbs/project-details-img1.png', '9:16', 30, 'completed', 3, NULL, '{\"vibe\": \"High-Production Commercial\", \"frame_rate\": 60, \"resolution\": \"1080x1920\", \"video_type\": \"commercial_cinematic\", \"avatar_name\": \"Cinematic AI Director\", \"generated_at\": \"2026-10-05T18:39:19+00:00\"}', '2026-10-05 18:39:19', NULL),
(4, 2, 'commercial_cinematic', 'en_female_energetic', 'cream — Cinematic Commercial', 'Product Commercial', 'Order Now at cream', 'tiktok_glow', 'lifestyle unboxing', 'viral_lofi_beat', 'assets/videos/ugc_3f5c66d09bb3cdae3c65c4cf9585552f.mp4', 'assets/images/thumbs/project-details-img1.png', '9:16', 30, 'completed', 3, NULL, '{\"vibe\": \"High-Production Commercial\", \"frame_rate\": 60, \"resolution\": \"1080x1920\", \"video_type\": \"commercial_cinematic\", \"avatar_name\": \"Cinematic AI Director\", \"generated_at\": \"2026-10-05T18:40:39+00:00\"}', '2026-10-05 18:40:39', NULL),
(5, 2, 'marcus_saas', 'en_female_energetic', 'I almost didn\'t post this, but this one thing completely changed how I use bright.', 'Let me break down why this is blowing up. Problem one: traditional methods take hours and cost a fortune. Problem two: they fail when you need them most. But with bright, . First, setup is under 60 seconds. Second, the automated workflow is so smooth it runs in the background. Third, you get 24/7 dedicated support that actually answers.', 'Tap below to test it risk-free today and see the results for yourself.', 'tiktok_glow', 'lifestyle unboxing', 'corporate_ambient', 'assets/videos/ugc_96438d9db25649eaa5cca589dd0c3a41.mp4', 'assets/images/thumbs/team-img1.png', '9:16', 80, 'completed', 8, NULL, '{\"vibe\": \"Authoritative, sharp, trustworthy, corporate-modern\", \"frame_rate\": 60, \"resolution\": \"1080x1920\", \"video_type\": \"ugc_talking_head\", \"avatar_name\": \"Marcus Vance\", \"generated_at\": \"2026-10-07T18:24:51+00:00\"}', '2026-10-07 18:24:51', NULL),
(6, 2, 'commercial_cinematic', 'en_female_energetic', 'Brand Commercial — Cinematic Commercial', 'Product Commercial', 'Order Now at Brand Commercial', 'tiktok_glow', 'lifestyle unboxing', 'viral_lofi_beat', 'assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', 'assets/images/thumbs/project-details-img1.png', '16:9', 30, 'completed', 3, NULL, '{\"vibe\": \"High-Production Commercial\", \"frame_rate\": 60, \"resolution\": \"1920x1080\", \"video_type\": \"commercial_cinematic\", \"avatar_name\": \"Cinematic AI Director\", \"generated_at\": \"2026-10-07T18:25:14+00:00\"}', '2026-10-07 18:25:14', NULL),
(10, 100000, 'lexi_genz', 'en_female_energetic', 'My dark spots vanished in 14 days', 'I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.', 'Tap to try it yourself', 'tiktok_glow', '', 'viral_lofi_beat', '', 'uploads/videos/scenes/scene_405903_1.jpg', '9:16', 30, 'rendering_client', 3, NULL, '{\"seed\": 405903, \"scenes\": [{\"act\": \"hook\", \"pan\": \"right\", \"label\": \"HOOK\", \"start\": 0, \"length\": 8, \"timing\": \"0:00 - 0:08\", \"caption\": \"My dark spots vanished in 14 days\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/about-five-img1.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_405903_1.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_405903_1.jpg\", \"scene_number\": 1, \"visual_prompt\": \"Authentic UGC style shot of a person holding and reacting to a product, direct to camera, Energetic, authentic, fast-paced, high energy, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, shot on 35mm, natural skin texture, no text, no logo, no watermark\"}, {\"act\": \"body\", \"pan\": \"left\", \"label\": \"BODY\", \"start\": 8, \"length\": 17, \"timing\": \"0:08 - 0:25\", \"caption\": \"I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.\", \"zoom_to\": 1, \"image_url\": \"http://localhost/assets/images/thumbs/team-details-img2.png\", \"zoom_from\": 1.18, \"local_path\": null, \"scene_number\": 2, \"visual_prompt\": \"Lifestyle scene showing the product in real everyday use, hands and close detail, candid authentic moment, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, natural light, no text, no logo, no watermark\"}, {\"act\": \"cta\", \"pan\": \"up\", \"label\": \"CTA\", \"start\": 25, \"length\": 5, \"timing\": \"0:25 - 0:30\", \"caption\": \"Tap to try it yourself\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/blog-details-img2.png\", \"zoom_from\": 1, \"local_path\": null, \"scene_number\": 3, \"visual_prompt\": \"Warm closeup of a person happily finishing their review while holding the product toward camera, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, inviting composition with clear space for a call to action, no text, no logo, no watermark\"}], \"provider\": \"storyboard\", \"style_id\": \"lifestyle_storyboard\", \"resolution\": \"720x1280\", \"started_at\": \"2026-10-12T12:34:04+00:00\", \"video_type\": \"ugc_testimonial\", \"avatar_name\": \"Lexi R.\", \"full_script\": \"My dark spots vanished in 14 days I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works. Tap to try it yourself\", \"provider_label\": \"Storyboard Studio (built-in, free)\"}', '2026-10-12 12:34:50', NULL),
(11, 100000, 'lexi_genz', 'en_female_energetic', 'My dark spots vanished in 14 days', 'I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.', 'Tap to try it yourself', 'tiktok_glow', '', 'viral_lofi_beat', '', 'uploads/videos/scenes/scene_294709_1.jpg', '9:16', 30, 'rendering_client', 3, NULL, '{\"seed\": 294709, \"scenes\": [{\"act\": \"hook\", \"pan\": \"right\", \"label\": \"HOOK\", \"start\": 0, \"length\": 8, \"timing\": \"0:00 - 0:08\", \"caption\": \"My dark spots vanished in 14 days\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/team-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_294709_1.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_294709_1.jpg\", \"scene_number\": 1, \"visual_prompt\": \"Authentic UGC style shot of a person holding and reacting to a product, direct to camera, Energetic, authentic, fast-paced, high energy, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, shot on 35mm, natural skin texture, no text, no logo, no watermark\"}, {\"act\": \"body\", \"pan\": \"left\", \"label\": \"BODY\", \"start\": 8, \"length\": 17, \"timing\": \"0:08 - 0:25\", \"caption\": \"I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.\", \"zoom_to\": 1, \"image_url\": \"http://localhost/assets/images/thumbs/blog-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_294709_2.jpg\", \"zoom_from\": 1.18, \"local_path\": \"uploads/videos/scenes/scene_294709_2.jpg\", \"scene_number\": 2, \"visual_prompt\": \"Lifestyle scene showing the product in real everyday use, hands and close detail, candid authentic moment, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, natural light, no text, no logo, no watermark\"}, {\"act\": \"cta\", \"pan\": \"up\", \"label\": \"CTA\", \"start\": 25, \"length\": 5, \"timing\": \"0:25 - 0:30\", \"caption\": \"Tap to try it yourself\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/about-five-img1.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_294709_3.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_294709_3.jpg\", \"scene_number\": 3, \"visual_prompt\": \"Warm closeup of a person happily finishing their review while holding the product toward camera, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, inviting composition with clear space for a call to action, no text, no logo, no watermark\"}], \"provider\": \"storyboard\", \"style_id\": \"lifestyle_storyboard\", \"resolution\": \"720x1280\", \"started_at\": \"2026-10-12T12:38:35+00:00\", \"video_type\": \"ugc_testimonial\", \"avatar_name\": \"Lexi R.\", \"full_script\": \"My dark spots vanished in 14 days I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works. Tap to try it yourself\", \"provider_label\": \"Storyboard Studio (built-in, free)\"}', '2026-10-12 12:41:02', NULL),
(12, 100000, 'lexi_genz', 'en_female_energetic', 'My dark spots vanished in 14 days', 'I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.', 'Tap to try it yourself', 'tiktok_glow', '', 'viral_lofi_beat', '', 'uploads/videos/scenes/scene_879085_1.jpg', '9:16', 30, 'rendering_client', 3, NULL, '{\"seed\": 879085, \"scenes\": [{\"act\": \"hook\", \"pan\": \"right\", \"label\": \"HOOK\", \"start\": 0, \"length\": 8, \"timing\": \"0:00 - 0:08\", \"caption\": \"My dark spots vanished in 14 days\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/blog-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_879085_1.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_879085_1.jpg\", \"scene_number\": 1, \"visual_prompt\": \"Authentic UGC style shot of a person holding and reacting to a product, direct to camera, Energetic, authentic, fast-paced, high energy, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, shot on 35mm, natural skin texture, no text, no logo, no watermark\"}, {\"act\": \"body\", \"pan\": \"left\", \"label\": \"BODY\", \"start\": 8, \"length\": 17, \"timing\": \"0:08 - 0:25\", \"caption\": \"I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.\", \"zoom_to\": 1, \"image_url\": \"http://localhost/assets/images/thumbs/about-five-img1.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_879085_2.jpg\", \"zoom_from\": 1.18, \"local_path\": \"uploads/videos/scenes/scene_879085_2.jpg\", \"scene_number\": 2, \"visual_prompt\": \"Lifestyle scene showing the product in real everyday use, hands and close detail, candid authentic moment, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, natural light, no text, no logo, no watermark\"}, {\"act\": \"cta\", \"pan\": \"up\", \"label\": \"CTA\", \"start\": 25, \"length\": 5, \"timing\": \"0:25 - 0:30\", \"caption\": \"Tap to try it yourself\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/team-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_879085_3.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_879085_3.jpg\", \"scene_number\": 3, \"visual_prompt\": \"Warm closeup of a person happily finishing their review while holding the product toward camera, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, inviting composition with clear space for a call to action, no text, no logo, no watermark\"}], \"provider\": \"storyboard\", \"style_id\": \"lifestyle_storyboard\", \"resolution\": \"720x1280\", \"started_at\": \"2026-10-12T13:12:02+00:00\", \"video_type\": \"ugc_testimonial\", \"avatar_name\": \"Lexi R.\", \"full_script\": \"My dark spots vanished in 14 days I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works. Tap to try it yourself\", \"provider_label\": \"Storyboard Studio (built-in, free)\"}', '2026-10-12 13:14:34', NULL),
(13, 100000, 'lexi_genz', 'en_female_energetic', 'My dark spots vanished in 14 days', 'I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.', 'Tap to try it yourself', 'tiktok_glow', '', 'viral_lofi_beat', '', 'uploads/videos/scenes/scene_318834_1.jpg', '9:16', 30, 'rendering_client', 3, NULL, '{\"seed\": 318834, \"scenes\": [{\"act\": \"hook\", \"pan\": \"right\", \"label\": \"HOOK\", \"start\": 0, \"length\": 8, \"timing\": \"0:00 - 0:08\", \"caption\": \"My dark spots vanished in 14 days\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/about-five-img1.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_318834_1.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_318834_1.jpg\", \"scene_number\": 1, \"visual_prompt\": \"Authentic UGC style shot of a person holding and reacting to a product, direct to camera, Energetic, authentic, fast-paced, high energy, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, shot on 35mm, natural skin texture, no text, no logo, no watermark\"}, {\"act\": \"body\", \"pan\": \"left\", \"label\": \"BODY\", \"start\": 8, \"length\": 17, \"timing\": \"0:08 - 0:25\", \"caption\": \"I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.\", \"zoom_to\": 1, \"image_url\": \"http://localhost/assets/images/thumbs/team-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_318834_2.jpg\", \"zoom_from\": 1.18, \"local_path\": \"uploads/videos/scenes/scene_318834_2.jpg\", \"scene_number\": 2, \"visual_prompt\": \"Lifestyle scene showing the product in real everyday use, hands and close detail, candid authentic moment, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, natural light, no text, no logo, no watermark\"}, {\"act\": \"cta\", \"pan\": \"up\", \"label\": \"CTA\", \"start\": 25, \"length\": 5, \"timing\": \"0:25 - 0:30\", \"caption\": \"Tap to try it yourself\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/blog-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_318834_3.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_318834_3.jpg\", \"scene_number\": 3, \"visual_prompt\": \"Warm closeup of a person happily finishing their review while holding the product toward camera, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, inviting composition with clear space for a call to action, no text, no logo, no watermark\"}], \"provider\": \"storyboard\", \"style_id\": \"lifestyle_storyboard\", \"resolution\": \"720x1280\", \"started_at\": \"2026-10-12T14:44:10+00:00\", \"video_type\": \"ugc_testimonial\", \"avatar_name\": \"Lexi R.\", \"full_script\": \"My dark spots vanished in 14 days I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works. Tap to try it yourself\", \"provider_label\": \"Storyboard Studio (built-in, free)\"}', '2026-10-12 14:47:15', NULL),
(14, 100000, 'lexi_genz', 'en_female_energetic', 'My dark spots vanished in 14 days', 'I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.', 'Tap to try it yourself', 'tiktok_glow', '', 'viral_lofi_beat', '', 'uploads/videos/scenes/scene_576889_1.jpg', '9:16', 30, 'rendering_client', 3, NULL, '{\"seed\": 576889, \"scenes\": [{\"act\": \"hook\", \"pan\": \"right\", \"label\": \"HOOK\", \"start\": 0, \"length\": 8, \"timing\": \"0:00 - 0:08\", \"caption\": \"My dark spots vanished in 14 days\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/team-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_576889_1.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_576889_1.jpg\", \"scene_number\": 1, \"visual_prompt\": \"Authentic UGC style shot of a person holding and reacting to a product, direct to camera, Energetic, authentic, fast-paced, high energy, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, shot on 35mm, natural skin texture, no text, no logo, no watermark\"}, {\"act\": \"body\", \"pan\": \"left\", \"label\": \"BODY\", \"start\": 8, \"length\": 17, \"timing\": \"0:08 - 0:25\", \"caption\": \"I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.\", \"zoom_to\": 1, \"image_url\": \"http://localhost/assets/images/thumbs/blog-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_576889_2.jpg\", \"zoom_from\": 1.18, \"local_path\": \"uploads/videos/scenes/scene_576889_2.jpg\", \"scene_number\": 2, \"visual_prompt\": \"Lifestyle scene showing the product in real everyday use, hands and close detail, candid authentic moment, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, natural light, no text, no logo, no watermark\"}, {\"act\": \"cta\", \"pan\": \"up\", \"label\": \"CTA\", \"start\": 25, \"length\": 5, \"timing\": \"0:25 - 0:30\", \"caption\": \"Tap to try it yourself\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/about-five-img1.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_576889_3.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_576889_3.jpg\", \"scene_number\": 3, \"visual_prompt\": \"Warm closeup of a person happily finishing their review while holding the product toward camera, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, inviting composition with clear space for a call to action, no text, no logo, no watermark\"}], \"provider\": \"storyboard\", \"style_id\": \"lifestyle_storyboard\", \"resolution\": \"720x1280\", \"started_at\": \"2026-10-12T20:45:47+00:00\", \"video_type\": \"ugc_testimonial\", \"avatar_name\": \"Lexi R.\", \"full_script\": \"My dark spots vanished in 14 days I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works. Tap to try it yourself\", \"provider_label\": \"Storyboard Studio (built-in, free)\"}', '2026-10-12 20:47:52', NULL),
(15, 100000, 'lexi_genz', 'en_female_energetic', 'My dark spots vanished in 14 days', 'I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.', 'Tap to try it yourself', 'tiktok_glow', '', 'viral_lofi_beat', '', 'uploads/videos/scenes/scene_548220_1.jpg', '9:16', 30, 'rendering_client', 3, NULL, '{\"seed\": 548220, \"scenes\": [{\"act\": \"hook\", \"pan\": \"right\", \"label\": \"HOOK\", \"start\": 0, \"length\": 8, \"timing\": \"0:00 - 0:08\", \"caption\": \"My dark spots vanished in 14 days\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/blog-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_548220_1.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_548220_1.jpg\", \"scene_number\": 1, \"visual_prompt\": \"Authentic UGC style shot of a person holding and reacting to a product, direct to camera, Energetic, authentic, fast-paced, high energy, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, shot on 35mm, natural skin texture, no text, no logo, no watermark\"}, {\"act\": \"body\", \"pan\": \"left\", \"label\": \"BODY\", \"start\": 8, \"length\": 17, \"timing\": \"0:08 - 0:25\", \"caption\": \"I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works.\", \"zoom_to\": 1, \"image_url\": \"http://localhost/assets/images/thumbs/about-five-img1.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_548220_2.jpg\", \"zoom_from\": 1.18, \"local_path\": \"uploads/videos/scenes/scene_548220_2.jpg\", \"scene_number\": 2, \"visual_prompt\": \"Lifestyle scene showing the product in real everyday use, hands and close detail, candid authentic moment, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, natural light, no text, no logo, no watermark\"}, {\"act\": \"cta\", \"pan\": \"up\", \"label\": \"CTA\", \"start\": 25, \"length\": 5, \"timing\": \"0:25 - 0:30\", \"caption\": \"Tap to try it yourself\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/team-details-img2.png\", \"local_url\": \"http://localhost/seopp/uploads/videos/scenes/scene_548220_3.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_548220_3.jpg\", \"scene_number\": 3, \"visual_prompt\": \"Warm closeup of a person happily finishing their review while holding the product toward camera, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, inviting composition with clear space for a call to action, no text, no logo, no watermark\"}], \"provider\": \"storyboard\", \"style_id\": \"lifestyle_storyboard\", \"resolution\": \"720x1280\", \"started_at\": \"2026-10-12T20:48:53+00:00\", \"video_type\": \"ugc_testimonial\", \"avatar_name\": \"Lexi R.\", \"full_script\": \"My dark spots vanished in 14 days I tried everything for these dark spots. Lumina Glow Serum cleared them in two weeks. Non-greasy, dermatologist tested, and it actually works. Tap to try it yourself\", \"provider_label\": \"Storyboard Studio (built-in, free)\"}', '2026-10-12 20:51:11', NULL),
(16, 1, 'commercial_cinematic', 'en_female_genz', '/ugcmarketing', '', '', 'tiktok_glow', '', 'viral_lofi_beat', '', 'uploads/videos/scenes/scene_975307_1.jpg', '16:9', 30, 'rendering_client', 3, NULL, '{\"seed\": 975307, \"scenes\": [{\"act\": \"hook\", \"pan\": \"right\", \"label\": \"SCENE 1\", \"start\": 0, \"length\": 9, \"timing\": \"0:00 - 0:09\", \"caption\": \"/ugcmarketing\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/about-five-img1.png\", \"local_url\": \"http://seopp.test/uploads/videos/scenes/scene_975307_1.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_975307_1.jpg\", \"scene_number\": 1, \"visual_prompt\": \"Hero product reveal on a dark obsidian pedestal, dramatic volumetric spotlight, floating dust particles, slow dolly-in, luxury minimalist studio photography, matte black and gold palette, soft architectural shadows, editorial fashion ad, elegant negative space, no text, no logo, no watermark, ultra detailed, 8k\"}, {\"act\": \"body\", \"pan\": \"left\", \"label\": \"SCENE 2\", \"start\": 9, \"length\": 14, \"timing\": \"0:09 - 0:23\", \"caption\": \"Engineered from the ground up for uncompromising performance.\", \"zoom_to\": 1, \"image_url\": \"http://localhost/assets/images/thumbs/team-details-img2.png\", \"zoom_from\": 1.18, \"local_path\": null, \"scene_number\": 2, \"visual_prompt\": \"Detailed product showcase, slow orbit around the object revealing craftsmanship and materials, soft reflections, cinematic colour grade, luxury minimalist studio photography, matte black and gold palette, soft architectural shadows, editorial fashion ad, elegant negative space, no text, no logo, no watermark, ultra detailed, 8k\"}, {\"act\": \"cta\", \"pan\": \"up\", \"label\": \"SCENE 3\", \"start\": 23, \"length\": 7, \"timing\": \"0:23 - 0:30\", \"caption\": \"Order now.\", \"zoom_to\": 1.18, \"image_url\": \"http://localhost/assets/images/thumbs/blog-details-img2.png\", \"local_url\": \"http://seopp.test/uploads/videos/scenes/scene_975307_3.jpg\", \"zoom_from\": 1, \"local_path\": \"uploads/videos/scenes/scene_975307_3.jpg\", \"scene_number\": 3, \"visual_prompt\": \"Final hero packshot, product centred with generous negative space, premium softbox lighting, subtle lens flare, luxury minimalist studio photography, matte black and gold palette, soft architectural shadows, editorial fashion ad, elegant negative space, no text, no logo, no watermark, ultra detailed, 8k\"}], \"provider\": \"storyboard\", \"style_id\": \"luxury_minimalist\", \"resolution\": \"1280x720\", \"started_at\": \"2026-10-13T16:16:07+00:00\", \"video_type\": \"commercial_cinematic\", \"avatar_name\": \"Cinematic AI Director\", \"full_script\": \"/ugcmarketing\", \"provider_label\": \"Storyboard Studio (built-in, free)\"}', '2026-10-13 16:18:11', NULL),
(17, 100000, 'lexi_genz', 'en_female_energetic', 'EDITED: cloud-knit shoes that feel like walking on air', 'Updated script body for the edit test.', 'EDITED cta: tap the link and save 40 percent today', 'tiktok_glow', '', 'viral_lofi_beat', '', 'assets/images/thumbs/about-five-img1.png', '9:16', 15, 'completed', 3, NULL, '{\"seed\": 163480, \"scenes\": [{\"act\": \"hook\", \"pan\": \"right\", \"label\": \"HOOK\", \"start\": 0, \"length\": 4, \"timing\": \"0:00 - 0:04\", \"caption\": \"EDITED: cloud-knit shoes that feel like walking on air\", \"zoom_to\": 1.18, \"image_url\": \"http://127.0.0.1/seopp/assets/images/thumbs/about-five-img1.png\", \"local_url\": \"http://127.0.0.1/seopp/assets/images/thumbs/about-five-img1.png\", \"zoom_from\": 1, \"local_path\": \"assets/images/thumbs/about-five-img1.png\", \"image_source\": \"local-placeholder\", \"scene_number\": 1, \"visual_prompt\": \"Authentic UGC style shot of a person holding and reacting to a product, direct to camera, Energetic, authentic, fast-paced, high energy, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, shot on 35mm, natural skin texture, no text, no logo, no watermark\"}, {\"act\": \"body\", \"pan\": \"left\", \"label\": \"BODY\", \"start\": 4, \"length\": 8, \"timing\": \"0:04 - 0:12\", \"caption\": \"Updated script body for the edit test.\", \"zoom_to\": 1, \"image_url\": \"http://127.0.0.1/seopp/assets/images/thumbs/team-details-img2.png\", \"local_url\": \"http://127.0.0.1/seopp/assets/images/thumbs/team-details-img2.png\", \"zoom_from\": 1.18, \"local_path\": \"assets/images/thumbs/team-details-img2.png\", \"image_source\": \"local-placeholder\", \"scene_number\": 2, \"visual_prompt\": \"Lifestyle scene showing the product in real everyday use, hands and close detail, candid authentic moment, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, natural light, no text, no logo, no watermark\"}, {\"act\": \"cta\", \"pan\": \"up\", \"label\": \"CTA\", \"start\": 12, \"length\": 3, \"timing\": \"0:12 - 0:15\", \"caption\": \"EDITED cta: tap the link and save 40 percent today\", \"zoom_to\": 1.18, \"image_url\": \"http://127.0.0.1/seopp/assets/images/thumbs/blog-details-img2.png\", \"local_url\": \"http://127.0.0.1/seopp/assets/images/thumbs/blog-details-img2.png\", \"zoom_from\": 1, \"local_path\": \"assets/images/thumbs/blog-details-img2.png\", \"image_source\": \"local-placeholder\", \"scene_number\": 3, \"visual_prompt\": \"Warm closeup of a person happily finishing their review while holding the product toward camera, modern lifestyle photography, natural sunlight, subtle lens flare, candid authentic moment, warm color grade, handheld documentary feel, inviting composition with clear space for a call to action, no text, no logo, no watermark\"}], \"provider\": \"storyboard\", \"style_id\": \"lifestyle_storyboard\", \"edit_count\": 4, \"rebuilt_at\": \"2026-10-18T17:05:38+00:00\", \"resolution\": \"720x1280\", \"video_type\": \"ugc_talking_head\", \"avatar_name\": \"Lexi R.\", \"full_script\": \"EDITED: cloud-knit shoes that feel like walking on air Updated script body for the edit test. EDITED cta: tap the link and save 40 percent today\", \"scene_source\": \"local-placeholder\", \"provider_label\": \"Storyboard Studio (built-in, free)\"}', '2026-10-17 04:21:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
CREATE TABLE `api_keys` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `key_hash` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `key_prefix` varchar(10) COLLATE latin1_swedish_ci DEFAULT NULL,
  `scopes` json DEFAULT NULL,
  `last_used_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `api_keys`
--

INSERT INTO `api_keys` (`id`, `user_id`, `key_hash`, `key_prefix`, `scopes`, `last_used_at`, `created_at`) VALUES
(2, 3, '$2y$10$URCC4k2vWY9jAxPbSlDQYe.BYKy44muBgamZEAjEvVlLFtAM2UtWK', 'adsb_34864', '[\"read\", \"write\", \"billing\"]', NULL, '2026-09-24 16:09:58'),
(3, 1, '7d43129894600935ee45a0b432553a8b338b612903028e7fb718ab587d1fde8f', 'adsb_testk', '[\"read\", \"write\"]', '2026-09-24 16:50:33', '2026-09-24 16:49:03'),
(4, 3, 'ed2d78071a8b3cc535b4d5964a0a5a9479756ca4ace8f8bbc3936cee43ee96c7', 'adsb_352f6', '[\"read\", \"write\", \"ads\", \"ai\", \"social\", \"directory\", \"wallet\", \"ugc\", \"reviews\"]', NULL, '2026-09-25 16:59:56');

-- --------------------------------------------------------

--
-- Table structure for table `api_rate_limits`
--

DROP TABLE IF EXISTS `api_rate_limits`;
CREATE TABLE `api_rate_limits` (
  `id` int NOT NULL,
  `key_id` int NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `window_minute` int NOT NULL,
  `request_count` int NOT NULL DEFAULT '1',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audience_segments`
--

DROP TABLE IF EXISTS `audience_segments`;
CREATE TABLE `audience_segments` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `name` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `criteria_json` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `criteria` json DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blog_posts`
--

DROP TABLE IF EXISTS `blog_posts`;
CREATE TABLE `blog_posts` (
  `id` int NOT NULL,
  `title` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `slug` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `excerpt` text COLLATE latin1_swedish_ci,
  `body` longtext COLLATE latin1_swedish_ci,
  `featured_image` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `author_id` int DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `status` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `category` varchar(100) COLLATE latin1_swedish_ci DEFAULT 'Advertising',
  `tags` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `views_count` int DEFAULT '0',
  `is_featured` tinyint DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `blog_posts`
--

INSERT INTO `blog_posts` (`id`, `title`, `slug`, `excerpt`, `body`, `featured_image`, `author_id`, `published_at`, `status`, `created_at`, `updated_at`, `category`, `tags`, `views_count`, `is_featured`) VALUES
(1, 'How to Run Ads Across 5 Platforms From One Dashboard', 'run-ads-five-platforms-one-dashboard', 'Managing ad campaigns on Meta, Instagram, TikTok, Google Ads, and Snapchat used to require five different tools. Here is how Adsbooster unifies it all.', '<p>Running ads across multiple platforms has traditionally been a nightmare for marketers and business owners. You needed separate accounts, separate dashboards, and separate strategies for each platform.</p><p>Adsbooster changes that. With a single dashboard, you can create, launch, and manage campaigns across Meta, Instagram, TikTok, Google Ads, and Snapchat. The platform handles budget allocation, creative generation, and performance tracking across all networks simultaneously.</p><p>Whether you are a solo entrepreneur or an agency managing dozens of client accounts, the ability to centralize your advertising workflow saves hours every week and eliminates the risk of inconsistent messaging across platforms.</p>', 'assets/images/thumbs/project-img1.png', 1, '2026-09-01 10:00:00', 'published', '2026-09-16 16:41:50', '2026-10-12 20:45:08', 'Advertising', NULL, 1, 0),
(2, 'AI-Powered Ad Creatives: Why They Outperform Manual Designs', 'ai-powered-ad-creatives-outperform', 'Artificial intelligence is transforming how ad creatives are generated. Learn why AI-created visuals and copy consistently outperform manual designs.', '<p>The days of spending hours tweaking ad creatives in Photoshop are numbered. AI-powered creative generation tools can now produce high-performing visuals and copy in seconds.</p><p>Studies show that AI-generated ad creatives achieve 20-40% higher click-through rates compared to manually designed alternatives. This is because AI models analyze millions of top-performing ads to understand what resonates with different audiences.</p><p>Adsbooster integrates AI creative generation directly into the campaign creation flow. When you launch a campaign, the platform automatically generates multiple creative variations and tests them to find the highest-performing combination.</p>', 'assets/images/thumbs/project-img2.png', 1, '2026-09-05 10:00:00', 'published', '2026-09-16 16:41:50', '2026-09-16 16:41:50', 'Advertising', NULL, 0, 0),
(3, 'The Complete Guide to Social Media Scheduling in 2026', 'social-media-scheduling-guide-2026', 'Scheduling social media posts across multiple platforms is essential for consistency. Here is the definitive guide to doing it right.', '<p>Consistency is the backbone of social media success. Posting regularly across Instagram, TikTok, Meta, and other platforms keeps your audience engaged and your brand visible.</p><p>But manually posting to each platform is time-consuming and error-prone. A social media scheduling tool eliminates this friction by letting you plan, write, and schedule posts for multiple platforms from a single interface.</p><p>Adsbooster content calendar lets you drag and drop posts, set optimal posting times based on audience activity data, and auto-publish to all connected accounts. The result is a consistent presence without the daily grind.</p>', 'assets/images/thumbs/project-img3.png', 1, '2026-09-08 10:00:00', 'published', '2026-09-16 16:41:50', '2026-09-25 11:53:49', 'Advertising', NULL, 1, 0),
(4, 'Meta Ads vs TikTok Ads: Which Platform Delivers Better ROI?', 'meta-ads-vs-tiktok-ads-roi', 'Choosing between Meta and TikTok for your ad spend can be tricky. We break down the strengths of each platform and when to use both.', '<p>Meta and TikTok are the two dominant social advertising platforms in 2026. Each has distinct strengths that make them suitable for different campaign objectives.</p><p>Meta excels at retargeting and conversion campaigns thanks to its mature pixel tracking and lookalike audience capabilities. TikTok, on the other hand, drives exceptional brand awareness and engagement through its algorithm-driven content discovery.</p><p>The smartest advertisers do not choose one over the other. They run complementary campaigns on both platforms, using Meta for bottom-funnel conversions and TikTok for top-funnel awareness. Adsbooster makes this dual-platform strategy effortless with its combo pack feature.</p>', 'assets/images/thumbs/project-img1.png', 1, '2026-09-10 10:00:00', 'published', '2026-09-16 16:41:50', '2026-09-25 11:54:06', 'Advertising', NULL, 2, 0),
(5, '5 Signs Your Ad Campaign Needs a Performance Audit', 'ad-campaign-performance-audit-signs', 'Not sure if your campaigns are underperforming? These five warning signs indicate it is time for a thorough performance review.', '<p>Running ads is easy. Running ads profitably is hard. Many advertisers waste thousands of dollars on underperforming campaigns without realizing it.</p><p>Here are five signs your campaign needs attention: high impressions but low clicks, a cost-per-acquisition that exceeds your profit margin, declining performance over time, audience fatigue shown by falling engagement rates, and zero conversions despite significant spend.</p><p>Adsbooster Campaign Doctor automatically monitors your campaigns for these issues and generates actionable recommendations. It can pause underperforming ads, reallocate budgets to winners, and suggest targeting adjustments to improve your return on ad spend.</p>', 'assets/images/thumbs/project-img2.png', 1, '2026-09-12 10:00:00', 'published', '2026-09-16 16:41:50', '2026-09-25 11:12:59', 'Advertising', NULL, 1, 0),
(6, 'How Agencies Scale Client Management With Multi-Network Tools', 'agencies-scale-client-management', 'Managing ads for multiple clients across multiple platforms requires the right tools. Here is how modern agencies scale without hiring more staff.', '<p>Advertising agencies face a unique challenge: managing dozens of client accounts across multiple ad platforms, each with its own interface, billing, and reporting.</p><p>The traditional approach requires dedicated account managers for each platform, leading to bloated teams and fragmented workflows. Multi-network advertising tools like Adsbooster solve this by providing a unified dashboard for all client campaigns.</p><p>With features like team collaboration, role-based access, white-label reporting, and automated campaign monitoring, agencies can scale their client base without proportionally scaling their headcount. The result is higher margins and better client satisfaction.</p>', 'assets/images/thumbs/project-img3.png', 1, '2026-09-15 10:00:00', 'published', '2026-09-16 16:41:50', '2026-09-25 11:53:22', 'Advertising', NULL, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `calendar_sync_events`
--

DROP TABLE IF EXISTS `calendar_sync_events`;
CREATE TABLE `calendar_sync_events` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `post_id` int DEFAULT NULL,
  `google_event_id` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `event_title` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `event_start` datetime DEFAULT NULL,
  `event_end` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_metrics_daily`
--

DROP TABLE IF EXISTS `campaign_metrics_daily`;
CREATE TABLE `campaign_metrics_daily` (
  `id` int NOT NULL,
  `campaign_id` int NOT NULL,
  `variant_id` int DEFAULT NULL,
  `date` date NOT NULL,
  `impressions` int DEFAULT '0',
  `clicks` int DEFAULT '0',
  `spend` decimal(10,2) DEFAULT '0.00',
  `conversions` int DEFAULT '0',
  `ctr` decimal(5,2) DEFAULT '0.00',
  `cpc` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_recommendations`
--

DROP TABLE IF EXISTS `campaign_recommendations`;
CREATE TABLE `campaign_recommendations` (
  `id` int NOT NULL,
  `campaign_id` int NOT NULL,
  `recommendation_type` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `message` text COLLATE latin1_swedish_ci,
  `suggested_action` text COLLATE latin1_swedish_ci,
  `status` enum('pending','applied','dismissed','auto_applied') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_run_logs`
--

DROP TABLE IF EXISTS `campaign_run_logs`;
CREATE TABLE `campaign_run_logs` (
  `id` int NOT NULL,
  `campaign_id` int NOT NULL,
  `action` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `details` text COLLATE latin1_swedish_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `competitor_ad_analyses`
--

DROP TABLE IF EXISTS `competitor_ad_analyses`;
CREATE TABLE `competitor_ad_analyses` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `competitor_name` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `competitor_url` varchar(500) COLLATE latin1_swedish_ci NOT NULL,
  `platform` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'meta',
  `scraped_ads_count` int DEFAULT '0',
  `extracted_hooks` json DEFAULT NULL,
  `extracted_angles` json DEFAULT NULL,
  `target_audience_insights` json DEFAULT NULL,
  `counter_creatives` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `competitor_ad_analyses`
--

INSERT INTO `competitor_ad_analyses` (`id`, `user_id`, `competitor_name`, `competitor_url`, `platform`, `scraped_ads_count`, `extracted_hooks`, `extracted_angles`, `target_audience_insights`, `counter_creatives`, `created_at`) VALUES
(1, 2, 'Seopp', 'http://seopp.test/', 'tiktok', 23, '[\"Why 90% of Seopp alternatives fail within 30 days.\", \"The secret hack Seopp customers use to cut their monthly spend.\", \"I stopped using traditional solutions and switched to Seopp. Here is what happened.\", \"If you are still doing this manually in 2026, you are losing money.\"]', '[{\"desc\": \"Highlights time-loss and frustration with legacy competitors.\", \"angle\": \"Direct Pain-Point Agitation\", \"share_pct\": 45}, {\"desc\": \"Clear visual contrast demonstrating fast time-to-value.\", \"angle\": \"Before & After Transformation\", \"share_pct\": 30}, {\"desc\": \"High-trust authentic UGC format emphasizing brand transparency.\", \"angle\": \"Unboxing & Founder Story\", \"share_pct\": 25}]', '{\"top_geos\": [\"United States\", \"United Kingdom\", \"Canada\", \"Australia\"], \"age_range\": \"24 - 45\", \"format_split\": {\"Single Image\": \"10%\", \"Static Carousel\": \"25%\", \"Video UGC (9:16)\": \"65%\"}, \"top_interests\": [\"E-commerce\", \"Direct-to-Consumer\", \"Growth Marketing\", \"Productivity Software\"]}', '[{\"cta\": \"Claim Your Exclusive Competitor Switcher Deal\", \"body\": \"Most platforms lock essential features behind costly tiers. We built our solution from the ground up to give you full unlimited access at half the cost.\", \"hook\": \"Don\'t settle for overpriced Seopp features when you can get 3x better results.\", \"title\": \"1. The Pain-Point Aggressor (Higher Urgency)\", \"headline\": \"Tired of Seopp? Here is the upgrade you\'ve been waiting for.\"}, {\"cta\": \"See the Full Side-by-Side Breakdown\", \"body\": \"Faster speeds, zero learning curve, and round-the-clock priority support. See why top media buyers are making the switch.\", \"hook\": \"We compared Seopp side-by-side with our platform. The results weren\'t even close.\", \"title\": \"2. The Social Proof / Comparison Winner\", \"headline\": \"Why 10,000+ creators switched from Seopp to us this month.\"}, {\"cta\": \"Start Your 14-Day Risk-Free Trial\", \"body\": \"Hidden fees and complicated setups are eating into your margins. Get transparent pricing, instant onboarding, and guaranteed ROI.\", \"hook\": \"Before you spend another dollar on Seopp, watch this.\", \"title\": \"3. The Contrarian / Myth-Buster\", \"headline\": \"The truth about Seopp nobody is talking about.\"}, {\"cta\": \"Unlock Your Lifetime VIP Access\", \"body\": \"Literally saved me 15 hours in my very first week. The workflow is so seamless it feels like magic.\", \"hook\": \"I thought Seopp was the best option until a colleague recommended this.\", \"title\": \"4. The Aesthetic UGC Hook\", \"headline\": \"My honest review after ditching Seopp for 30 days.\"}, {\"cta\": \"Claim 50% Switcher Discount Now\", \"body\": \"Transfer your account effortlessly in under 2 minutes. Plus, our dedicated onboarding team will set up your first 3 campaigns for free.\", \"hook\": \"Still paying full price for Seopp? We\'ll match and double your perks.\", \"title\": \"5. The Irresistible Offer / Risk Reversal\", \"headline\": \"Switch today and get 50% off + 10,000 free bonus credits.\"}]', '2026-10-05 17:20:20'),
(4, 1, 'Seopp', 'http://seopp.test/', 'tiktok', 12, '[\"Why 90% of Seopp alternatives fail within 30 days.\", \"The secret hack Seopp customers use to cut their monthly spend.\", \"I stopped using traditional solutions and switched to Seopp. Here is what happened.\", \"If you are still doing this manually in 2026, you are losing money.\"]', '[{\"desc\": \"Highlights time-loss and frustration with legacy competitors.\", \"angle\": \"Direct Pain-Point Agitation\", \"share_pct\": 45}, {\"desc\": \"Clear visual contrast demonstrating fast time-to-value.\", \"angle\": \"Before & After Transformation\", \"share_pct\": 30}, {\"desc\": \"High-trust authentic UGC format emphasizing brand transparency.\", \"angle\": \"Unboxing & Founder Story\", \"share_pct\": 25}]', '{\"top_geos\": [\"United States\", \"United Kingdom\", \"Canada\", \"Australia\"], \"age_range\": \"24 - 45\", \"format_split\": {\"Single Image\": \"10%\", \"Static Carousel\": \"25%\", \"Video UGC (9:16)\": \"65%\"}, \"top_interests\": [\"E-commerce\", \"Direct-to-Consumer\", \"Growth Marketing\", \"Productivity Software\"]}', '[{\"cta\": \"Claim Your Exclusive Competitor Switcher Deal\", \"body\": \"Most platforms lock essential features behind costly tiers. We built our solution from the ground up to give you full unlimited access at half the cost.\", \"hook\": \"Don\'t settle for overpriced Seopp features when you can get 3x better results.\", \"title\": \"1. The Pain-Point Aggressor (Higher Urgency)\", \"headline\": \"Tired of Seopp? Here is the upgrade you\'ve been waiting for.\"}, {\"cta\": \"See the Full Side-by-Side Breakdown\", \"body\": \"Faster speeds, zero learning curve, and round-the-clock priority support. See why top media buyers are making the switch.\", \"hook\": \"We compared Seopp side-by-side with our platform. The results weren\'t even close.\", \"title\": \"2. The Social Proof / Comparison Winner\", \"headline\": \"Why 10,000+ creators switched from Seopp to us this month.\"}, {\"cta\": \"Start Your 14-Day Risk-Free Trial\", \"body\": \"Hidden fees and complicated setups are eating into your margins. Get transparent pricing, instant onboarding, and guaranteed ROI.\", \"hook\": \"Before you spend another dollar on Seopp, watch this.\", \"title\": \"3. The Contrarian / Myth-Buster\", \"headline\": \"The truth about Seopp nobody is talking about.\"}, {\"cta\": \"Unlock Your Lifetime VIP Access\", \"body\": \"Literally saved me 15 hours in my very first week. The workflow is so seamless it feels like magic.\", \"hook\": \"I thought Seopp was the best option until a colleague recommended this.\", \"title\": \"4. The Aesthetic UGC Hook\", \"headline\": \"My honest review after ditching Seopp for 30 days.\"}, {\"cta\": \"Claim 50% Switcher Discount Now\", \"body\": \"Transfer your account effortlessly in under 2 minutes. Plus, our dedicated onboarding team will set up your first 3 campaigns for free.\", \"hook\": \"Still paying full price for Seopp? We\'ll match and double your perks.\", \"title\": \"5. The Irresistible Offer / Risk Reversal\", \"headline\": \"Switch today and get 50% off + 10,000 free bonus credits.\"}]', '2026-10-15 08:30:01');

-- --------------------------------------------------------

--
-- Table structure for table `connected_accounts`
--

DROP TABLE IF EXISTS `connected_accounts`;
CREATE TABLE `connected_accounts` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `platform` varchar(50) COLLATE latin1_swedish_ci NOT NULL,
  `access_token` text COLLATE latin1_swedish_ci,
  `refresh_token` text COLLATE latin1_swedish_ci,
  `token_expiry` datetime DEFAULT NULL,
  `platform_user_id` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `account_name` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `metadata_json` text COLLATE latin1_swedish_ci
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `connected_accounts`
--

INSERT INTO `connected_accounts` (`id`, `user_id`, `platform`, `access_token`, `refresh_token`, `token_expiry`, `platform_user_id`, `created_at`, `account_name`, `metadata_json`) VALUES
(16, 3, 'google_calendar', 'live_tok_4d50809fdd95b484a34fae0e7b628672', NULL, '2026-11-23 16:18:13', 'google_calendar_8f67fc2e71', '2026-09-24 16:18:13', 'Google Calendar Profile (fc2e71)', '{\"connected_at\":\"2026-09-24 16:18:13\",\"sync_status\":\"active\",\"realtime\":true}'),
(18, 3, 'meta', 'verified_handle_6438d989565c7f4db310dc69767e11e1', NULL, '2026-12-24 13:33:15', 'meta_5cbe4cda', '2026-09-25 13:33:15', 'Meta (Facebook) Profile', '{\"connected_at\":\"2026-09-25 13:33:15\",\"oauth_verified\":true,\"sync_status\":\"warning\",\"token_type\":\"Bearer\",\"latency_ms\":833,\"handle\":\"\",\"last_synced_at\":\"2026-09-25 13:33:21\",\"last_error\":\"Meta API error (HTTP 400): Invalid OAuth access token - Cannot parse access token\"}');

-- --------------------------------------------------------

--
-- Table structure for table `cookie_consents`
--

DROP TABLE IF EXISTS `cookie_consents`;
CREATE TABLE `cookie_consents` (
  `id` int NOT NULL,
  `ip` varchar(45) COLLATE latin1_swedish_ci DEFAULT NULL,
  `consent_uuid` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `necessary` tinyint DEFAULT '1',
  `preferences` tinyint DEFAULT '0',
  `analytics` tinyint DEFAULT '0',
  `marketing` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `creator_bounties`
--

DROP TABLE IF EXISTS `creator_bounties`;
CREATE TABLE `creator_bounties` (
  `id` int NOT NULL,
  `brand_user_id` int NOT NULL,
  `title` varchar(500) COLLATE latin1_swedish_ci NOT NULL,
  `description` text COLLATE latin1_swedish_ci NOT NULL,
  `platform` enum('tiktok','instagram_reels','youtube_shorts','all') COLLATE latin1_swedish_ci DEFAULT 'tiktok',
  `content_type` enum('ugc_talking_head','unboxing','tutorial','lifestyle_testimonial') COLLATE latin1_swedish_ci DEFAULT 'ugc_talking_head',
  `deliverables_req` text COLLATE latin1_swedish_ci NOT NULL,
  `bounty_amount` decimal(10,2) NOT NULL,
  `platform_fee_pct` decimal(5,2) DEFAULT '10.00',
  `total_escrow_held` decimal(10,2) NOT NULL,
  `escrow_status` enum('funded','released_to_creator','refunded_to_brand') COLLATE latin1_swedish_ci DEFAULT 'funded',
  `claimed_creator_id` int DEFAULT NULL,
  `status` enum('open','in_progress','draft_submitted','completed','disputed','cancelled') COLLATE latin1_swedish_ci DEFAULT 'open',
  `submission_deadline` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `creator_bounties`
--

INSERT INTO `creator_bounties` (`id`, `brand_user_id`, `title`, `description`, `platform`, `content_type`, `deliverables_req`, `bounty_amount`, `platform_fee_pct`, `total_escrow_held`, `escrow_status`, `claimed_creator_id`, `status`, `submission_deadline`, `created_at`) VALUES
(1, 2, '15s UGC Talking Head Review for Hydrating Skincare Brand', 'Looking for a female creator (20-35) to test our glow serum and record an authentic selfie-style talking head review.', 'tiktok', 'ugc_talking_head', '1x 9:16 vertical video, 1080p, clear audio, with hook & CTA.', 120.00, 10.00, 120.00, 'funded', NULL, 'open', '2026-10-12 17:14:19', '2026-10-05 17:14:19'),
(2, 2, 'SaaS Productivity App Unboxing & Workflow Demo', 'Tech creator needed to record a screen-share and face-cam walkthrough of our AI automation tool.', 'instagram_reels', 'tutorial', '1x Reel (30s) highlighting 3 core features.', 200.00, 10.00, 200.00, 'funded', NULL, 'open', '2026-10-12 17:14:21', '2026-10-05 17:14:21'),
(3, 2, 'Athletic Compression Gym Wear Try-On Haul', 'Fitness influencer needed to showcase workout durability and squat-proof fit.', 'youtube_shorts', 'lifestyle_testimonial', '1x Short with trending audio beat.', 150.00, 10.00, 150.00, 'funded', NULL, 'open', '2026-10-12 17:14:21', '2026-10-05 17:14:21');

-- --------------------------------------------------------

--
-- Table structure for table `creator_bounty_submissions`
--

DROP TABLE IF EXISTS `creator_bounty_submissions`;
CREATE TABLE `creator_bounty_submissions` (
  `id` int NOT NULL,
  `bounty_id` int NOT NULL,
  `creator_user_id` int NOT NULL,
  `video_url` varchar(500) COLLATE latin1_swedish_ci NOT NULL,
  `thumbnail_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `submission_notes` text COLLATE latin1_swedish_ci,
  `ai_compliance_score` int DEFAULT '100',
  `ai_compliance_report` json DEFAULT NULL,
  `review_status` enum('pending_review','approved','revision_requested') COLLATE latin1_swedish_ci DEFAULT 'pending_review',
  `revision_notes` text COLLATE latin1_swedish_ci,
  `submitted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cron_run_logs`
--

DROP TABLE IF EXISTS `cron_run_logs`;
CREATE TABLE `cron_run_logs` (
  `id` int NOT NULL,
  `job_name` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `status` enum('running','success','failed') COLLATE latin1_swedish_ci DEFAULT 'running',
  `notes` text COLLATE latin1_swedish_ci
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cron_run_logs`
--

INSERT INTO `cron_run_logs` (`id`, `job_name`, `started_at`, `finished_at`, `status`, `notes`) VALUES
(1, 'pull_campaign_metrics', '2026-10-12 20:03:58', '2026-10-12 20:03:58', 'success', 'Processed 0 campaigns. Impressions: 0, Clicks: 0, Spend: $0.00'),
(2, 'pull_campaign_metrics', '2026-10-12 20:13:58', '2026-10-12 20:13:58', 'success', 'No active campaigns; nothing to pull.'),
(3, 'publish_scheduled_posts', '2026-10-12 20:35:17', '2026-10-12 20:35:21', 'failed', 'Processed 1 due post(s). Published: 0, Failed: 1. Errors: #2(facebook): An active access token must be used to query information about the current user..'),
(4, 'pull_campaign_metrics', '2026-10-12 20:44:13', '2026-10-12 20:44:13', 'success', 'No active campaigns; nothing to pull.'),
(5, 'publish_scheduled_posts', '2026-10-12 20:44:13', '2026-10-12 20:44:13', 'success', 'Processed 0 due post(s). Published: 0, Failed: 0.'),
(6, 'auto_refill_check', '2026-10-12 20:44:14', '2026-10-12 20:44:14', 'success', 'Checked: 0, Triggered: 0, Skipped: 0, Failed: 0'),
(7, 'ab_test_winner', '2026-10-12 20:44:14', '2026-10-12 20:44:14', 'success', 'Scanned: 0 campaigns. Winners declared: 0, Skipped: 0'),
(8, 'campaign_doctor', '2026-10-12 20:44:14', '2026-10-12 20:44:14', 'success', 'Scanned: 0 campaigns. Flagged: 0, Auto-applied: 0'),
(9, 'pull_campaign_metrics', '2026-10-12 20:44:36', '2026-10-12 20:44:36', 'success', 'No active campaigns; nothing to pull.'),
(10, 'publish_scheduled_posts', '2026-10-12 20:44:37', '2026-10-12 20:44:37', 'success', 'Processed 0 due post(s). Published: 0, Failed: 0.'),
(11, 'auto_refill_check', '2026-10-12 20:44:37', '2026-10-12 20:44:37', 'success', 'Checked: 0, Triggered: 0, Skipped: 0, Failed: 0'),
(12, 'ab_test_winner', '2026-10-12 20:44:37', '2026-10-12 20:44:37', 'success', 'Scanned: 0 campaigns. Winners declared: 0, Skipped: 0'),
(13, 'campaign_doctor', '2026-10-12 20:44:37', '2026-10-12 20:44:37', 'success', 'Scanned: 0 campaigns. Flagged: 0, Auto-applied: 0');

-- --------------------------------------------------------

--
-- Table structure for table `dating_blocks`
--

DROP TABLE IF EXISTS `dating_blocks`;
CREATE TABLE `dating_blocks` (
  `id` int NOT NULL,
  `blocker_id` int NOT NULL,
  `blocked_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dating_pairs`
--

DROP TABLE IF EXISTS `dating_pairs`;
CREATE TABLE `dating_pairs` (
  `id` int NOT NULL,
  `sender_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `status` enum('pending','matched','rejected') DEFAULT 'pending',
  `icebreaker_message` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `matched_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_0900_ai_ci;

--
-- Dumping data for table `dating_pairs`
--

INSERT INTO `dating_pairs` (`id`, `sender_id`, `receiver_id`, `status`, `icebreaker_message`, `created_at`, `matched_at`) VALUES
(1, 3, 1, 'pending', '', '2026-09-24 20:19:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `dating_profiles`
--

DROP TABLE IF EXISTS `dating_profiles`;
CREATE TABLE `dating_profiles` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `gender` enum('male','female','other') COLLATE latin1_swedish_ci DEFAULT NULL,
  `looking_for` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'everyone',
  `age` int DEFAULT NULL,
  `city` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `country` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `bio` text COLLATE latin1_swedish_ci,
  `interests` text COLLATE latin1_swedish_ci,
  `photo_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `is_visible` tinyint DEFAULT '1',
  `is_photo_verified` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `photos_json` text COLLATE latin1_swedish_ci,
  `occupation` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `relationship_goals` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `verified_match` tinyint DEFAULT '0',
  `photo` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dating_profiles`
--

INSERT INTO `dating_profiles` (`id`, `user_id`, `gender`, `looking_for`, `age`, `city`, `country`, `bio`, `interests`, `photo_url`, `is_visible`, `is_photo_verified`, `created_at`, `updated_at`, `photos_json`, `occupation`, `relationship_goals`, `verified_match`, `photo`) VALUES
(1, 1, 'male', 'everyone', 28, 'Test City', NULL, 'Test bio', NULL, 'uploads/dating/sample.jpg', 1, 0, '2026-09-24 16:45:23', '2026-09-24 17:45:23', NULL, NULL, NULL, 0, 'uploads/dating/sample.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `dating_verification_uploads`
--

DROP TABLE IF EXISTS `dating_verification_uploads`;
CREATE TABLE `dating_verification_uploads` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `selfie_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dynamic_content`
--

DROP TABLE IF EXISTS `dynamic_content`;
CREATE TABLE `dynamic_content` (
  `id` int NOT NULL,
  `page_slug` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `section_key` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `item_key` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `content_value` text COLLATE latin1_swedish_ci,
  `media_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_campaign_packs`
--

DROP TABLE IF EXISTS `ecommerce_campaign_packs`;
CREATE TABLE `ecommerce_campaign_packs` (
  `id` int NOT NULL,
  `product_id` int NOT NULL,
  `user_id` int NOT NULL,
  `ugc_images` json DEFAULT NULL,
  `copy_variations` json DEFAULT NULL,
  `posting_calendar_14d` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ecommerce_campaign_packs`
--

INSERT INTO `ecommerce_campaign_packs` (`id`, `product_id`, `user_id`, `ugc_images`, `copy_variations`, `posting_calendar_14d`, `created_at`) VALUES
(1, 3, 2, '[{\"url\": \"assets/images/thumbs/blog-details-img2.png\", \"badge\": \"TOP RATED ⭐\", \"title\": \"Handheld Product Showcase\"}, {\"url\": \"assets/images/thumbs/blog-details-img1.png\", \"badge\": \"50% OFF FLASH SALE\", \"title\": \"Lifestyle Daily Use\"}, {\"url\": \"assets/images/thumbs/team-details-img3.png\", \"badge\": \"VERIFIED BUYER\", \"title\": \"Creator Unboxing Aesthetic\"}]', '[{\"cta\": \"Shop Now with 30-Day Money Back Guarantee\", \"angle\": \"Pain-Point & Instant Relief\", \"headline\": \"Finally, High-Performance Compression Athletic Leggings that actually delivers real results.\", \"primary_text\": \"Stop wasting money on subpar alternatives. Get guaranteed results with High-Performance Compression Athletic Leggings for just $54.00.\"}, {\"cta\": \"Claim Your 20% New Customer Discount\", \"angle\": \"Benefit-Driven & Transformation\", \"headline\": \"Transform your daily routine with High-Performance Compression Athletic Leggings.\", \"primary_text\": \"Over 500+ 5-star reviews can\'t be wrong. Experience the difference starting today for only $54.00.\"}, {\"cta\": \"Order Now - Free Express Shipping Included\", \"angle\": \"FOMO & Limited-Time Flash Sale\", \"headline\": \"⚡ FLASH SALE: High-Performance Compression Athletic Leggings is 40% OFF this weekend only!\", \"primary_text\": \"High demand alert! Inventory is running low on High-Performance Compression Athletic Leggings. Secure yours now before we sell out.\"}]', '[{\"day\": \"Day 1\", \"date\": \"2026-10-06 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 1 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 2\", \"date\": \"2026-10-07 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 2 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 3\", \"date\": \"2026-10-08 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 3 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 4\", \"date\": \"2026-10-09 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 4 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 5\", \"date\": \"2026-10-10 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 5 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 6\", \"date\": \"2026-10-11 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 6 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 7\", \"date\": \"2026-10-12 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 7 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 8\", \"date\": \"2026-10-13 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 8 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 9\", \"date\": \"2026-10-14 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 9 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 10\", \"date\": \"2026-10-15 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 10 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 11\", \"date\": \"2026-10-16 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 11 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 12\", \"date\": \"2026-10-17 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 12 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 13\", \"date\": \"2026-10-18 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 13 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 14\", \"date\": \"2026-10-19 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 14 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}]', '2026-10-05 17:17:23'),
(2, 2, 2, '[{\"url\": \"assets/images/thumbs/team-details-img2.png\", \"badge\": \"TOP RATED ⭐\", \"title\": \"Handheld Product Showcase\"}, {\"url\": \"assets/images/thumbs/blog-details-img1.png\", \"badge\": \"50% OFF FLASH SALE\", \"title\": \"Lifestyle Daily Use\"}, {\"url\": \"assets/images/thumbs/team-details-img3.png\", \"badge\": \"VERIFIED BUYER\", \"title\": \"Creator Unboxing Aesthetic\"}]', '[{\"cta\": \"Shop Now with 30-Day Money Back Guarantee\", \"angle\": \"Pain-Point & Instant Relief\", \"headline\": \"Finally, Ergonomic Wireless Mech Keyboard RGB that actually delivers real results.\", \"primary_text\": \"Stop wasting money on subpar alternatives. Get guaranteed results with Ergonomic Wireless Mech Keyboard RGB for just $129.00.\"}, {\"cta\": \"Claim Your 20% New Customer Discount\", \"angle\": \"Benefit-Driven & Transformation\", \"headline\": \"Transform your daily routine with Ergonomic Wireless Mech Keyboard RGB.\", \"primary_text\": \"Over 500+ 5-star reviews can\'t be wrong. Experience the difference starting today for only $129.00.\"}, {\"cta\": \"Order Now - Free Express Shipping Included\", \"angle\": \"FOMO & Limited-Time Flash Sale\", \"headline\": \"⚡ FLASH SALE: Ergonomic Wireless Mech Keyboard RGB is 40% OFF this weekend only!\", \"primary_text\": \"High demand alert! Inventory is running low on Ergonomic Wireless Mech Keyboard RGB. Secure yours now before we sell out.\"}]', '[{\"day\": \"Day 1\", \"date\": \"2026-10-06 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 1 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 2\", \"date\": \"2026-10-07 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 2 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 3\", \"date\": \"2026-10-08 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 3 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 4\", \"date\": \"2026-10-09 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 4 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 5\", \"date\": \"2026-10-10 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 5 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 6\", \"date\": \"2026-10-11 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 6 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 7\", \"date\": \"2026-10-12 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 7 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 8\", \"date\": \"2026-10-13 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 8 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 9\", \"date\": \"2026-10-14 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 9 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 10\", \"date\": \"2026-10-15 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 10 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 11\", \"date\": \"2026-10-16 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 11 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 12\", \"date\": \"2026-10-17 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 12 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 13\", \"date\": \"2026-10-18 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 13 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 14\", \"date\": \"2026-10-19 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 14 with Ergonomic Wireless Mech Keyboard RGB! Transform your routine today. Available now for $129.00 via link in bio! #wireless-mech-keyboard #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}]', '2026-10-05 17:17:37'),
(3, 1, 2, '[{\"url\": \"assets/images/thumbs/about-five-img1.png\", \"badge\": \"TOP RATED ⭐\", \"title\": \"Handheld Product Showcase\"}, {\"url\": \"assets/images/thumbs/blog-details-img1.png\", \"badge\": \"50% OFF FLASH SALE\", \"title\": \"Lifestyle Daily Use\"}, {\"url\": \"assets/images/thumbs/team-details-img3.png\", \"badge\": \"VERIFIED BUYER\", \"title\": \"Creator Unboxing Aesthetic\"}]', '[{\"cta\": \"Shop Now with 30-Day Money Back Guarantee\", \"angle\": \"Pain-Point & Instant Relief\", \"headline\": \"Finally, Ultra-Hydrating Botanical Glow Serum (50ml) that actually delivers real results.\", \"primary_text\": \"Stop wasting money on subpar alternatives. Get guaranteed results with Ultra-Hydrating Botanical Glow Serum (50ml) for just $38.00.\"}, {\"cta\": \"Claim Your 20% New Customer Discount\", \"angle\": \"Benefit-Driven & Transformation\", \"headline\": \"Transform your daily routine with Ultra-Hydrating Botanical Glow Serum (50ml).\", \"primary_text\": \"Over 500+ 5-star reviews can\'t be wrong. Experience the difference starting today for only $38.00.\"}, {\"cta\": \"Order Now - Free Express Shipping Included\", \"angle\": \"FOMO & Limited-Time Flash Sale\", \"headline\": \"⚡ FLASH SALE: Ultra-Hydrating Botanical Glow Serum (50ml) is 40% OFF this weekend only!\", \"primary_text\": \"High demand alert! Inventory is running low on Ultra-Hydrating Botanical Glow Serum (50ml). Secure yours now before we sell out.\"}]', '[{\"day\": \"Day 1\", \"date\": \"2026-10-06 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 1 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 2\", \"date\": \"2026-10-07 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 2 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 3\", \"date\": \"2026-10-08 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 3 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 4\", \"date\": \"2026-10-09 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 4 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 5\", \"date\": \"2026-10-10 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 5 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 6\", \"date\": \"2026-10-11 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 6 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 7\", \"date\": \"2026-10-12 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 7 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 8\", \"date\": \"2026-10-13 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 8 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 9\", \"date\": \"2026-10-14 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 9 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 10\", \"date\": \"2026-10-15 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 10 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 11\", \"date\": \"2026-10-16 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 11 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 12\", \"date\": \"2026-10-17 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 12 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 13\", \"date\": \"2026-10-18 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 13 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 14\", \"date\": \"2026-10-19 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 14 with Ultra-Hydrating Botanical Glow Serum (50ml)! Transform your routine today. Available now for $38.00 via link in bio! #botanical-glow-serum #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}]', '2026-10-05 17:17:41'),
(4, 3, 2, '[{\"url\": \"assets/images/thumbs/blog-details-img2.png\", \"badge\": \"TOP RATED ⭐\", \"title\": \"Handheld Product Showcase\"}, {\"url\": \"assets/images/thumbs/blog-details-img1.png\", \"badge\": \"50% OFF FLASH SALE\", \"title\": \"Lifestyle Daily Use\"}, {\"url\": \"assets/images/thumbs/team-details-img3.png\", \"badge\": \"VERIFIED BUYER\", \"title\": \"Creator Unboxing Aesthetic\"}]', '[{\"cta\": \"Shop Now with 30-Day Money Back Guarantee\", \"angle\": \"Pain-Point & Instant Relief\", \"headline\": \"Finally, High-Performance Compression Athletic Leggings that actually delivers real results.\", \"primary_text\": \"Stop wasting money on subpar alternatives. Get guaranteed results with High-Performance Compression Athletic Leggings for just $54.00.\"}, {\"cta\": \"Claim Your 20% New Customer Discount\", \"angle\": \"Benefit-Driven & Transformation\", \"headline\": \"Transform your daily routine with High-Performance Compression Athletic Leggings.\", \"primary_text\": \"Over 500+ 5-star reviews can\'t be wrong. Experience the difference starting today for only $54.00.\"}, {\"cta\": \"Order Now - Free Express Shipping Included\", \"angle\": \"FOMO & Limited-Time Flash Sale\", \"headline\": \"⚡ FLASH SALE: High-Performance Compression Athletic Leggings is 40% OFF this weekend only!\", \"primary_text\": \"High demand alert! Inventory is running low on High-Performance Compression Athletic Leggings. Secure yours now before we sell out.\"}]', '[{\"day\": \"Day 1\", \"date\": \"2026-10-06 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 1 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 2\", \"date\": \"2026-10-07 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 2 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 3\", \"date\": \"2026-10-08 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 3 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 4\", \"date\": \"2026-10-09 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 4 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 5\", \"date\": \"2026-10-10 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 5 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 6\", \"date\": \"2026-10-11 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 6 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 7\", \"date\": \"2026-10-12 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 7 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 8\", \"date\": \"2026-10-13 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 8 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 9\", \"date\": \"2026-10-14 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 9 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 10\", \"date\": \"2026-10-15 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 10 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 11\", \"date\": \"2026-10-16 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 11 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 12\", \"date\": \"2026-10-17 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 12 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 13\", \"date\": \"2026-10-18 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 13 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 14\", \"date\": \"2026-10-19 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 14 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}]', '2026-10-05 17:17:44'),
(5, 6, 1, '[{\"url\": \"assets/images/thumbs/blog-details-img2.png\", \"badge\": \"TOP RATED ⭐\", \"title\": \"Handheld Product Showcase\"}, {\"url\": \"assets/images/thumbs/blog-details-img1.png\", \"badge\": \"50% OFF FLASH SALE\", \"title\": \"Lifestyle Daily Use\"}, {\"url\": \"assets/images/thumbs/team-details-img3.png\", \"badge\": \"VERIFIED BUYER\", \"title\": \"Creator Unboxing Aesthetic\"}]', '[{\"cta\": \"Shop Now with 30-Day Money Back Guarantee\", \"angle\": \"Pain-Point & Instant Relief\", \"headline\": \"Finally, High-Performance Compression Athletic Leggings that actually delivers real results.\", \"primary_text\": \"Stop wasting money on subpar alternatives. Get guaranteed results with High-Performance Compression Athletic Leggings for just $54.00.\"}, {\"cta\": \"Claim Your 20% New Customer Discount\", \"angle\": \"Benefit-Driven & Transformation\", \"headline\": \"Transform your daily routine with High-Performance Compression Athletic Leggings.\", \"primary_text\": \"Over 500+ 5-star reviews can\'t be wrong. Experience the difference starting today for only $54.00.\"}, {\"cta\": \"Order Now - Free Express Shipping Included\", \"angle\": \"FOMO & Limited-Time Flash Sale\", \"headline\": \"⚡ FLASH SALE: High-Performance Compression Athletic Leggings is 40% OFF this weekend only!\", \"primary_text\": \"High demand alert! Inventory is running low on High-Performance Compression Athletic Leggings. Secure yours now before we sell out.\"}]', '[{\"day\": \"Day 1\", \"date\": \"2026-10-12 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 1 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 2\", \"date\": \"2026-10-13 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 2 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 3\", \"date\": \"2026-10-14 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 3 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 4\", \"date\": \"2026-10-15 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 4 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 5\", \"date\": \"2026-10-16 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 5 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 6\", \"date\": \"2026-10-17 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 6 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 7\", \"date\": \"2026-10-18 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 7 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 8\", \"date\": \"2026-10-19 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 8 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 9\", \"date\": \"2026-10-20 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 9 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 10\", \"date\": \"2026-10-21 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 10 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 11\", \"date\": \"2026-10-22 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 11 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"facebook\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 12\", \"date\": \"2026-10-23 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 12 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"twitter\", \"post_type\": \"video_reel\"}, {\"day\": \"Day 13\", \"date\": \"2026-10-24 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 13 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"instagram\", \"post_type\": \"carousel_image\"}, {\"day\": \"Day 14\", \"date\": \"2026-10-25 18:00:00\", \"status\": \"scheduled\", \"caption\": \"Day 14 with High-Performance Compression Athletic Leggings! Transform your routine today. Available now for $54.00 via link in bio! #compression-athletic-leggings #shopping #bestseller\", \"platform\": \"tiktok\", \"post_type\": \"carousel_image\"}]', '2026-10-11 16:18:40');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_products`
--

DROP TABLE IF EXISTS `ecommerce_products`;
CREATE TABLE `ecommerce_products` (
  `id` int NOT NULL,
  `store_id` int NOT NULL,
  `user_id` int NOT NULL,
  `product_title` varchar(500) COLLATE latin1_swedish_ci NOT NULL,
  `product_handle` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `currency` varchar(10) COLLATE latin1_swedish_ci DEFAULT 'USD',
  `image_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `description` text COLLATE latin1_swedish_ci,
  `rating` decimal(3,2) DEFAULT '5.00',
  `reviews_count` int DEFAULT '0',
  `auto_pack_generated` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ecommerce_products`
--

INSERT INTO `ecommerce_products` (`id`, `store_id`, `user_id`, `product_title`, `product_handle`, `price`, `currency`, `image_url`, `description`, `rating`, `reviews_count`, `auto_pack_generated`, `created_at`) VALUES
(1, 1, 2, 'Ultra-Hydrating Botanical Glow Serum (50ml)', 'botanical-glow-serum', 38.00, 'USD', 'assets/images/thumbs/about-five-img1.png', 'Formulated with organic hyaluronic acid and niacinamide. Clinically proven to hydrate and brighten skin tone in 7 days.', 4.90, 328, 1, '2026-10-05 17:17:10'),
(2, 1, 2, 'Ergonomic Wireless Mech Keyboard RGB', 'wireless-mech-keyboard', 129.00, 'USD', 'assets/images/thumbs/team-details-img2.png', 'Custom tactile switches, 80-hour battery life, aerospace aluminum casing with seamless Bluetooth 5.3 pairing.', 4.80, 184, 1, '2026-10-05 17:17:10'),
(3, 1, 2, 'High-Performance Compression Athletic Leggings', 'compression-athletic-leggings', 54.00, 'USD', 'assets/images/thumbs/blog-details-img2.png', 'Squat-proof seamless fabric, moisture-wicking technology with high-waist posture support for gym and daily wear.', 4.95, 512, 1, '2026-10-05 17:17:10'),
(4, 2, 1, 'Ultra-Hydrating Botanical Glow Serum (50ml)', 'botanical-glow-serum', 38.00, 'USD', 'assets/images/thumbs/about-five-img1.png', 'Formulated with organic hyaluronic acid and niacinamide. Clinically proven to hydrate and brighten skin tone in 7 days.', 4.90, 328, 0, '2026-10-11 16:18:32'),
(5, 2, 1, 'Ergonomic Wireless Mech Keyboard RGB', 'wireless-mech-keyboard', 129.00, 'USD', 'assets/images/thumbs/team-details-img2.png', 'Custom tactile switches, 80-hour battery life, aerospace aluminum casing with seamless Bluetooth 5.3 pairing.', 4.80, 184, 0, '2026-10-11 16:18:32'),
(6, 2, 1, 'High-Performance Compression Athletic Leggings', 'compression-athletic-leggings', 54.00, 'USD', 'assets/images/thumbs/blog-details-img2.png', 'Squat-proof seamless fabric, moisture-wicking technology with high-waist posture support for gym and daily wear.', 4.95, 512, 1, '2026-10-11 16:18:32'),
(7, 3, 100000, 'Shopify T-Shirt', 'shopify-t-shirt', 19.00, 'USD', 'https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt.png?v=1155241139', 'So this is a product.\n\n\n	The text you see here is a Product Description. Every product has a price, a weight, a picture and a description. To edit the description of this product or to create a new product you can go to the Products Tab of the administration menu.\n\n\n	Once you have mastered the creation and editing of products you will want your products to show up on your Shopify site. There is a two step process to do this.\n\n\n	First you need to add your products to a Collection. A Collection is an easy way to group products together. If you go to the Collections Tab of the administration menu you can begin creating collections and adding products to them.\n\n\n	Second you&#8217;ll need to create a link from your shop&#8217;s navigation menu to your Collections. You can do this by going to the Navigations Tab of the administration menu and clicking on &#8220;Add a link&#8221;.\n\n\n	Good luck with your shop!', 0.00, 0, 0, '2026-10-17 08:30:59'),
(8, 4, 100000, 'Shopify T-Shirt', 'shopify-t-shirt', 19.00, 'USD', 'https://cdn.shopify.com/s/files/1/0000/2442/products/shopify_shirt.png?v=1155241139', 'So this is a product.\n\n\n	The text you see here is a Product Description. Every product has a price, a weight, a picture and a description. To edit the description of this product or to create a new product you can go to the Products Tab of the administration menu.\n\n\n	Once you have mastered the creation and editing of products you will want your products to show up on your Shopify site. There is a two step process to do this.\n\n\n	First you need to add your products to a Collection. A Collection is an easy way to group products together. If you go to the Collections Tab of the administration menu you can begin creating collections and adding products to them.\n\n\n	Second you&#8217;ll need to create a link from your shop&#8217;s navigation menu to your Collections. You can do this by going to the Navigations Tab of the administration menu and clicking on &#8220;Add a link&#8221;.\n\n\n	Good luck with your shop!', 0.00, 0, 0, '2026-10-17 08:34:12');

-- --------------------------------------------------------

--
-- Table structure for table `ecommerce_stores`
--

DROP TABLE IF EXISTS `ecommerce_stores`;
CREATE TABLE `ecommerce_stores` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `store_type` enum('shopify','woocommerce','custom') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'shopify',
  `store_name` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `store_url` varchar(500) COLLATE latin1_swedish_ci NOT NULL,
  `api_key` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `is_connected` tinyint(1) DEFAULT '1',
  `last_synced_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ecommerce_stores`
--

INSERT INTO `ecommerce_stores` (`id`, `user_id`, `store_type`, `store_name`, `store_url`, `api_key`, `is_connected`, `last_synced_at`, `created_at`) VALUES
(1, 2, 'custom', 'JMN', 'http://seopp.test', NULL, 1, '2026-10-05 16:17:10', '2026-10-05 17:17:10'),
(2, 1, 'shopify', 'JMN', 'http://seopp.test', NULL, 1, '2026-10-11 15:18:32', '2026-10-11 16:18:32');

-- --------------------------------------------------------

--
-- Table structure for table `email_campaigns`
--

DROP TABLE IF EXISTS `email_campaigns`;
CREATE TABLE `email_campaigns` (
  `id` int NOT NULL,
  `admin_id` int NOT NULL,
  `subject` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `body` text COLLATE latin1_swedish_ci,
  `status` enum('draft','sending','sent') COLLATE latin1_swedish_ci DEFAULT 'draft',
  `sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_campaign_recipients`
--

DROP TABLE IF EXISTS `email_campaign_recipients`;
CREATE TABLE `email_campaign_recipients` (
  `id` int NOT NULL,
  `campaign_id` int NOT NULL,
  `user_id` int NOT NULL,
  `opened` tinyint DEFAULT '0',
  `clicked` tinyint DEFAULT '0',
  `sent_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_logs`
--

DROP TABLE IF EXISTS `email_logs`;
CREATE TABLE `email_logs` (
  `id` int NOT NULL,
  `sender_id` int DEFAULT NULL,
  `recipient` varchar(255) DEFAULT NULL,
  `subject` varchar(500) DEFAULT NULL,
  `body` text,
  `type` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_0900_ai_ci;

--
-- Dumping data for table `email_logs`
--

INSERT INTO `email_logs` (`id`, `sender_id`, `recipient`, `subject`, `body`, `type`, `status`, `sent_at`) VALUES
(1, NULL, 'jmauricennadi@gmail.com', 'Payment Successful', NULL, 'branded', 'failed', '2026-09-22 20:32:37'),
(2, NULL, 'jotahecomng@gmail.com', 'Account Connected', NULL, 'branded', 'sent', '2026-09-24 14:13:02'),
(3, NULL, 'jotahecomng@gmail.com', 'Account Connected', NULL, 'branded', 'sent', '2026-09-24 14:15:59'),
(4, NULL, 'jotahecomng@gmail.com', 'Social Account Connected in Real-Time', NULL, 'branded', 'sent', '2026-09-24 15:17:48'),
(5, NULL, 'jotahecomng@gmail.com', 'Social Account Connected in Real-Time', NULL, 'branded', 'sent', '2026-09-24 15:18:14'),
(6, NULL, 'jotahecomng@gmail.com', 'OAuth Account Connected', NULL, 'branded', 'sent', '2026-09-24 16:30:59'),
(7, NULL, 'admin@adsbooster.net', 'New Message from Jamachi Mauricennadi on Adsbooster', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>You Have a New Message 💬</h2>\n                    <p>Hi Admin User,</p>\n                    <p><b>Jamachi Mauricennadi</b> sent you a direct message on Adsbooster:</p>\n                    <div style=\"background:#080c14;border-left:3px solid #c8ff00;border-radius:6px;padding:16px 20px;margin:20px 0;font-style:italic;\">\n                        \"Thanks for the update!\"\n                    </div>\n                    <div style=\"text-align:center;\">\n                        <a href=\"https://adsbooster.net/p2p-chat.php?user=3\" class=\"btn-action\">Reply to Message &rarr;</a>\n                    </div>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'p2p_message', 'sent', '2026-09-25 10:57:27'),
(8, NULL, 'jotahecomng@gmail.com', 'Your Adsbooster Security Verification Code: 817738', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>Two-Factor Security Verification 🔒</h2>\n                    <p>Hi Jamachi Mauricennadi,</p>\n                    <p>Use the following 6-digit one-time code to complete your login or security confirmation:</p>\n                    <div class=\"code-box\">817738</div>\n                    <p style=\"color:#94a3b8;font-size:13px;text-align:center;\">This code expires in 10 minutes. If you did not attempt to sign in, please update your account password immediately.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'two_factor_code', 'sent', '2026-09-25 11:17:49'),
(9, NULL, 'jotahecomng@gmail.com', 'Your Adsbooster Security Verification Code: 501152', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>Two-Factor Security Verification 🔒</h2>\n                    <p>Hi Jamachi Mauricennadi,</p>\n                    <p>Use the following 6-digit one-time code to complete your login or security confirmation:</p>\n                    <div class=\"code-box\">501152</div>\n                    <p style=\"color:#94a3b8;font-size:13px;text-align:center;\">This code expires in 10 minutes. If you did not attempt to sign in, please update your account password immediately.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'two_factor_code', 'sent', '2026-09-25 12:12:08'),
(10, NULL, 'jotahecomng@gmail.com', 'Social Account Connected', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    <p>Hi Jamachi Mauricennadi,</p><p>Meta (Facebook) Profile was successfully verified and linked to your Meta (Facebook) publishing channel in real time.</p><p><a href=\"/social-connect.php\">View in dashboard →</a></p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'branded', 'sent', '2026-09-25 12:33:15'),
(11, NULL, 'jmauricennadi@gmail.com', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi Jamachi Maurice Mauricennadi,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-05 20:15:01 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-05 19:15:01'),
(12, NULL, 'admin@adsbooster.net', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi Admin User,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-07 19:08:37 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-07 18:08:37'),
(13, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 11:24:58 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 10:25:04'),
(14, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 12:32:57 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 11:32:57'),
(15, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 12:33:28 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 11:33:28'),
(16, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 12:33:57 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 11:33:57'),
(17, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 12:38:30 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 11:38:30'),
(18, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 12:43:56 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 11:43:56'),
(19, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 12:50:21 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 11:50:22'),
(20, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 12:50:57 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 11:50:57'),
(21, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 12:51:20 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 11:51:21'),
(22, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 13:04:24 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 12:04:24');
INSERT INTO `email_logs` (`id`, `sender_id`, `recipient`, `subject`, `body`, `type`, `status`, `sent_at`) VALUES
(23, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 13:11:47 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 12:11:47'),
(24, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 13:15:09 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 12:15:09'),
(25, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 14:42:51 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 13:42:51'),
(26, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 14:43:59 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 13:43:59'),
(27, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 20:36:18 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 19:36:20'),
(28, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 20:39:29 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 19:39:29'),
(29, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 20:44:56 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 19:44:57'),
(30, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 20:45:21 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 19:45:22'),
(31, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 20:45:44 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 19:45:44'),
(32, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-12 20:48:50 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-12 19:48:50'),
(33, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-13 14:22:28 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-13 13:22:30'),
(34, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n<title>Adsbooster.net</title>\n<style>\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\n  .email-brand span { color: #c8ff00; }\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\n  .email-body a { color: #c8ff00; }\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\n</style>\n</head>\n<body>\n<div class=\"email-container\">\n  <div class=\"email-header\">\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\n  </div>\n  <div class=\"email-body\">\n    \n                    <h2>New Login Detected 🛡️</h2>\n                    <p>Hi E2E Tester,</p>\n                    <p>A new login was detected on your Adsbooster account:</p>\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> ::1</p>\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-14 14:28:08 UTC</p>\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\n                    </div>\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\n  </div>\n  <div class=\"email-footer\">\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\n  </div>\n</div>\n</body>\n</html>', 'login_alert', 'sent', '2026-10-14 13:28:10'),
(35, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n<meta charset=\"UTF-8\">\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n<title>Adsbooster.net</title>\r\n<style>\r\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\r\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\r\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\r\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\r\n  .email-brand span { color: #c8ff00; }\r\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\r\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\r\n  .email-body a { color: #c8ff00; }\r\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\r\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\r\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\r\n</style>\r\n</head>\r\n<body>\r\n<div class=\"email-container\">\r\n  <div class=\"email-header\">\r\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\r\n  </div>\r\n  <div class=\"email-body\">\r\n    \r\n                    <h2>New Login Detected 🛡️</h2>\r\n                    <p>Hi E2E Tester,</p>\r\n                    <p>A new login was detected on your Adsbooster account:</p>\r\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\r\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\r\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-15 16:58:38 UTC</p>\r\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\r\n                    </div>\r\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\r\n  </div>\r\n  <div class=\"email-footer\">\r\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\r\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\r\n  </div>\r\n</div>\r\n</body>\r\n</html>', 'login_alert', 'sent', '2026-10-15 15:58:38'),
(36, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n<meta charset=\"UTF-8\">\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n<title>Adsbooster.net</title>\r\n<style>\r\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\r\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\r\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\r\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\r\n  .email-brand span { color: #c8ff00; }\r\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\r\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\r\n  .email-body a { color: #c8ff00; }\r\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\r\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\r\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\r\n</style>\r\n</head>\r\n<body>\r\n<div class=\"email-container\">\r\n  <div class=\"email-header\">\r\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\r\n  </div>\r\n  <div class=\"email-body\">\r\n    \r\n                    <h2>New Login Detected 🛡️</h2>\r\n                    <p>Hi E2E Tester,</p>\r\n                    <p>A new login was detected on your Adsbooster account:</p>\r\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\r\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\r\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-16 18:39:33 UTC</p>\r\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\r\n                    </div>\r\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\r\n  </div>\r\n  <div class=\"email-footer\">\r\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\r\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\r\n  </div>\r\n</div>\r\n</body>\r\n</html>', 'login_alert', 'sent', '2026-10-16 17:39:35'),
(37, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n<meta charset=\"UTF-8\">\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n<title>Adsbooster.net</title>\r\n<style>\r\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\r\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\r\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\r\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\r\n  .email-brand span { color: #c8ff00; }\r\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\r\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\r\n  .email-body a { color: #c8ff00; }\r\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\r\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\r\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\r\n</style>\r\n</head>\r\n<body>\r\n<div class=\"email-container\">\r\n  <div class=\"email-header\">\r\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\r\n  </div>\r\n  <div class=\"email-body\">\r\n    \r\n                    <h2>New Login Detected 🛡️</h2>\r\n                    <p>Hi E2E Tester,</p>\r\n                    <p>A new login was detected on your Adsbooster account:</p>\r\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\r\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\r\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-17 04:17:28 UTC</p>\r\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\r\n                    </div>\r\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\r\n  </div>\r\n  <div class=\"email-footer\">\r\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\r\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\r\n  </div>\r\n</div>\r\n</body>\r\n</html>', 'login_alert', 'sent', '2026-10-17 03:17:33');
INSERT INTO `email_logs` (`id`, `sender_id`, `recipient`, `subject`, `body`, `type`, `status`, `sent_at`) VALUES
(38, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n<meta charset=\"UTF-8\">\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n<title>Adsbooster.net</title>\r\n<style>\r\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\r\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\r\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\r\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\r\n  .email-brand span { color: #c8ff00; }\r\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\r\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\r\n  .email-body a { color: #c8ff00; }\r\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\r\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\r\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\r\n</style>\r\n</head>\r\n<body>\r\n<div class=\"email-container\">\r\n  <div class=\"email-header\">\r\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\r\n  </div>\r\n  <div class=\"email-body\">\r\n    \r\n                    <h2>New Login Detected 🛡️</h2>\r\n                    <p>Hi E2E Tester,</p>\r\n                    <p>A new login was detected on your Adsbooster account:</p>\r\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\r\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\r\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-17 08:29:53 UTC</p>\r\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\r\n                    </div>\r\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\r\n  </div>\r\n  <div class=\"email-footer\">\r\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\r\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\r\n  </div>\r\n</div>\r\n</body>\r\n</html>', 'login_alert', 'sent', '2026-10-17 07:29:55'),
(39, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n<meta charset=\"UTF-8\">\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n<title>Adsbooster.net</title>\r\n<style>\r\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\r\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\r\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\r\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\r\n  .email-brand span { color: #c8ff00; }\r\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\r\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\r\n  .email-body a { color: #c8ff00; }\r\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\r\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\r\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\r\n</style>\r\n</head>\r\n<body>\r\n<div class=\"email-container\">\r\n  <div class=\"email-header\">\r\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\r\n  </div>\r\n  <div class=\"email-body\">\r\n    \r\n                    <h2>New Login Detected 🛡️</h2>\r\n                    <p>Hi E2E Tester,</p>\r\n                    <p>A new login was detected on your Adsbooster account:</p>\r\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\r\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\r\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-17 18:12:29 UTC</p>\r\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\r\n                    </div>\r\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\r\n  </div>\r\n  <div class=\"email-footer\">\r\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\r\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\r\n  </div>\r\n</div>\r\n</body>\r\n</html>', 'login_alert', 'sent', '2026-10-17 17:12:30'),
(40, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n<meta charset=\"UTF-8\">\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n<title>Adsbooster.net</title>\r\n<style>\r\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\r\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\r\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\r\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\r\n  .email-brand span { color: #c8ff00; }\r\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\r\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\r\n  .email-body a { color: #c8ff00; }\r\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\r\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\r\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\r\n</style>\r\n</head>\r\n<body>\r\n<div class=\"email-container\">\r\n  <div class=\"email-header\">\r\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\r\n  </div>\r\n  <div class=\"email-body\">\r\n    \r\n                    <h2>New Login Detected 🛡️</h2>\r\n                    <p>Hi E2E Tester,</p>\r\n                    <p>A new login was detected on your Adsbooster account:</p>\r\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\r\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\r\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-18 16:18:00 UTC</p>\r\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\r\n                    </div>\r\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\r\n  </div>\r\n  <div class=\"email-footer\">\r\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\r\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\r\n  </div>\r\n</div>\r\n</body>\r\n</html>', 'login_alert', 'sent', '2026-10-18 15:18:02'),
(41, NULL, 'e2e@test.local', 'Security Notice: New Login to Your Account', '<!DOCTYPE html>\r\n<html lang=\"en\">\r\n<head>\r\n<meta charset=\"UTF-8\">\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n<title>Adsbooster.net</title>\r\n<style>\r\n  body { margin: 0; padding: 0; background-color: #080c14; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; color: #f8fafc; }\r\n  .email-container { max-width: 600px; margin: 40px auto; background-color: #0d1524; border: 1px solid #1e293b; border-radius: 16px; overflow: hidden; }\r\n  .email-header { padding: 32px 36px 24px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }\r\n  .email-brand { font-size: 24px; font-weight: 800; color: #ffffff; text-decoration: none; letter-spacing: -0.5px; }\r\n  .email-brand span { color: #c8ff00; }\r\n  .email-body { padding: 36px; line-height: 1.6; font-size: 15px; color: #f8fafc; }\r\n  .email-body h1, .email-body h2, .email-body h3 { color: #ffffff; margin-top: 0; }\r\n  .email-body a { color: #c8ff00; }\r\n  .btn-action { display: inline-block; background-color: #c8ff00; color: #080c14 !important; font-weight: 700; font-size: 14px; padding: 13px 30px; text-decoration: none; border-radius: 10px; margin: 20px 0; }\r\n  .code-box { background: #080c14; border: 1px solid #c8ff00; border-radius: 12px; padding: 20px; text-align: center; font-size: 32px; font-family: monospace; font-weight: 800; letter-spacing: 8px; color: #c8ff00; margin: 24px 0; }\r\n  .email-footer { padding: 24px 36px; background-color: #060910; border-top: 1px solid #1e293b; text-align: center; font-size: 12px; color: #94a3b8; }\r\n</style>\r\n</head>\r\n<body>\r\n<div class=\"email-container\">\r\n  <div class=\"email-header\">\r\n    <a href=\"https://adsbooster.net\" class=\"email-brand\">Adsbooster<span>.net</span></a>\r\n  </div>\r\n  <div class=\"email-body\">\r\n    \r\n                    <h2>New Login Detected 🛡️</h2>\r\n                    <p>Hi E2E Tester,</p>\r\n                    <p>A new login was detected on your Adsbooster account:</p>\r\n                    <div style=\"background:#080c14;border:1px solid #1e293b;border-radius:10px;padding:16px;margin:20px 0;\">\r\n                        <p style=\"margin:0 0 6px;\"><b>IP Address:</b> 127.0.0.1</p>\r\n                        <p style=\"margin:0 0 6px;\"><b>Time:</b> 2026-10-18 17:29:37 UTC</p>\r\n                        <p style=\"margin:0;\"><b>Location:</b> Web App Session</p>\r\n                    </div>\r\n                    <p style=\"color:#94a3b8;font-size:13px;\">If this was you, no action is needed. If you did not authorize this login, reset your password immediately from the privacy center.</p>\r\n  </div>\r\n  <div class=\"email-footer\">\r\n    <p style=\"margin:0 0 8px;\">&copy; 2026 Adsbooster.net. Multi-network ad automation, social scheduler &amp; directory.</p>\r\n    <p style=\"margin:0;\">Need assistance? Contact our team at <a href=\"mailto:support@adsbooster.net\" style=\"color:#94a3b8;\">support@adsbooster.net</a></p>\r\n  </div>\r\n</div>\r\n</body>\r\n</html>', 'login_alert', 'sent', '2026-10-18 16:29:37');

-- --------------------------------------------------------

--
-- Table structure for table `fraud_flags`
--

DROP TABLE IF EXISTS `fraud_flags`;
CREATE TABLE `fraud_flags` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `flag_type` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `description` text COLLATE latin1_swedish_ci,
  `severity` enum('low','medium','high') COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('flagged','reviewed','dismissed') COLLATE latin1_swedish_ci DEFAULT 'flagged',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
CREATE TABLE `invoices` (
  `id` int NOT NULL,
  `transaction_id` int NOT NULL,
  `invoice_number` varchar(50) DEFAULT NULL,
  `file_path` varchar(500) DEFAULT NULL,
  `generated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_0900_ai_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `transaction_id`, `invoice_number`, `file_path`, `generated_at`) VALUES
(1, 3, 'INV-TESTVERIFY', 'uploads/invoices/INV-TESTVERIFY.html', '2026-09-22 20:28:29'),
(2, 4, 'INV-TESTVERIFY', 'uploads/invoices/INV-TESTVERIFY.html', '2026-09-22 20:29:39'),
(3, 5, 'INV-TESTVERIFY', 'uploads/invoices/INV-TESTVERIFY.html', '2026-09-22 20:32:37');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `slug` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `category` varchar(100) COLLATE latin1_swedish_ci NOT NULL DEFAULT 'Advertising',
  `job_type` enum('full-time','part-time','contract','freelance','bounty') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'contract',
  `location_type` enum('remote','hybrid','on-site') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'remote',
  `location` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `salary_min` decimal(12,2) DEFAULT NULL,
  `salary_max` decimal(12,2) DEFAULT NULL,
  `salary_currency` varchar(10) COLLATE latin1_swedish_ci NOT NULL DEFAULT 'USD',
  `salary_period` enum('hourly','monthly','project','yearly') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'project',
  `description` text COLLATE latin1_swedish_ci NOT NULL,
  `requirements` text COLLATE latin1_swedish_ci,
  `skills_required` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('open','in_progress','completed','closed','paused') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'open',
  `featured` tinyint(1) NOT NULL DEFAULT '0',
  `views_count` int NOT NULL DEFAULT '0',
  `applications_count` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `user_id`, `title`, `slug`, `category`, `job_type`, `location_type`, `location`, `salary_min`, `salary_max`, `salary_currency`, `salary_period`, `description`, `requirements`, `skills_required`, `status`, `featured`, `views_count`, `applications_count`, `created_at`, `updated_at`) VALUES
(1, 1, 'Senior Meta & TikTok Media Buyer (Scaling D2C Brand from $50k to $200k/mo)', 'senior-meta-tiktok-media-buyer-scaling-d2c', 'Media Buying & Ads Scaling', 'contract', 'remote', 'Worldwide / US Timezones', 3000.00, 6000.00, 'USD', 'monthly', 'We are looking for an experienced Media Buyer to manage and scale our paid acquisition across Meta (Facebook/Instagram) and TikTok Ads.\n\nYour primary objective is maintaining a 3.2x+ blended ROAS while aggressively testing ad creative hooks, audience segments, and bid strategies.', '- At least 3 years verifiable experience in paid social media buying.\n- Experience managing accounts with >$30,000 monthly ad spend.\n- Deep understanding of creative testing frameworks and post-iOS14 attribution.', 'Meta Ads, TikTok Ads, ROAS Scaling, Creative Strategy, Triple Whale', 'open', 1, 66, 7, '2026-09-23 12:32:55', '2026-10-15 15:44:14'),
(2, 1, 'UGC Video Creator & Video Editor for TikTok/Reels ($150 per delivered video)', 'ugc-video-creator-editor-tiktok-reels', 'UGC Video & Reel Creation', 'bounty', 'remote', 'Remote', 150.00, 450.00, 'USD', 'project', 'Seeking charismatic, high-energy UGC creators to film and edit 30-45 second authentic vertical video ads for our fitness and wellness products.\n\nScript angles, storyboards, and sample products will be shipped directly to you.', '- Modern smartphone camera with 4K recording.\n- Crisp audio equipment (lavalier mic preferred).\n- Experience with dynamic text captions, fast cuts, and trending b-roll.', 'UGC Video, CapCut, TikTok Trends, On-Camera Talent, Premiere Pro', 'open', 1, 112, 14, '2026-09-24 12:32:55', '2026-09-25 13:32:55'),
(3, 1, 'Direct Response Ad Copywriter for Omnichannel Ad Campaigns', 'direct-response-ad-copywriter-omnichannel', 'Ad Copywriting & Scripts', 'freelance', 'remote', 'Remote', 1200.00, 2500.00, 'USD', 'monthly', 'Looking for a seasoned direct-response copywriter to write compelling ad angles, hook variations, primary text, and advertorial landing pages for our high-growth ecommerce brand.', '- Proven track record writing high-converting Facebook/Instagram ad copy.\n- Ability to rapidly brainstorm 20+ viral hook variations per campaign.\n- Excellent English writing skills with emotional trigger mastery.', 'Direct Response Copy, Hook Generation, Landing Page Copy, Meta Ad Copy', 'open', 0, 31, 5, '2026-09-22 12:32:55', '2026-09-25 13:32:55'),
(4, 1, 'B2B LinkedIn & Google Search Performance Specialist', 'b2b-linkedin-google-search-specialist', 'TikTok & Meta Optimization', 'contract', 'remote', 'US / UK Remote', 2000.00, 4000.00, 'USD', 'project', 'B2B SaaS platform seeking a Google Ads & LinkedIn Campaign Architect to audit existing search campaigns, restructure keyword intent match types, and implement lead form conversion ads.', '- Google Ads Certified with 3+ years managing B2B lead gen accounts.\n- Proven reduction in cost-per-qualified-lead (SQL).\n- LinkedIn Campaign Manager proficiency.', 'Google Ads, LinkedIn Ads, B2B Lead Gen, Tag Manager, Conversion Tracking', 'open', 0, 23, 3, '2026-09-21 12:32:55', '2026-09-25 13:40:26');

-- --------------------------------------------------------

--
-- Table structure for table `jobs_services`
--

DROP TABLE IF EXISTS `jobs_services`;
CREATE TABLE `jobs_services` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `slug` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `type` enum('job','service','gig') COLLATE latin1_swedish_ci DEFAULT 'job',
  `category` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `budget_type` enum('fixed','hourly','bounty') COLLATE latin1_swedish_ci DEFAULT 'fixed',
  `budget_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `description` text COLLATE latin1_swedish_ci NOT NULL,
  `skills_required` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `location_type` enum('remote','onsite','hybrid') COLLATE latin1_swedish_ci DEFAULT 'remote',
  `location` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `contact_email` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `contact_phone` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('active','paused','completed','closed') COLLATE latin1_swedish_ci DEFAULT 'active',
  `views_count` int DEFAULT '0',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `jobs_services`
--

INSERT INTO `jobs_services` (`id`, `user_id`, `title`, `slug`, `type`, `category`, `budget_type`, `budget_amount`, `description`, `skills_required`, `location_type`, `location`, `contact_email`, `contact_phone`, `status`, `views_count`, `created_at`) VALUES
(1, 1, 'Senior Meta & TikTok Media Buyer for E-commerce DTC Brand', 'senior-meta-tiktok-media-buyer-dtc', 'job', 'Paid Media & Advertising', 'hourly', 65.00, 'Looking for an experienced performance marketer to manage $40k/month Meta and TikTok ad spend. Must be proficient in UGC creative testing, Pixel tracking, and ROAS scaling.', 'Meta Ads, TikTok Ads Manager, UGC Creatives, CBO, Retargeting', 'remote', 'Global / Remote', 'careers@adsbooster.net', '+1 (555) 392-1084', 'active', 0, '2026-09-20 11:47:54'),
(2, 1, 'Custom 9:16 UGC Video Creator & Short-Form Video Producer', 'custom-ugc-video-creator-short-form', 'service', 'Creative & Video Production', 'fixed', 350.00, 'I produce high-converting vertical UGC reels, hooks, and dynamic voiceover videos tailored for TikTok, Reels, and YouTube Shorts. Turnaround in 48 hours with 3 hook variations.', 'UGC Video, CapCut, TikTok Scripting, Hook Optimization, Lighting', 'remote', 'United States / Remote', 'creator@adsbooster.net', '+1 (555) 482-9921', 'active', 0, '2026-09-22 11:47:54'),
(3, 1, 'Google Search & Performance Max Campaign Audit & Rebuild', 'google-search-pmax-audit-rebuild', 'service', 'Search Engine Marketing', 'fixed', 750.00, 'Full account audit, negative keyword lists, conversion tracking verification, and PMax campaign segmentation designed to reduce wasted ad spend and lift conversion rate.', 'Google Ads, Performance Max, GA4, GTM, Conversion Tracking', 'remote', 'London, UK / Remote', 'audit@adsbooster.net', '+44 20 7946 0912', 'active', 0, '2026-09-24 11:47:54');

-- --------------------------------------------------------

--
-- Table structure for table `marketplace_items`
--

DROP TABLE IF EXISTS `marketplace_items`;
CREATE TABLE `marketplace_items` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `item_type` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'product',
  `listing_type` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `title` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `slug` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `category` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `featured_image` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `image_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `description` text COLLATE latin1_swedish_ci,
  `seller_verified` tinyint DEFAULT '0',
  `contact_email` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `website_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('active','inactive','pending') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `featured` tinyint DEFAULT '0',
  `views_count` int DEFAULT '0',
  `rating` decimal(3,2) DEFAULT '0.00',
  `is_boosted` tinyint DEFAULT '0',
  `boost_expires_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `business_type` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `address` text COLLATE latin1_swedish_ci,
  `phone` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `whatsapp` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `google_maps_url` text COLLATE latin1_swedish_ci,
  `google_maps_embed` text COLLATE latin1_swedish_ci,
  `contact_method` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'direct',
  `listing_fee` decimal(10,2) DEFAULT '0.00',
  `is_free_with_plan` tinyint DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `marketplace_items`
--

INSERT INTO `marketplace_items` (`id`, `user_id`, `item_type`, `listing_type`, `title`, `slug`, `category`, `price`, `featured_image`, `image_url`, `description`, `seller_verified`, `contact_email`, `website_url`, `status`, `featured`, `views_count`, `rating`, `is_boosted`, `boost_expires_at`, `created_at`, `updated_at`, `business_type`, `address`, `phone`, `whatsapp`, `google_maps_url`, `google_maps_embed`, `contact_method`, `listing_fee`, `is_free_with_plan`) VALUES
(1, 1, 'business', NULL, 'Apex Growth Media & Performance Advertising', 'apex-growth-media-performance-advertising', 'Marketing & Advertising', 299.00, 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=800&auto=format&fit=crop', NULL, 'Full-service omnichannel growth agency specializing in TikTok scaling, Meta ad optimization, and conversion landing pages.', 1, 'contact@apexgrowth.io', NULL, 'active', 1, 845, 4.95, 1, NULL, '2026-09-25 10:53:28', '2026-10-18 16:51:07', 'Agency', '742 Evergreen Terrace, Manhattan, NY', '+1 (555) 019-2831', '+15550192831', 'https://maps.google.com/?q=Manhattan,NY', NULL, 'direct', 0.00, 1),
(2, 1, 'place', NULL, 'The Grand Horizon Luxury Suites & Resort', 'grand-horizon-luxury-suites-resort', 'Hotels & Hospitality', 180.00, 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800&auto=format&fit=crop', NULL, 'Five-star coastal suites featuring oceanview balconies, private infinity pool, executive conference rooms, and 24/7 concierge.', 1, 'reservations@grandhorizon.com', NULL, 'active', 1, 1253, 4.90, 1, NULL, '2026-09-25 10:53:28', '2026-10-18 16:50:53', 'Hotel', '120 Ocean Promenade, Miami Beach, FL', '+1 (555) 014-9922', '+15550149922', 'https://maps.google.com/?q=Miami+Beach,FL', NULL, 'direct', 0.00, 1),
(3, 1, 'place', NULL, 'OmniCare Specialist Medical & Wellness Center', 'omnicare-specialist-medical-center', 'Hospitals & Healthcare', 75.00, 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&auto=format&fit=crop', NULL, 'Modern healthcare facility offering comprehensive diagnostics, cardiology, physiotherapy, and 24-hour emergency care.', 1, 'care@omnicareclinic.org', NULL, 'active', 0, 610, 4.85, 0, NULL, '2026-09-25 10:53:28', '2026-09-25 10:53:28', 'Hospital', '450 Health Parkway, Chicago, IL', '+1 (555) 017-4321', '+15550174321', 'https://maps.google.com/?q=Chicago,IL', NULL, 'direct', 0.00, 1),
(4, 1, 'place', NULL, 'Grace Fellowship International Worship Center', 'grace-fellowship-international-church', 'Churches & Community', 0.00, 'https://images.unsplash.com/photo-1548625361-195fe579b183?w=800&auto=format&fit=crop', NULL, 'A vibrant faith community offering Sunday services, youth empowerment mentorship, and community food drives.', 1, 'welcome@gracefellowship.org', NULL, 'active', 0, 440, 5.00, 0, NULL, '2026-09-25 10:53:28', '2026-10-18 16:42:17', 'Church', '88 Cathedral Way, Dallas, TX', '+1 (555) 011-8844', '+15550118844', 'https://maps.google.com/?q=Dallas,TX', NULL, 'direct', 0.00, 1),
(5, 1, 'place', NULL, 'La Trattoria Artisan Italian Dining', 'la-trattoria-artisan-italian-dining', 'Restaurants & Dining', 45.00, 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop', NULL, 'Authentic woodfired pizza, handmade pasta, and curated Mediterranean wines in an intimate, modern atmosphere.', 1, 'tables@latrattoria.com', NULL, 'active', 1, 981, 4.92, 1, NULL, '2026-09-25 10:53:28', '2026-10-18 16:51:02', 'Restaurant', '210 Little Italy Blvd, San Francisco, CA', '+1 (555) 013-7721', '+15550137721', 'https://maps.google.com/?q=San+Francisco,CA', NULL, 'direct', 0.00, 1),
(6, 1, 'product', NULL, 'Adsbooster Omni-Channel AI Campaign Bundle', 'adsbooster-omni-channel-campaign-bundle', 'Software & Tools', 99.00, 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop', NULL, '50+ pre-tested viral ad frameworks, AI prompt templates for Groq/Gemini, and automated budget allocation rules.', 1, 'sales@adsbooster.net', NULL, 'active', 1, 1890, 4.98, 1, NULL, '2026-09-25 10:53:28', '2026-09-25 10:53:28', 'Product', 'Instant Digital Download', '+1 (555) 019-0011', '+15550190011', '', NULL, 'direct', 0.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `marketplace_reviews`
--

DROP TABLE IF EXISTS `marketplace_reviews`;
CREATE TABLE `marketplace_reviews` (
  `id` int NOT NULL,
  `item_id` int NOT NULL,
  `reviewer_user_id` int NOT NULL,
  `rating` tinyint DEFAULT NULL,
  `comment` text COLLATE latin1_swedish_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `type` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `title` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `body` text COLLATE latin1_swedish_ci,
  `link` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `is_read` tinyint DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `body`, `link`, `is_read`, `read_at`, `created_at`) VALUES
(4, 3, 'social_connected', 'Account Connected', 'Meta / Facebook has been connected successfully.', '/social-connect.php', 1, '2026-09-24 15:13:18', '2026-09-24 15:13:02'),
(5, 3, 'social_connected', 'Account Connected', 'Google Calendar has been connected successfully.', '/social-connect.php', 1, '2026-09-24 15:16:50', '2026-09-24 15:15:58'),
(6, 3, 'social_connected', 'Social Account Connected in Real-Time', 'Meta (Facebook) is now synced and ready for ad campaigns & scheduling.', '/social-connect.php', 1, '2026-09-24 16:23:04', '2026-09-24 16:17:47'),
(7, 3, 'social_connected', 'Social Account Connected in Real-Time', 'Google Calendar is now synced and ready for ad campaigns & scheduling.', '/social-connect.php', 1, '2026-09-24 16:23:04', '2026-09-24 16:18:13'),
(8, 3, 'social_connected', 'OAuth Account Connected', 'Meta was successfully authorized and connected via OAuth.', '/social-connect.php', 1, '2026-09-24 20:20:31', '2026-09-24 17:30:59'),
(9, 3, 'social_connected', 'Social Account Connected', 'Meta (Facebook) Profile was successfully verified and linked to your Meta (Facebook) publishing channel in real time.', '/social-connect.php', 1, '2026-09-25 13:47:18', '2026-09-25 13:33:15');

-- --------------------------------------------------------

--
-- Table structure for table `p2p_conversations`
--

DROP TABLE IF EXISTS `p2p_conversations`;
CREATE TABLE `p2p_conversations` (
  `id` int NOT NULL,
  `user_a` int NOT NULL,
  `user_b` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `p2p_conversations`
--

INSERT INTO `p2p_conversations` (`id`, `user_a`, `user_b`, `created_at`, `updated_at`) VALUES
(1, 1, 3, '2026-09-24 16:33:59', '2026-09-24 17:33:59'),
(2, 3, 99999, '2026-09-25 10:56:16', '2026-09-25 11:56:16'),
(3, 2, 99999, '2026-10-05 16:25:15', '2026-10-05 17:25:15'),
(4, 99999, 100000, '2026-10-12 19:37:18', '2026-10-12 20:37:18');

-- --------------------------------------------------------

--
-- Table structure for table `p2p_deals`
--

DROP TABLE IF EXISTS `p2p_deals`;
CREATE TABLE `p2p_deals` (
  `id` int NOT NULL,
  `conversation_id` int DEFAULT NULL,
  `proposer_id` int NOT NULL,
  `receiver_id` int NOT NULL,
  `title` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(10) COLLATE latin1_swedish_ci NOT NULL DEFAULT 'USD',
  `terms` text COLLATE latin1_swedish_ci NOT NULL,
  `status` enum('proposed','accepted','declined','completed','cancelled') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'proposed',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `p2p_messages`
--

DROP TABLE IF EXISTS `p2p_messages`;
CREATE TABLE `p2p_messages` (
  `id` int NOT NULL,
  `sender_id` int NOT NULL,
  `receiver_id` int DEFAULT NULL,
  `conversation_id` int DEFAULT NULL,
  `message` text COLLATE latin1_swedish_ci,
  `is_read` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `p2p_messages`
--

INSERT INTO `p2p_messages` (`id`, `sender_id`, `receiver_id`, `conversation_id`, `message`, `is_read`, `created_at`) VALUES
(2, 3, 1, 1, 'Can you share more details?', 1, '2026-09-24 19:19:52'),
(3, 3, 1, 1, 'Thanks for the update!', 1, '2026-09-24 19:20:00'),
(4, 3, 1, 1, '❤️ Nice to meet you! Would love to connect and chat.', 1, '2026-09-24 19:20:07'),
(5, 3, 1, 1, '💼 I saw your marketplace listing and I\'m interested in discussing details.', 1, '2026-09-24 19:20:15'),
(6, 3, 1, 1, '👋 Hi there! Let\'s collaborate on Adsbooster.', 1, '2026-09-24 19:20:19'),
(7, 3, 99999, 2, 'How do I run a multi-platform ad campaign?', 0, '2026-09-25 10:56:16'),
(8, 99999, 3, 2, '**Running a Multi‑Platform Ad Campaign (Meta + TikTok + Google Ads) – Step‑by‑Step Playbook 🚀**\n\n---\n\n## 1️⃣ Define the Core Goal & KPI Stack\n| Goal | Primary KPI | Supporting Metrics |\n|------|------------|---------------------|\n| **Lead gen** | CPL (cost per lead) | Form completions, click‑through rate (CTR) |\n| **E‑commerce sales** | ROAS (return on ad spend) | AOV, add‑to‑cart, purchase‑conversion |\n| **App installs** | CPI (cost per install) | Daily active users (DAU), retention 7d |\n\n> **Action:** Write a one‑sentence campaign brief (e.g., “Drive 200 qualified B2B SaaS demo requests in 30 days at ≤ $45 CPL”).  \n\n---\n\n## 2️⃣ Audience Architecture – One Funnel, Three Platforms\n1. **Top‑of‑Funnel (Awareness)**\n   - Broad interest & look‑alike audiences.\n   - Creative: 15‑30 s video, eye‑catching hook.\n2. **Middle‑of‑Funnel (Consideration)**\n   - Retarget website visitors, video viewers (25‑75 % watched), email list.\n   - Creative: product demo, social proof, carousel.\n3. **Bottom‑of‑Funnel (Conversion)**\n   - High‑intent audiences: cart abandoners, past purchasers, lead‑form completers.\n   - Creative: limited‑time offer, UGC testimonial, direct CTA.\n\n> **Action:** Build the same audience “layers” in each ad manager (Meta Audiences, TikTok Audiences, Google Audiences) so you can compare performance apples‑to‑apples.\n\n---\n\n## 3️⃣ Creative Production Blueprint\n| Asset | Specs (Meta) | Specs (TikTok) | Specs (Google) |\n|-------|--------------|----------------|----------------|\n| **Video** | 4:5 or 1:1, ≤ 15 s (feed) | 9:16, ≤ 9 s (In‑Feed) | 16:9, ≤ 30 s (YouTube) |\n| **Image** | 1080×1080, < 30 KB | 1080×1920, < 30 KB | 1200×628 (Display) |\n| **Copy** | 125 char primary, 30 char headline | 80 char hook, 2‑line CTA | 30 char headline, 90 char description |\n| **CTA** | “Learn More”, “Get Quote” | “Shop Now”, “Sign Up” | “Buy”, “Install” |\n\n> **Action:** Shoot 3‑5 short clips (different hooks) → repurpose across platforms with platform‑specific cropping tools (e.g., Canva, Kapwing). Keep a master folder with raw files for quick edits.\n\n---\n\n## 4️⃣ Budget Allocation Framework\n1. **Test Phase (Week 1‑2) – 30 % total budget**  \n   - Even split across platforms (≈ 10 % each) to gather baseline data.  \n2. **Scale Phase (Week 3‑6) – 60 % total budget**  \n   - Shift budget to the two best‑performing platforms (based on CPA/CPL).  \n3. **Optimization/Retarget Phase', 1, '2026-09-25 10:56:21'),
(9, 3, 1, 1, 'Thanks for the update!', 1, '2026-09-25 10:57:26'),
(10, 99999, 2, 3, '👋 Hello Jamachi Maurice Mauricennadi! I\'m your Adsbooster AI Growth Consultant. How can I assist you with your ad campaigns, copywriting, or marketplace listings today?', 1, '2026-10-05 16:25:15'),
(11, 2, 99999, 3, 'Give me 5 catchy ad headlines for my product.', 0, '2026-10-05 16:25:22'),
(12, 99999, 2, 3, 'Sure thing! 🎯 To craft headlines that truly pop, I just need a quick snapshot of your product. Could you let me know:\n\n1. **What’s the product?** (e.g., a fitness app, a skincare serum, a SaaS tool…)  \n2. **Key benefit** you want to highlight (e.g., saves time, boosts confidence, cuts costs).  \n3. **Target audience** (age, gender, interests, pain points).  \n4. **Brand voice** – playful, professional, edgy, etc.  \n5. **Any must‑include words** or a tagline you already love.\n\nDrop those details and I’ll spin out 5 killer headlines right away! 🚀', 1, '2026-10-05 16:25:25'),
(13, 2, 99999, 3, 'How do I run a multi-platform ad campaign?', 0, '2026-10-05 16:25:36'),
(14, 99999, 2, 3, '## 🚀 Run a Multi‑Platform Ad Campaign in 7 Actionable Steps  \n\nBelow is a quick‑start playbook you can copy‑paste into a spreadsheet or project‑management tool and start executing today.\n\n| Step | What to Do | Tools & Tips |\n|------|------------|--------------|\n| **1️⃣ Define the Goal & KPI Stack** | • Choose ONE primary objective (e.g., **sales**, **lead gen**, **app installs**).<br>• Set 2‑3 supporting KPIs per platform (e.g., ROAS, CPL, CTR, View‑Through Rate). | Google Sheet KPI tracker, Funnel.io, Supermetrics. |\n| **2️⃣ Map Your Funnel & Audiences** | • Sketch a simple 3‑stage funnel (Awareness → Consideration → Conversion).<br>• Build **core**, **look‑alike**, and **retarget** audiences for each stage. | Meta Audiences Manager, TikTok Audience Builder, Google Audiences (Custom Intent, In‑Market). |\n| **3️⃣ Allocate Budget & Calendar** | • Decide **budget split** by funnel stage (e.g., 40 % Awareness, 30 % Consideration, 30 % Conversion).<br>• Set a **15‑day test window** before scaling. | Spreadsheet with daily spend caps, Facebook/Google “Campaign Budget Optimization” (CBO). |\n| **4️⃣ Create Platform‑Specific Creative** | **Meta** – 1‑sq, 1‑vert, 1‑story (15‑30 s).<br>**TikTok** – 9‑sec hook + 15‑sec deep dive (vertical).<br>**Google Search** – 3‑ad copy variations + 5‑keyword ad groups.<br>**Google Display/YouTube** – 300×250, 728×90, 16:9 video. | Canva/Adobe Express for static; InShot or CapCut for video; **Hook‑Problem‑Solution‑CTA** formula for copy. |\n| **5️⃣ Set Up Tracking & Attribution** | • Install **Meta Pixel**, **TikTok Pixel**, **Google Tag Manager** on your site.<br>• Create **UTM parameters** per platform & ad set (e.g., `utm_source=fb&utm_medium=paid&utm_campaign=summer_sale`).<br>• Link all data to a **single dashboard** (Data Studio, Power BI). | GTM → GA4 conversion events; Facebook Attribution; TikTok Conversion API. |\n| **6️⃣ Launch & Test (First 7‑10 Days)** | • Run **A/B tests** on: <br>   • Creative (image vs video) <br>   • Copy (CTA variations) <br>   • Audience (interest vs look‑alike) <br>• Keep **CPC/CPM** ≤ target and **Frequency** ≤ 2.5 (avoid fatigue). | Meta “A/B Test” tool, TikTok “Experiment” feature, Google Ads Draft & Experiments. |\n| **7️⃣ Optimize & Scale** | **Daily**: Pause ad sets with ROAS < 2× or CPL > target.<br>**Every 48 h**: Shift budget to top‑performing creatives & audiences.<br>**Weekly**: Add **look‑alike** from the best converters, expand interest layers, test new creative angles', 1, '2026-10-05 16:25:39'),
(15, 2, 99999, 3, 'How do I boost my business directory listing?', 0, '2026-10-05 16:36:25'),
(16, 99999, 2, 3, '**Boosting Your Business Directory Listing – Action Plan 🚀**\n\nBelow is a step‑by‑step checklist you can start implementing **today** to get more clicks, calls, and foot‑traffic from every major directory (Google My Business, Yelp, Bing Places, Apple Maps, industry‑specific sites, etc.).\n\n---\n\n## 1️⃣ Audit & Clean Up Existing Listings\n| ✅ What to Do | 🛠️ How |\n|---|---|\n| **Gather every profile** (Google, Bing, Yelp, TripAdvisor, YellowPages, niche directories) | Use a tool like **BrightLocal** or **Whitespark** to pull a master list. |\n| **Verify NAP consistency** (Name, Address, Phone) | Make sure every listing shows the exact same format (e.g., “123 Main St, Suite 5, Springfield, IL 62704”). |\n| **Check categories** | Choose the **primary** category that best describes your core service, then add 2‑3 secondary categories. |\n| **Remove duplicates** | Claim ownership and request removal of any stale or duplicate entries. |\n| **Add missing info** | Hours, website URL, business description, photos, payment methods, accessibility notes. |\n\n🔧 **Quick win:** Update your Google Business Profile now—add 3 fresh, high‑resolution photos and a short “What makes us different” tagline (≤ 150 chars).\n\n---\n\n## 2️⃣ Optimize for SEO & Conversions\n| 🎯 Goal | Action |\n|---|---|\n| **Keyword‑rich description** | Write a 750‑character description that naturally includes 2‑3 primary keywords (e.g., “family‑owned plumbing service in Springfield”). |\n| **Add a call‑to‑action** | End the description with a clear CTA: “Call now for a free estimate 👉 (555) 123‑4567.” |\n| **Use schema markup** (if you control the website) | Add **LocalBusiness** schema so search engines sync your data with directories. |\n| **Upload videos** | Short 15‑30 sec clips of your storefront, team, or a quick service demo boost engagement by 30‑40 %. |\n| **Enable messaging** (Google, Facebook) | Turn on “Message” so prospects can contact you with a single tap. |\n\n---\n\n## 3️⃣ Supercharge with Reviews & Reputation\n| ⭐️ Why | 📌 What to Do |\n|---|---|\n| **Social proof drives clicks** | Ask happy customers for a 5‑star review within 24 hrs of service. |\n| **Automate requests** | Set up an email/SMS workflow (e.g., via **NiceJob**, **Podium**, or **Zapier**) that sends a short “Thanks! Please review us” link. |\n| **Respond to every review** | Thank positive reviewers & address negatives within 24 hrs—shows you care and improves ranking. |\n| **Leverage rich snippets** | Encourage reviewers to mention specific services (“great roof repair”) to trigger “service‑specific” rich snippets. |\n| **Showcase testimonials** | Pin your best 5‑star review to the top of Google & Yelp profiles. |\n\n🔔 **Pro tip:** Offer a small incentive (e.g., 10 % off next visit) *only* for leaving an honest review—never “pay for a 5‑star.” This stays within platform policies.\n\n---\n\n## 4️⃣ Build High‑Quality Citations\n|', 1, '2026-10-05 16:36:29'),
(17, 2, 99999, 3, 'How do I run a multi-platform ad campaign?', 0, '2026-10-05 17:08:16'),
(18, 99999, 2, 3, '## 🚀 Quick‑Start Guide to a Multi‑Platform Ad Campaign\n\n### 1️⃣ Define Your Objectives\n- **Brand Awareness** – reach new audiences  \n- **Lead Generation** – capture contact info  \n- **Sales/Conversions** – drive purchases  \n- **Retargeting** – re‑engage interested users  \n\n### 2️⃣ Audience & Creative Blueprint\n- **Core Audience** – demographics, interests, behaviors  \n- **Ad Creative** – headline, copy, image/video, CTA  \n- **Creative Variations** – test 2‑3 formats per platform  \n\n### 3️⃣ Channel Allocation & Specs  \n[PLATFORMS:Meta Ads (FB & IG):40%:Visual carousel, 1080x1080; TikTok Ads:35%:Short vertical video, 9:16; Google Search:25%:Responsive search ads, 3 headlines, 2 descriptions]\n\n### 4️⃣ Budget & Bid Strategy  \n- **Daily Budget**: $200 → $80 Meta, $70 TikTok, $50 Google  \n- **Bid Mode**: CPM for awareness, CPA for conversions  \n- **Optimization Goal**: ROAS > 4.0  \n\n### 5️⃣ KPI Dashboard  \n[METRICS:Impressions:1.2M:↑15%|Clicks:48K:↑12%|Conversions:1.8K:↑20%|ROAS:5.2x:↑0.8x]\n\n### 6️⃣ Execution Roadmap  \n[STEPS:1:Audience Research:Use Meta Audience Insights, TikTok Creator Marketplace, Google Keyword Planner:AdEspresso|2:Creative Production:Create 3 carousel sets, 3 TikTok clips:Canva, InVideo|3:Campaign Setup:Meta Ads Manager, TikTok Ads Manager, Google Ads:Set up tracking pixels, UTM parameters|4:Launch & Monitor:Start with 3‑day test, adjust bids based on CPM/CPA|5:Scale & Optimize:Increase budget by 10% on top performers, refresh creatives every 7 days|6:Reporting:Weekly KPI review, adjust channel mix|\n\n### 7️⃣ Actionable Resources  \n- **Create Ad**: [ACTION:Create Ad:./create-ad.php:ad-icon]  \n- **UGC Generator**: [ACTION:Generate UGC:./ugc-generator.php:ugc-icon]  \n- **CAPI Setup**: [ACTION:Set Up CAPI:./capi-gateway.php:api-icon]  \n\n---\n\n### 📊 Visual Snapshot  \n[CHART:doughnut:Budget Allocation:Meta 40%:TikTok 35%:Google 25%]  \n\n---\n\nFollow this blueprint, monitor the KPI cards daily, and tweak the roadmap steps in real time. Happy campaigning!', 1, '2026-10-05 17:08:39'),
(19, 2, 99999, 3, 'Give me 5 catchy ad headlines for my product. summary', 0, '2026-10-05 17:11:13'),
(20, 99999, 2, 3, '**Ad Headlines**  \n\n• “Unlock the Future of [Product] – Experience Power in Every Click!”  \n• “Transform Your Day with [Product] – Simplicity Meets Performance.”  \n• “Don’t Just Use It – Own It. Discover the New Standard in [Product]!”  \n• “Ready for a Game‑Changer? Meet the [Product] That Redefines Efficiency.”  \n• “Why Settle? Elevate Every Moment with the Unmatched [Product] Edge.”', 1, '2026-10-05 17:11:23'),
(21, 2, 99999, 3, 'tutorial', 0, '2026-10-05 17:14:36'),
(22, 99999, 2, 3, '**Adsbooster AI Growth Consultant – Quick‑Start Tutorial**  \n\n---\n\n### 1. Overview  \nA fast‑track guide to launch, optimize, and scale high‑performing paid campaigns using Adsbooster’s AI‑powered tools.\n\n---\n\n### 2. Getting Started  \n\n**Account Setup**  \n• Sign up at **adsbooster.net** and verify your business email.  \n• Connect your ad accounts (Meta Business Manager, TikTok Business Center, Google Ads).  \n• Install the **CAPI Gateway** for server‑side event tracking.  \n\n**Essential Integrations**  \n• **Pixel/SDK** – place the generated snippet on your site or mobile app.  \n• **CRM Sync** – map leads & purchases to your CRM via the built‑in webhook.  \n\n[ACTION:Connect Accounts:connect-accounts.php:fa‑link]  \n[ACTION:Install CAPI:install-capi.php:fa‑cogs]  \n\n---\n\n### 3. Campaign Creation  \n\n**Step‑by‑Step Workflow**  \n\n[STEPS:1:Audience Builder:Select look‑alike, interest, and retargeting layers using AI suggestions:Adsbooster UI|2:Creative Generator:Run the UGC‑Generator for 3‑second hook videos:ugc-generator.php|3:Ad Copy AI:Generate 5 headline variations and 3 primary texts:copy‑ai.php|4:Budget Allocation:Apply the recommended spend split across platforms:budget‑optimizer.php|5:Launch & Monitor:Activate the campaign and open the Real‑Time Dashboard:dashboard.php]  \n\n**Key Settings**  \n• **Objective** – Choose from Traffic, Conversions, or Lead Gen.  \n• **Bidding** – Opt for “Maximize Conversions” with a CPA cap (e.g., $12).  \n• **Placements** – Use “Automatic” for Meta; select “In‑Feed” + “Spark Ads” for TikTok.  \n\n---\n\n### 4. Creative Optimization  \n\n**AI‑Generated UGC**  \n• Upload 5‑10 raw clips (≤10 s).  \n• The generator outputs 3‑second punchy hooks with subtitles.  \n\n**Dynamic Creative**  \n• Combine up to 4 headlines, 3 descriptions, and 5 images/videos.  \n• Adsbooster’s AI tests permutations in real time, pausing low‑ROAS combos.  \n\n[ACTION:Create UGC:ugc-generator.php:fa‑video]  \n\n---\n\n### 5. Tracking & Analytics  \n\n**Core KPIs at a Glance**  \n\n[METRICS:ROAS:5.8×:Current|CPA:$11.20:Goal $12|CTR:2.4%:Industry Avg 1.2%]  \n\n**Channel Performance Matrix**  \n\n[PLATFORMS:Meta Ads (FB & IG):45%:Prospecting + Retargeting|TikTok Ads:35%:Short‑form video focus|Google Search:20%:High‑intent keywords]  \n\n**Live Dashboard**  \n• Heat‑map of ad set performance.  \n• AI alerts for “Spend Spike” or “CTR Drop”.  \n\n[ACTION:Open Dashboard:dashboard.php:fa‑chart-bar]', 1, '2026-10-05 17:14:48'),
(23, 2, 99999, 3, 'How do I boost my business directory listing?', 0, '2026-10-05 17:43:16'),
(24, 99999, 2, 3, '🔍 **Search Engine & Directory Visibility Blueprint**\n\nAccelerate organic traffic and commercial discoverability with high-intent search optimization:\n\n[METRICS:Focus Keyword:First 40 Chars|Meta Description:<155 Chars|Google Index Time:24-48 Hours]\n\n[CHART:bar:Organic Search Conversion Rates by Intent:Commercial / Product:5.8,Local Directory / City:4.6,Informational / Guide:1.9]\n\n[STEPS:1:Keyword In Title Tag:Front-load your target high-value keyword in the first 40 characters of your listing title:Google Search Best Practice|2:Click-Inducing Meta Description:Write an action-oriented summary with social proof and direct WhatsApp booking channel:Meta Optimizer|3:Verified Business Listing:Verified listings on Adsbooster index rapidly on Google search engines for high-intent keywords:Directory Suite]\n\n[ACTION:⭐ Boost Directory Listing:marketplace.php:ph-bold ph-star]', 1, '2026-10-05 17:43:30'),
(25, 99999, 100000, 4, '👋 Hello E2E Tester! I\'m your Adsbooster AI Growth Consultant. How can I assist you with your ad campaigns, copywriting, or marketplace listings today?', 1, '2026-10-12 19:37:18');

-- --------------------------------------------------------

--
-- Table structure for table `payout_requests`
--

DROP TABLE IF EXISTS `payout_requests`;
CREATE TABLE `payout_requests` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(50) NOT NULL,
  `details_json` text NOT NULL,
  `status` enum('pending','approved','paid','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `policy_rules`
--

DROP TABLE IF EXISTS `policy_rules`;
CREATE TABLE `policy_rules` (
  `id` int NOT NULL,
  `platform` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `rule_type` enum('text','image','url') COLLATE latin1_swedish_ci DEFAULT NULL,
  `pattern` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `severity` enum('low','medium','high','critical') COLLATE latin1_swedish_ci DEFAULT NULL,
  `description` text COLLATE latin1_swedish_ci,
  `is_active` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `policy_scan_logs`
--

DROP TABLE IF EXISTS `policy_scan_logs`;
CREATE TABLE `policy_scan_logs` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `campaign_id` int DEFAULT NULL,
  `post_id` int DEFAULT NULL,
  `compliance_score` int DEFAULT NULL,
  `issues_json` json DEFAULT NULL,
  `scanned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_metrics_daily`
--

DROP TABLE IF EXISTS `post_metrics_daily`;
CREATE TABLE `post_metrics_daily` (
  `id` int NOT NULL,
  `post_id` int NOT NULL,
  `date` date NOT NULL,
  `reach` int DEFAULT '0',
  `likes` int DEFAULT '0',
  `comments` int DEFAULT '0',
  `shares` int DEFAULT '0',
  `saves` int DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pricing_plans`
--

DROP TABLE IF EXISTS `pricing_plans`;
CREATE TABLE `pricing_plans` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `description` text COLLATE latin1_swedish_ci,
  `price` decimal(10,2) DEFAULT NULL,
  `ad_credits_included` decimal(10,2) DEFAULT '0.00',
  `ai_credits_included` int DEFAULT '0',
  `duration` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `billing_cycle` enum('monthly','yearly','pay_as_you_go') COLLATE latin1_swedish_ci DEFAULT NULL,
  `features_json` json DEFAULT NULL,
  `is_featured` tinyint DEFAULT '0',
  `sort_order` int DEFAULT '0',
  `status` enum('active','inactive') COLLATE latin1_swedish_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pricing_plans`
--

INSERT INTO `pricing_plans` (`id`, `name`, `description`, `price`, `ad_credits_included`, `ai_credits_included`, `duration`, `billing_cycle`, `features_json`, `is_featured`, `sort_order`, `status`, `created_at`) VALUES
(1, 'Starter Booster', 'Ideal for small businesses launching campaigns across key ad networks.', 29.00, 30.00, 150, 'month', 'monthly', '[\"Meta, Instagram & Google Ads support\", \"$30.00 Monthly Ad Credits Included\", \"150 AI Copy & Script Credits\", \"10 Scheduled Social Posts\", \"Basic Campaign Analytics\", \"Standard Email Support\"]', 0, 1, 'active', '2026-09-24 15:37:26'),
(2, 'Growth Pro', 'Complete multi-network automation, combo packs, and AI campaign doctor.', 79.00, 95.00, 500, 'month', 'monthly', '[\"All 5 Networks + All-in-One Combo Pack\", \"$95.00 Monthly Ad Credits (+$16 Bonus!)\", \"500 AI UGC Video & Image Credits\", \"Unlimited Scheduled Posts\", \"A/B Creative Split Testing\", \"Lookalike Audience Suggestions\", \"Priority 24/7 Support\"]', 1, 2, 'active', '2026-09-24 15:37:26'),
(3, 'Agency Scaling', 'Full white-label agency sub-accounts, webhook APIs, and auto-pilot optimization.', 199.00, 260.00, 1500, 'month', 'monthly', '[\"Everything in Growth Pro\", \"$260.00 Monthly Ad Credits (+$61 Bonus!)\", \"1,500 AI Generation Credits\", \"White-label Client Workspaces\", \"Full REST API & Webhooks Access\", \"AI Campaign Doctor Auto-Pilot\", \"Auto-Refill Wallet Protection\", \"Dedicated Account Manager\"]', 0, 3, 'active', '2026-09-24 15:37:26'),
(4, 'Enterprise Omnichannel', 'Custom high-volume enterprise advertising and bespoke integration SLAs.', 499.00, 700.00, 5000, 'month', 'monthly', '[\"Bespoke High-Volume Infrastructure\", \"$700.00 Monthly Ad Credits (+$201 Bonus!)\", \"5,000 AI Credits\", \"Unlimited Team Members & Sub-accounts\", \"Custom Ad Policy Pre-Flight Rules\", \"Direct Slack / WhatsApp Support Bridge\", \"99.9% Uptime SLA Agreement\"]', 0, 4, 'active', '2026-09-24 15:37:26');

-- --------------------------------------------------------

--
-- Table structure for table `pricing_plan_currency_overrides`
--

DROP TABLE IF EXISTS `pricing_plan_currency_overrides`;
CREATE TABLE `pricing_plan_currency_overrides` (
  `id` int NOT NULL,
  `plan_id` int NOT NULL,
  `currency_code` varchar(3) COLLATE latin1_swedish_ci DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

DROP TABLE IF EXISTS `referrals`;
CREATE TABLE `referrals` (
  `id` int NOT NULL,
  `referrer_id` int NOT NULL,
  `referred_id` int NOT NULL,
  `status` enum('pending','rewarded') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `reward_credits` decimal(10,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `scheduled_posts`
--

DROP TABLE IF EXISTS `scheduled_posts`;
CREATE TABLE `scheduled_posts` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `platform` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `post_type` enum('manual','ai_generated','realtime_publish','scheduled_campaign') COLLATE latin1_swedish_ci DEFAULT NULL,
  `caption` text COLLATE latin1_swedish_ci,
  `media_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `media_type` enum('image','ugc_video','reel','text_only','document','pdf') COLLATE latin1_swedish_ci DEFAULT NULL,
  `scheduled_time` datetime DEFAULT NULL,
  `google_calendar_event_id` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `external_id` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `publish_error` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('scheduled','publishing','published','failed','cancelled') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'scheduled',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `scheduled_posts`
--

INSERT INTO `scheduled_posts` (`id`, `user_id`, `platform`, `post_type`, `caption`, `media_url`, `media_type`, `scheduled_time`, `google_calendar_event_id`, `published_at`, `external_id`, `publish_error`, `status`, `created_at`, `updated_at`) VALUES
(1, 3, 'meta', 'ai_generated', '<p>me</p>', NULL, 'image', '2026-09-25 12:00:00', NULL, NULL, NULL, NULL, 'cancelled', '2026-09-24 15:16:16', '2026-09-24 15:23:16');

-- --------------------------------------------------------

--
-- Table structure for table `server_tracking_events`
--

DROP TABLE IF EXISTS `server_tracking_events`;
CREATE TABLE `server_tracking_events` (
  `id` int NOT NULL,
  `pixel_id` int NOT NULL,
  `user_id` int NOT NULL,
  `event_name` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `event_id` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `event_source_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `user_data_hashed` json DEFAULT NULL,
  `custom_data` json DEFAULT NULL,
  `meta_capi_status` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'sent',
  `tiktok_events_status` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'sent',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `server_tracking_pixels`
--

DROP TABLE IF EXISTS `server_tracking_pixels`;
CREATE TABLE `server_tracking_pixels` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `pixel_token` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `name` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `meta_pixel_id` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `meta_capi_access_token` text COLLATE latin1_swedish_ci,
  `meta_test_event_code` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `tiktok_pixel_id` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `tiktok_events_access_token` text COLLATE latin1_swedish_ci,
  `tiktok_test_event_code` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `domain_verified` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service_check_log`
--

DROP TABLE IF EXISTS `service_check_log`;
CREATE TABLE `service_check_log` (
  `id` int UNSIGNED NOT NULL,
  `check_key` varchar(64) NOT NULL,
  `ok` tinyint(1) NOT NULL,
  `latency_ms` int UNSIGNED NOT NULL DEFAULT '0',
  `detail` varchar(255) DEFAULT NULL,
  `checked_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_0900_ai_ci;

--
-- Dumping data for table `service_check_log`
--

INSERT INTO `service_check_log` (`id`, `check_key`, `ok`, `latency_ms`, `detail`, `checked_at`) VALUES
(1, 'database', 1, 1, 'responded in 1 ms', '2026-10-12 13:08:35'),
(2, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 13:08:35'),
(3, 'storage', 1, 1, 'writable', '2026-10-12 13:08:35'),
(4, 'image_cdn', 0, 0, 'probe helper unavailable', '2026-10-12 13:08:35'),
(5, 'ai_script', 0, 0, 'probe helper unavailable', '2026-10-12 13:08:35'),
(6, 'cache', 1, 1, 'writable', '2026-10-12 13:08:35'),
(7, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 13:09:45'),
(8, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 13:09:45'),
(9, 'storage', 1, 0, 'writable', '2026-10-12 13:09:45'),
(10, 'image_cdn', 1, 3269, 'HTTP 200', '2026-10-12 13:09:48'),
(11, 'ai_script', 1, 2149, 'HTTP 404', '2026-10-12 13:09:50'),
(12, 'cache', 1, 0, 'writable', '2026-10-12 13:09:50'),
(13, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 13:15:11'),
(14, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 13:15:11'),
(15, 'storage', 1, 0, 'writable', '2026-10-12 13:15:11'),
(16, 'image_cdn', 0, 10010, 'Connection timed out after 10004 milliseconds', '2026-10-12 13:15:21'),
(17, 'ai_script', 0, 6008, 'Connection timed out after 6003 milliseconds', '2026-10-12 13:15:27'),
(18, 'cache', 1, 1, 'writable', '2026-10-12 13:15:27'),
(19, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 14:42:53'),
(20, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 14:42:53'),
(21, 'storage', 1, 1, 'writable', '2026-10-12 14:42:53'),
(22, 'image_cdn', 1, 6549, 'HTTP 200', '2026-10-12 14:43:00'),
(23, 'ai_script', 1, 8955, 'HTTP 401', '2026-10-12 14:43:09'),
(24, 'cache', 1, 1, 'writable', '2026-10-12 14:43:09'),
(25, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 14:43:09'),
(26, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 14:43:09'),
(27, 'storage', 1, 0, 'writable', '2026-10-12 14:43:09'),
(28, 'image_cdn', 0, 20023, 'Operation timed out after 10010 milliseconds with 0 bytes received', '2026-10-12 14:43:30'),
(29, 'ai_script', 1, 6095, 'HTTP 401', '2026-10-12 14:43:36'),
(30, 'cache', 1, 0, 'writable', '2026-10-12 14:43:36'),
(31, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:36:23'),
(32, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:36:23'),
(33, 'storage', 1, 1, 'writable', '2026-10-12 20:36:23'),
(34, 'image_cdn', 1, 3936, 'HTTP 200', '2026-10-12 20:36:27'),
(35, 'ai_script', 1, 3421, 'HTTP 401', '2026-10-12 20:36:30'),
(36, 'cache', 1, 0, 'writable', '2026-10-12 20:36:30'),
(37, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:37:21'),
(38, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:37:21'),
(39, 'storage', 1, 0, 'writable', '2026-10-12 20:37:21'),
(40, 'image_cdn', 1, 16485, 'HTTP 200', '2026-10-12 20:37:38'),
(41, 'ai_script', 0, 12016, 'Operation timed out after 6001 milliseconds with 0 bytes received', '2026-10-12 20:37:50'),
(42, 'cache', 1, 0, 'writable', '2026-10-12 20:37:50'),
(43, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:38:36'),
(44, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:38:36'),
(45, 'storage', 1, 1, 'writable', '2026-10-12 20:38:36'),
(46, 'image_cdn', 1, 3999, 'HTTP 200', '2026-10-12 20:38:40'),
(47, 'ai_script', 0, 12028, 'Operation timed out after 6009 milliseconds with 0 bytes received', '2026-10-12 20:38:52'),
(48, 'cache', 1, 0, 'writable', '2026-10-12 20:38:52'),
(49, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:39:29'),
(50, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:39:29'),
(51, 'storage', 1, 0, 'writable', '2026-10-12 20:39:29'),
(52, 'image_cdn', 1, 15821, 'HTTP 200', '2026-10-12 20:39:45'),
(53, 'ai_script', 0, 10888, 'Operation timed out after 6009 milliseconds with 0 bytes received', '2026-10-12 20:39:56'),
(54, 'cache', 1, 0, 'writable', '2026-10-12 20:39:56'),
(55, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:39:56'),
(56, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:39:56'),
(57, 'storage', 1, 0, 'writable', '2026-10-12 20:39:56'),
(58, 'image_cdn', 1, 7165, 'HTTP 200', '2026-10-12 20:40:03'),
(59, 'ai_script', 1, 5694, 'HTTP 401', '2026-10-12 20:40:09'),
(60, 'cache', 1, 0, 'writable', '2026-10-12 20:40:09'),
(61, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:40:09'),
(62, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:40:09'),
(63, 'storage', 1, 0, 'writable', '2026-10-12 20:40:09'),
(64, 'image_cdn', 1, 4930, 'HTTP 200', '2026-10-12 20:40:14'),
(65, 'ai_script', 0, 9665, 'Operation timed out after 6012 milliseconds with 0 bytes received', '2026-10-12 20:40:24'),
(66, 'cache', 1, 0, 'writable', '2026-10-12 20:40:24'),
(67, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:42:56'),
(68, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:42:56'),
(69, 'storage', 1, 1, 'writable', '2026-10-12 20:42:56'),
(70, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-12 20:42:56'),
(71, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-12 20:42:56'),
(72, 'cache', 1, 1, 'writable', '2026-10-12 20:42:56'),
(73, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:42:58'),
(74, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:42:58'),
(75, 'storage', 1, 0, 'writable', '2026-10-12 20:42:58'),
(76, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-12 20:42:58'),
(77, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-12 20:42:58'),
(78, 'cache', 1, 0, 'writable', '2026-10-12 20:42:58'),
(79, 'database', 1, 0, 'responded in 0 ms', '2026-10-12 20:43:01'),
(80, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:43:01'),
(81, 'storage', 1, 0, 'writable', '2026-10-12 20:43:01'),
(82, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-12 20:43:01'),
(83, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-12 20:43:01'),
(84, 'cache', 1, 0, 'writable', '2026-10-12 20:43:01'),
(85, 'database', 1, 1, 'responded in 1 ms', '2026-10-12 20:45:05'),
(86, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:45:05'),
(87, 'storage', 1, 1, 'writable', '2026-10-12 20:45:05'),
(88, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-12 20:45:05'),
(89, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-12 20:45:05'),
(90, 'cache', 1, 1, 'writable', '2026-10-12 20:45:05'),
(91, 'database', 1, 1, 'responded in 1 ms', '2026-10-12 20:53:42'),
(92, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-12 20:53:42'),
(93, 'storage', 1, 1, 'writable', '2026-10-12 20:53:42'),
(94, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-12 20:53:42'),
(95, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-12 20:53:42'),
(96, 'cache', 1, 1, 'writable', '2026-10-12 20:53:42'),
(97, 'database', 1, 1, 'responded in 0 ms', '2026-10-13 14:25:26'),
(98, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-13 14:25:26'),
(99, 'storage', 1, 1, 'writable', '2026-10-13 14:25:26'),
(100, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-13 14:25:26'),
(101, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-13 14:25:26'),
(102, 'cache', 1, 1, 'writable', '2026-10-13 14:25:26'),
(103, 'database', 1, 1, 'responded in 1 ms', '2026-10-13 16:58:48'),
(104, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-13 16:58:48'),
(105, 'storage', 1, 1, 'writable', '2026-10-13 16:58:48'),
(106, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-13 16:58:48'),
(107, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-13 16:58:48'),
(108, 'cache', 1, 1, 'writable', '2026-10-13 16:58:48'),
(109, 'database', 1, 1, 'responded in 1 ms', '2026-10-13 17:27:30'),
(110, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-13 17:27:30'),
(111, 'storage', 1, 2, 'writable', '2026-10-13 17:27:30'),
(112, 'image_cdn', 0, 0, 'no response', '2026-10-13 17:27:30'),
(113, 'ai_script', 0, 0, 'no response', '2026-10-13 17:27:30'),
(114, 'cache', 1, 1, 'writable', '2026-10-13 17:27:30'),
(115, 'database', 1, 1, 'responded in 1 ms', '2026-10-15 08:31:17'),
(116, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-15 08:31:17'),
(117, 'storage', 1, 2, 'writable', '2026-10-15 08:31:17'),
(118, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-15 08:31:17'),
(119, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-15 08:31:17'),
(120, 'cache', 1, 1, 'writable', '2026-10-15 08:31:17'),
(121, 'database', 1, 0, 'responded in 0 ms', '2026-10-15 08:31:31'),
(122, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-15 08:31:31'),
(123, 'storage', 1, 1, 'writable', '2026-10-15 08:31:31'),
(124, 'image_cdn', 1, 0, 'HTTP 200 · 2165 B', '2026-10-15 08:31:31'),
(125, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-15 08:31:31'),
(126, 'cache', 1, 1, 'writable', '2026-10-15 08:31:31'),
(127, 'database', 1, 1, 'responded in 1 ms', '2026-10-15 16:57:55'),
(128, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-15 16:57:55'),
(129, 'storage', 1, 1, 'writable', '2026-10-15 16:57:55'),
(130, 'image_cdn', 1, 0, 'not configured on this node', '2026-10-15 16:57:55'),
(131, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-15 16:57:55'),
(132, 'cache', 1, 1, 'writable', '2026-10-15 16:57:55'),
(133, 'database', 1, 1, 'responded in 1 ms', '2026-10-15 16:59:08'),
(134, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-15 16:59:08'),
(135, 'storage', 1, 0, 'writable', '2026-10-15 16:59:08'),
(136, 'image_cdn', 1, 0, 'not configured on this node', '2026-10-15 16:59:08'),
(137, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-15 16:59:08'),
(138, 'cache', 1, 0, 'writable', '2026-10-15 16:59:08'),
(139, 'database', 1, 1, 'responded in 1 ms', '2026-10-16 18:40:29'),
(140, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-16 18:40:29'),
(141, 'storage', 1, 1, 'writable', '2026-10-16 18:40:29'),
(142, 'image_cdn', 1, 0, 'not configured on this node', '2026-10-16 18:40:29'),
(143, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-16 18:40:29'),
(144, 'cache', 1, 0, 'writable', '2026-10-16 18:40:29'),
(145, 'database', 1, 1, 'responded in 1 ms', '2026-10-17 04:22:03'),
(146, 'runtime', 1, 0, 'PHP 8.3.33', '2026-10-17 04:22:03'),
(147, 'storage', 1, 2, 'writable', '2026-10-17 04:22:03'),
(148, 'image_cdn', 1, 0, 'not configured on this node', '2026-10-17 04:22:03'),
(149, 'ai_script', 1, 0, 'HTTP 401 · 96 B', '2026-10-17 04:22:03'),
(150, 'cache', 1, 1, 'writable', '2026-10-17 04:22:03');

-- --------------------------------------------------------

--
-- Table structure for table `site_reviews`
--

DROP TABLE IF EXISTS `site_reviews`;
CREATE TABLE `site_reviews` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `rating` tinyint NOT NULL DEFAULT '5',
  `review_title` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `review_text` text COLLATE latin1_swedish_ci NOT NULL,
  `plan_type` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'pro',
  `user_role` varchar(100) COLLATE latin1_swedish_ci DEFAULT 'Verified Advertiser',
  `status` enum('pending','approved','rejected') COLLATE latin1_swedish_ci DEFAULT 'approved',
  `is_featured` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `site_reviews`
--

INSERT INTO `site_reviews` (`id`, `user_id`, `rating`, `review_title`, `review_text`, `plan_type`, `user_role`, `status`, `is_featured`, `created_at`) VALUES
(1, 1, 5, 'Scaled our TikTok & Meta ROAS to 4.2x in 3 Weeks', 'The AI UGC Video Studio combined with direct ad launches has saved our agency dozens of hours every month. The real-time pacing alerts prevented thousands in ad waste.', 'pro', 'Verified Advertiser', 'approved', 1, '2026-09-13 11:47:54'),
(2, 1, 5, 'The Verified Business Directory delivers high-ticket leads daily', 'Having our digital marketing agency listed in the Adsbooster Verified Directory with direct WhatsApp integration generated 14 qualified client inquiries in our first fortnight.', 'enterprise', 'Verified Advertiser', 'approved', 1, '2026-09-18 11:47:54'),
(3, 1, 5, 'Game changer for solo growth marketers & creators', 'Creating multi-scene reels with the smartphone simulator, then queuing straight to Instagram and TikTok without third-party scheduling tools is extraordinary.', 'pro', 'Verified Advertiser', 'approved', 1, '2026-09-23 11:47:54');

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
CREATE TABLE `site_settings` (
  `setting_key` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `setting_value` text COLLATE latin1_swedish_ci,
  `setting_group` varchar(100) COLLATE latin1_swedish_ci DEFAULT 'general'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`setting_key`, `setting_value`, `setting_group`) VALUES
('auto_refill_reward_credits', '10', 'referrals'),
('consent_mode_default', 'denied', 'privacy'),
('contact_address', 'New York, NY 10002, United States', 'general'),
('contact_email', 'support@adsbooster.net', 'general'),
('contact_phone', '+1 (555) 123-4567', 'general'),
('currency_symbol', '$', 'general'),
('firecrawl_api_key', '', 'general'),
('flutterwave_live_key', 'FLWSECK_LIVE-XXXXXXXXXXXXXXXXXXXX', 'payment'),
('flutterwave_test_key', 'FLWSECK_TEST-XXXXXXXXXXXXXXXXXXXX', 'payment'),
('gemini_api_key', '', 'general'),
('google_client_id', 'YOUR_GOOGLE_CLIENT_ID', 'integrations'),
('google_client_secret', 'YOUR_GOOGLE_CLIENT_SECRET', 'integrations'),
('groq_api_key', '', 'general'),
('maintenance_mode', '0', 'general'),
('openrouter_api_key', '', 'general'),
('paystack_live_key', 'sk_live_XXXXXXXXXXXXXXXXXXXXXXX', 'payment'),
('paystack_test_key', 'sk_test_XXXXXXXXXXXXXXXXXXXXXXX', 'payment'),
('policy_compliance_threshold', '70', 'policies'),
('referral_reward_amount', '50', 'referrals'),
('registration_open', '1', 'general'),
('site_address', 'New York, NY 10002, United States', 'general'),
('site_email', 'support@adsbooster.net', 'general'),
('site_favicon', '/assets/images/logo/favicon.png', 'general'),
('site_logo', '/assets/images/logo/logo-green.png', 'general'),
('site_name', 'Adsbooster.net', 'general'),
('site_phone', '+1 (555) 123-4567', 'general'),
('site_slogan', 'Multi-Network AI Advertising Platform', 'general'),
('social_facebook', 'https://facebook.com/adsbooster', 'social'),
('social_instagram', 'https://instagram.com/adsbooster', 'social'),
('social_linkedin', 'https://linkedin.com/company/adsbooster', 'social'),
('social_twitter', 'https://twitter.com/adsbooster', 'social');

-- --------------------------------------------------------

--
-- Table structure for table `social_inbox_messages`
--

DROP TABLE IF EXISTS `social_inbox_messages`;
CREATE TABLE `social_inbox_messages` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `platform` enum('instagram','facebook','tiktok','whatsapp','p2p') COLLATE latin1_swedish_ci NOT NULL,
  `sender_id` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `sender_name` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `sender_avatar` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `message_type` enum('comment','dm','whatsapp_chat') COLLATE latin1_swedish_ci NOT NULL,
  `post_context_id` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `message_text` text COLLATE latin1_swedish_ci NOT NULL,
  `ai_auto_replied` tinyint(1) DEFAULT '0',
  `auto_reply_text` text COLLATE latin1_swedish_ci,
  `status` enum('unread','read','replied','closed') COLLATE latin1_swedish_ci DEFAULT 'unread',
  `sentiment` enum('positive','neutral','negative','high_intent_buy') COLLATE latin1_swedish_ci DEFAULT 'neutral',
  `received_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `replied_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `social_inbox_messages`
--

INSERT INTO `social_inbox_messages` (`id`, `user_id`, `platform`, `sender_id`, `sender_name`, `sender_avatar`, `message_type`, `post_context_id`, `message_text`, `ai_auto_replied`, `auto_reply_text`, `status`, `sentiment`, `received_at`, `replied_at`) VALUES
(1, 1, 'instagram', 'ig_sarah_m', 'Sarah Miller (@sarahm_designs)', 'assets/images/thumbs/team-details-img3.png', 'comment', 'post_ig_9921', 'Price? How fast does shipping take to California?', 1, 'Hey Sarah! 👋 Thanks for asking! You can grab yours directly here: http://seopp.test/pricing-plan.php — use promo code [FLASH15] at checkout for an instant 15% OFF today only! 🚀 Let me know if you need any help!', 'replied', 'high_intent_buy', '2026-10-05 17:51:56', '2026-10-11 15:18:56'),
(2, 1, 'tiktok', 'tt_alex_k', 'Alex Rivera (@alexmoves)', 'assets/images/thumbs/team-details-img1.png', 'dm', NULL, 'Hey! Where can I buy this? Is there an active discount code available?', 1, 'Hey Alex! 👋 Thanks for asking! You can grab yours directly here: http://seopp.test/pricing-plan.php — use promo code [FLASH15] at checkout for an instant 15% OFF today only! 🚀 Let me know if you need any help!', 'replied', 'high_intent_buy', '2026-10-05 17:51:56', '2026-10-11 15:19:00'),
(3, 1, 'whatsapp', 'wa_14155552671', 'Marcus Thorne (+1 415-555-2671)', 'assets/images/thumbs/team-details-img2.png', 'whatsapp_chat', NULL, 'Hello, I saw your ad on Facebook. Do you have wholesale pricing for agencies?', 1, 'Hey Marcus! 👋 Thanks for asking! You can grab yours directly here: http://seopp.test/pricing-plan.php — use promo code [FLASH15] at checkout for an instant 15% OFF today only! 🚀 Let me know if you need any help!', 'replied', 'positive', '2026-10-05 17:51:56', '2026-10-11 15:19:02'),
(4, 1, 'facebook', 'fb_emma_w', 'Emma Watson', 'assets/images/thumbs/blog-details-img1.png', 'comment', 'fb_post_881', 'Link please! I want to try the 14-day trial before subscribing.', 1, 'Hey Emma! 👋 Thanks for asking! You can grab yours directly here: http://seopp.test/pricing-plan.php — use promo code [FLASH15] at checkout for an instant 15% OFF today only! 🚀 Let me know if you need any help!', 'replied', 'high_intent_buy', '2026-10-05 17:51:56', '2026-10-11 15:19:07'),
(5, 2, 'instagram', 'ig_sarah_m', 'Sarah Miller (@sarahm_designs)', 'assets/images/thumbs/team-details-img3.png', 'comment', 'post_ig_9921', 'Price? How fast does shipping take to California?', 1, 'Hey Sarah! 👋 Thanks for asking! You can grab yours directly here: http://seopp.test/pricing-plan.php — use promo code [FLASH15] at checkout for an instant 15% OFF today only! 🚀 Let me know if you need any help!', 'replied', 'high_intent_buy', '2026-10-05 18:19:02', '2026-10-05 17:19:06'),
(6, 2, 'tiktok', 'tt_alex_k', 'Alex Rivera (@alexmoves)', 'assets/images/thumbs/team-details-img1.png', 'dm', NULL, 'Hey! Where can I buy this? Is there an active discount code available?', 1, 'Hey Alex! 👋 Thanks for asking! You can grab yours directly here: http://seopp.test/pricing-plan.php — use promo code [FLASH15] at checkout for an instant 15% OFF today only! 🚀 Let me know if you need any help!', 'replied', 'high_intent_buy', '2026-10-05 18:19:02', '2026-10-05 17:19:19'),
(7, 2, 'whatsapp', 'wa_14155552671', 'Marcus Thorne (+1 415-555-2671)', 'assets/images/thumbs/team-details-img2.png', 'whatsapp_chat', NULL, 'Hello, I saw your ad on Facebook. Do you have wholesale pricing for agencies?', 1, 'Hey Marcus! 👋 Thanks for asking! You can grab yours directly here: http://seopp.test/pricing-plan.php — use promo code [FLASH15] at checkout for an instant 15% OFF today only! 🚀 Let me know if you need any help!', 'replied', 'positive', '2026-10-05 18:19:02', '2026-10-05 17:19:25'),
(8, 2, 'facebook', 'fb_emma_w', 'Emma Watson', 'assets/images/thumbs/blog-details-img1.png', 'comment', 'fb_post_881', 'Link please! I want to try the 14-day trial before subscribing.', 1, 'Hey Emma! 👋 Thanks for asking! You can grab yours directly here: http://seopp.test/pricing-plan.php — use promo code [FLASH15] at checkout for an instant 15% OFF today only! 🚀 Let me know if you need any help!', 'replied', 'high_intent_buy', '2026-10-05 18:19:02', '2026-10-05 17:19:28'),
(9, 100000, 'instagram', 'ig_sarah_m', 'Sarah Miller (@sarahm_designs)', 'assets/images/thumbs/team-details-img3.png', 'comment', 'post_ig_9921', 'Price? How fast does shipping take to California?', 0, NULL, 'unread', 'high_intent_buy', '2026-10-12 20:37:16', NULL),
(10, 100000, 'tiktok', 'tt_alex_k', 'Alex Rivera (@alexmoves)', 'assets/images/thumbs/team-details-img1.png', 'dm', NULL, 'Hey! Where can I buy this? Is there an active discount code available?', 0, NULL, 'unread', 'high_intent_buy', '2026-10-12 20:37:16', NULL),
(11, 100000, 'whatsapp', 'wa_14155552671', 'Marcus Thorne (+1 415-555-2671)', 'assets/images/thumbs/team-details-img2.png', 'whatsapp_chat', NULL, 'Hello, I saw your ad on Facebook. Do you have wholesale pricing for agencies?', 0, NULL, 'unread', 'positive', '2026-10-12 20:37:16', NULL),
(12, 100000, 'facebook', 'fb_emma_w', 'Emma Watson', 'assets/images/thumbs/blog-details-img1.png', 'comment', 'fb_post_881', 'Link please! I want to try the 14-day trial before subscribing.', 0, NULL, 'unread', 'high_intent_buy', '2026-10-12 20:37:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `social_inbox_rules`
--

DROP TABLE IF EXISTS `social_inbox_rules`;
CREATE TABLE `social_inbox_rules` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `trigger_keywords` varchar(500) COLLATE latin1_swedish_ci DEFAULT 'price, how to buy, link, cost, where to get, info',
  `platforms` varchar(255) COLLATE latin1_swedish_ci DEFAULT 'instagram,facebook,tiktok,whatsapp',
  `auto_dm_enabled` tinyint(1) DEFAULT '1',
  `promo_discount_code` varchar(100) COLLATE latin1_swedish_ci DEFAULT 'FLASH15',
  `product_link` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `reply_template` text COLLATE latin1_swedish_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

DROP TABLE IF EXISTS `support_tickets`;
CREATE TABLE `support_tickets` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `ticket_type` enum('support','bug_report','billing') COLLATE latin1_swedish_ci DEFAULT NULL,
  `priority` enum('low','medium','high','urgent') COLLATE latin1_swedish_ci DEFAULT 'medium',
  `subject` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('open','in_progress','resolved','closed') COLLATE latin1_swedish_ci DEFAULT 'open',
  `report_target_user_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_invitations`
--

DROP TABLE IF EXISTS `team_invitations`;
CREATE TABLE `team_invitations` (
  `id` int NOT NULL,
  `owner_id` int NOT NULL,
  `email` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `role` enum('admin','editor','viewer') COLLATE latin1_swedish_ci DEFAULT 'viewer',
  `invite_token` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `status` enum('pending','accepted','expired') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

DROP TABLE IF EXISTS `team_members`;
CREATE TABLE `team_members` (
  `id` int NOT NULL,
  `parent_user_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `email` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `full_name` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `role` enum('admin','editor','viewer') COLLATE latin1_swedish_ci DEFAULT 'viewer',
  `invite_token` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `invited_at` datetime DEFAULT NULL,
  `status` enum('active','pending','removed') COLLATE latin1_swedish_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `tickets`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `tickets`;
CREATE TABLE `tickets` (
`id` int
,`user_id` int
,`ticket_number` varchar(6)
,`type` enum('support','bug_report','billing')
,`priority` enum('low','medium','high','urgent')
,`subject` varchar(500)
,`status` enum('open','in_progress','resolved','closed')
,`created_at` timestamp
,`updated_at` timestamp
);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_messages`
--

DROP TABLE IF EXISTS `ticket_messages`;
CREATE TABLE `ticket_messages` (
  `id` int NOT NULL,
  `ticket_id` int NOT NULL,
  `sender_id` int NOT NULL,
  `message` text COLLATE latin1_swedish_ci,
  `attachment_path` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
CREATE TABLE `transactions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `gateway` enum('paystack','flutterwave') COLLATE latin1_swedish_ci DEFAULT NULL,
  `type` enum('plan_subscription','ad_credit_topup','ai_credit_topup') COLLATE latin1_swedish_ci DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `currency` varchar(3) COLLATE latin1_swedish_ci DEFAULT 'USD',
  `status` enum('pending','successful','failed','refunded') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `invoice_number` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `invoice_path` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `gateway_reference` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `reference` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `gateway`, `type`, `amount`, `currency`, `status`, `invoice_number`, `invoice_path`, `gateway_reference`, `reference`, `metadata`, `created_at`, `updated_at`) VALUES
(1, 2, 'flutterwave', 'ad_credit_topup', 5.00, 'USD', 'failed', 'INV-20260922-744DEF', NULL, '23650EDF397640F28CEBA620', '23650EDF397640F28CEBA620', '{\"email\": \"jmauricennadi@gmail.com\"}', '2026-09-22 15:40:01', '2026-09-22 15:40:01'),
(6, 2, 'flutterwave', 'ad_credit_topup', 5.00, 'USD', 'failed', 'INV-20260922-ED427B', NULL, 'D4879830074DF529286E69E4', 'D4879830074DF529286E69E4', '{\"email\": \"jmauricennadi@gmail.com\"}', '2026-09-22 20:34:33', '2026-09-22 20:34:33'),
(7, 2, 'flutterwave', 'ai_credit_topup', 5.00, 'USD', 'failed', 'INV-20260922-5C8DBE', NULL, '6E3AD583B74933D676FB6DC8', '6E3AD583B74933D676FB6DC8', '{\"email\": \"jmauricennadi@gmail.com\"}', '2026-09-22 20:34:43', '2026-09-22 20:34:43'),
(8, 2, 'paystack', 'ad_credit_topup', 5.00, 'USD', 'failed', 'INV-20260923-C253CD', NULL, '5276B988EC79BB9EDB4D6C3D', '5276B988EC79BB9EDB4D6C3D', '{\"email\": \"jmauricennadi@gmail.com\"}', '2026-09-23 14:41:01', '2026-09-23 14:41:01'),
(9, 3, 'flutterwave', 'ad_credit_topup', 100.00, 'USD', 'failed', 'INV-20260923-E8A2A5', NULL, '1AB010D38974CDC01A613736', '1AB010D38974CDC01A613736', '{\"email\": \"jotahecomng@gmail.com\"}', '2026-09-23 15:08:32', '2026-09-23 15:08:32'),
(10, 3, 'flutterwave', 'ad_credit_topup', 100.00, 'USD', 'failed', 'INV-20260924-2FBBE0', NULL, 'BB6DFD9BE20FC0BBECDA5E33', 'BB6DFD9BE20FC0BBECDA5E33', '{\"email\": \"jotahecomng@gmail.com\"}', '2026-09-24 13:55:17', '2026-09-24 13:55:17'),
(11, 3, 'flutterwave', 'ai_credit_topup', 50.00, 'USD', 'failed', 'INV-20260924-DB3A06', NULL, '6D97127AB29A6B87FEEB9332', '6D97127AB29A6B87FEEB9332', '{\"email\": \"jotahecomng@gmail.com\"}', '2026-09-24 14:21:20', '2026-09-24 14:21:20'),
(12, 3, 'paystack', 'ad_credit_topup', 100.00, 'USD', 'failed', 'INV-20260924-B571C1', NULL, '4F3100F2C84D821721CA6F03', '4F3100F2C84D821721CA6F03', '{\"email\": \"jotahecomng@gmail.com\"}', '2026-09-24 14:21:26', '2026-09-24 14:21:26'),
(13, 3, 'paystack', 'ai_credit_topup', 5.00, 'USD', 'failed', 'INV-20260924-74BD75', NULL, 'CBB46F46EB790F6ED810E738', 'CBB46F46EB790F6ED810E738', '{\"email\": \"jotahecomng@gmail.com\"}', '2026-09-24 14:21:30', '2026-09-24 14:21:30'),
(14, 3, 'paystack', 'plan_subscription', 29.00, 'USD', 'failed', 'INV-20260924-6ACD4C', NULL, 'EF5CE783239371E2EBC1A2D7', 'EF5CE783239371E2EBC1A2D7', '{\"email\": \"jotahecomng@gmail.com\", \"plan_id\": 1, \"plan_name\": \"Starter Booster\"}', '2026-09-24 15:08:00', '2026-09-24 15:08:00'),
(15, 3, 'flutterwave', 'plan_subscription', 29.00, 'USD', 'failed', 'INV-20260924-B6A8AB', NULL, 'ECFEB932E42602A08C0A01C1', 'ECFEB932E42602A08C0A01C1', '{\"email\": \"jotahecomng@gmail.com\", \"plan_id\": 1, \"plan_name\": \"Starter Booster\"}', '2026-09-24 15:08:08', '2026-09-24 15:08:08'),
(16, 3, 'paystack', 'ad_credit_topup', 100.00, 'USD', 'failed', 'INV-20260925-A8B86C', NULL, 'EDE0BB6DD3028ED2CD83796D', 'EDE0BB6DD3028ED2CD83796D', '{\"email\": \"jotahecomng@gmail.com\"}', '2026-09-25 16:08:09', '2026-09-25 16:08:09'),
(17, 3, 'paystack', 'plan_subscription', 499.00, 'USD', 'failed', 'INV-20260925-FB2605', NULL, '788B48B805AD9B367BCE6EAC', '788B48B805AD9B367BCE6EAC', '{\"email\": \"jotahecomng@gmail.com\", \"plan_id\": 4, \"plan_name\": \"Enterprise Omnichannel\"}', '2026-09-25 16:08:15', '2026-09-25 16:08:15'),
(18, 1, 'paystack', 'ai_credit_topup', 100.00, 'USD', 'failed', 'INV-20261007-9C82AC', NULL, '4571B86208CD48681557CA16', '4571B86208CD48681557CA16', '{\"email\": \"admin@adsbooster.net\"}', '2026-10-07 18:10:11', '2026-10-07 18:10:11'),
(19, 1, 'flutterwave', 'ai_credit_topup', 100.00, 'USD', 'failed', 'INV-20261007-D64A67', NULL, 'D42D96D74B58E101B69ACD06', 'D42D96D74B58E101B69ACD06', '{\"email\": \"admin@adsbooster.net\"}', '2026-10-07 18:10:19', '2026-10-07 18:10:19');

-- --------------------------------------------------------

--
-- Table structure for table `translations`
--

DROP TABLE IF EXISTS `translations`;
CREATE TABLE `translations` (
  `id` int NOT NULL,
  `locale` varchar(10) COLLATE latin1_swedish_ci NOT NULL,
  `translation_key` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `value` text COLLATE latin1_swedish_ci
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `full_name` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `email` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `phone` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `company` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `headline` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `bio` text COLLATE latin1_swedish_ci,
  `password` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `role` enum('user','team_member','admin') COLLATE latin1_swedish_ci DEFAULT 'user',
  `parent_user_id` int DEFAULT NULL,
  `account_type` enum('individual','agency_owner','agency_client') COLLATE latin1_swedish_ci DEFAULT 'individual',
  `ad_credits` decimal(10,2) DEFAULT '0.00',
  `ai_credits` int DEFAULT '0',
  `ai_preferred_provider` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `plan_id` int DEFAULT NULL,
  `billing_cycle` varchar(20) COLLATE latin1_swedish_ci DEFAULT NULL,
  `plan_expiry` date DEFAULT NULL,
  `onboarding_completed` tinyint DEFAULT '0',
  `status` enum('active','suspended','pending') COLLATE latin1_swedish_ci DEFAULT 'active',
  `is_verified_seller` tinyint DEFAULT '0',
  `referral_code` varchar(20) COLLATE latin1_swedish_ci DEFAULT NULL,
  `referred_by` varchar(20) COLLATE latin1_swedish_ci DEFAULT NULL,
  `auto_refill_enabled` tinyint DEFAULT '0',
  `auto_refill_threshold` decimal(10,2) DEFAULT '0.00',
  `auto_refill_amount` decimal(10,2) DEFAULT '0.00',
  `auto_refill_gateway` varchar(20) COLLATE latin1_swedish_ci DEFAULT NULL,
  `totp_secret` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `totp_enabled` tinyint DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `two_factor_enabled` tinyint DEFAULT '0',
  `two_factor_secret` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `two_factor_type` enum('totp','email','both') COLLATE latin1_swedish_ci DEFAULT 'both',
  `two_factor_backup` text COLLATE latin1_swedish_ci,
  `two_factor_setup_at` datetime DEFAULT NULL,
  `email_2fa_code` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `email_2fa_expires_at` datetime DEFAULT NULL,
  `2fa_attempts` int UNSIGNED NOT NULL DEFAULT '0',
  `remember_token` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `remember_token_expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone`, `company`, `headline`, `bio`, `password`, `google_id`, `avatar`, `role`, `parent_user_id`, `account_type`, `ad_credits`, `ai_credits`, `ai_preferred_provider`, `plan_id`, `billing_cycle`, `plan_expiry`, `onboarding_completed`, `status`, `is_verified_seller`, `referral_code`, `referred_by`, `auto_refill_enabled`, `auto_refill_threshold`, `auto_refill_amount`, `auto_refill_gateway`, `totp_secret`, `totp_enabled`, `created_at`, `updated_at`, `two_factor_enabled`, `two_factor_secret`, `two_factor_type`, `two_factor_backup`, `two_factor_setup_at`, `email_2fa_code`, `email_2fa_expires_at`, `2fa_attempts`, `remember_token`, `remember_token_expires_at`) VALUES
(1, 'Admin User', 'admin@adsbooster.net', NULL, NULL, NULL, 'Seasoned professional with background in digital ad operations. Proven ability to manage campaigns across platforms.', '$2y$10$ukmrC0oa4oms5wOGH0910e86X4GoSSjZJfzj.m91YZ8JYwYv5Guxy', NULL, NULL, 'admin', NULL, 'individual', 0.00, 71, 'gemini', 4, NULL, '2032-10-22', 0, 'active', 1, '72F27CFC', NULL, 0, 0.00, 0.00, NULL, NULL, 0, '2026-09-16 14:17:16', '2026-10-17 17:30:40', 0, NULL, 'both', NULL, NULL, NULL, NULL, 0, 'f5139e4b8a703802e56f3648cb08c7bcff9e27b1626c763dc648c899072dbe97', '2026-11-10 16:12:52'),
(2, 'Jamachi Maurice Mauricennadi', 'jmauricennadi@gmail.com', NULL, 'Freelance', 'Digital advertising specialist with experience in campaign execution', 'Seasoned professional with background in digital ad operations. Proven ability to manage campaigns across platforms.', '$2y$10$ukmrC0oa4oms5wOGH0910e86X4GoSSjZJfzj.m91YZ8JYwYv5Guxy', NULL, NULL, 'user', NULL, 'individual', 0.00, 72, NULL, NULL, NULL, NULL, 1, 'active', 0, '0e076164998d42e9', NULL, 0, 0.00, 0.00, NULL, NULL, 0, '2026-09-16 17:09:42', '2026-10-07 19:08:05', 0, NULL, 'both', NULL, NULL, NULL, NULL, 0, NULL, NULL),
(3, 'Jamachi Mauricennadi', 'jotahecomng@gmail.com', NULL, NULL, NULL, NULL, '$2y$10$j48dM8evVXJhPQASJrQaxe7YlVN3Yxjij8wzVTwWtfssJjVKDDqsi', NULL, NULL, 'user', NULL, 'individual', 0.00, 83, 'gemini', NULL, NULL, NULL, 1, 'active', 0, '0010a2bccc34c1f4', NULL, 0, 0.00, 0.00, NULL, NULL, 0, '2026-09-23 16:06:11', '2026-10-05 17:25:02', 0, NULL, 'both', NULL, NULL, NULL, NULL, 0, NULL, NULL),
(4, 'Adsbooster AI Growth Assistant', 'ai.assistant@adsbooster.net', NULL, NULL, NULL, NULL, '$2y$12$g.gFN7Ugrq0pF5z1DxJ2ZOyCe8GRDa./jaRwpvIPosjZHogfgh.j6', NULL, NULL, 'admin', NULL, 'individual', 0.00, 0, NULL, NULL, NULL, NULL, 0, 'active', 0, NULL, NULL, 0, 0.00, 0.00, NULL, NULL, 0, '2026-09-24 17:01:34', '2026-09-24 18:01:34', 0, NULL, 'both', NULL, NULL, NULL, NULL, 0, NULL, NULL),
(99999, 'Adsbooster AI Consultant', 'ai@adsbooster.net', NULL, NULL, NULL, NULL, 'ai_bot_protected', NULL, NULL, 'admin', NULL, 'individual', 0.00, 0, NULL, NULL, NULL, NULL, 0, 'active', 0, NULL, NULL, 0, 0.00, 0.00, NULL, NULL, 0, '2026-09-25 11:56:09', '2026-09-25 11:56:09', 0, NULL, 'both', NULL, NULL, NULL, NULL, 0, NULL, NULL),
(100000, 'E2E Tester', 'e2e@test.local', NULL, '', 'Smoke regression test', 'Smoke test bio for regression.', '$2y$12$svaANYW6ZzWTbO2vCOxxU.x2tIxXo/vumitioWdeCBx1qjZWSgboi', NULL, NULL, 'user', NULL, 'individual', 500.00, 526, NULL, NULL, NULL, NULL, 0, 'active', 0, 'E1E13739', NULL, 0, 0.00, 0.00, NULL, NULL, 0, '2026-10-12 11:15:55', '2026-10-17 18:15:27', 0, NULL, 'both', NULL, NULL, NULL, NULL, 0, '54476d36580a22206fe21e3e7a6f376787b1a33093234899a75a449bf4155c44', '2026-11-13 14:28:08');

-- --------------------------------------------------------

--
-- Table structure for table `user_achievements`
--

DROP TABLE IF EXISTS `user_achievements`;
CREATE TABLE `user_achievements` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `achievement_id` int NOT NULL,
  `earned_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_deals`
--

DROP TABLE IF EXISTS `user_deals`;
CREATE TABLE `user_deals` (
  `id` int NOT NULL,
  `conversation_id` int NOT NULL,
  `proposer_id` int NOT NULL,
  `recipient_id` int NOT NULL,
  `deal_title` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `deal_scope` text COLLATE latin1_swedish_ci NOT NULL,
  `amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(10) COLLATE latin1_swedish_ci DEFAULT 'USD',
  `delivery_days` int DEFAULT '3',
  `status` enum('pending','accepted','declined','completed','cancelled') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
CREATE TABLE `user_follows` (
  `id` int NOT NULL,
  `follower_id` int NOT NULL,
  `following_id` int NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_portfolios`
--

DROP TABLE IF EXISTS `user_portfolios`;
CREATE TABLE `user_portfolios` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `username` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `display_name` varchar(150) COLLATE latin1_swedish_ci NOT NULL,
  `headline` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `bio` text COLLATE latin1_swedish_ci,
  `template_style` enum('dark_luxury','creative_neon','executive_minimal') COLLATE latin1_swedish_ci NOT NULL DEFAULT 'dark_luxury',
  `phone` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `email` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `company` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `job_title` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `website` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `location` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `skills_json` text COLLATE latin1_swedish_ci,
  `services_json` text COLLATE latin1_swedish_ci,
  `portfolio_items_json` mediumtext COLLATE latin1_swedish_ci,
  `social_links_json` text COLLATE latin1_swedish_ci,
  `resume_url` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `avatar_url` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `views_count` int NOT NULL DEFAULT '0',
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_portfolios`
--

INSERT INTO `user_portfolios` (`id`, `user_id`, `username`, `display_name`, `headline`, `bio`, `template_style`, `phone`, `email`, `company`, `job_title`, `website`, `location`, `skills_json`, `services_json`, `portfolio_items_json`, `social_links_json`, `resume_url`, `avatar_url`, `views_count`, `is_public`, `created_at`, `updated_at`) VALUES
(1, 3, 'contact', 'Growth Professional', 'Specializing in multi-network ad optimization, UGC production, and ROAS scaling.', 'Experienced marketing specialist with a proven track record delivering profitable campaigns across Meta, TikTok, and Google Ads.', 'dark_luxury', '+1 (555) 019-2831', 'contact@adsbooster.net', '', 'Performance Advertiser & Creator', NULL, 'Worldwide / Remote', '[\"Meta Ads\",\"TikTok Ads\",\"UGC Video\",\"Copywriting\",\"Conversion Rate Optimization\"]', '[{\"title\":\"Omnichannel Ad Campaign Management\",\"price\":\"$2,500\\/month\"},{\"title\":\"High-Converting UGC Video Creatives\",\"price\":\"$350\\/video package\"}]', '[{\"title\":\"D2C Ecommerce Scale\",\"metric\":\"4.8x Blended ROAS\",\"description\":\"Scaled ad spend from $10k to $75k\\/month while dropping CPA by 34%.\"}]', NULL, NULL, NULL, 2, 1, '2026-09-25 17:09:40', '2026-10-17 09:32:24'),
(2, 2, 'jmauricennadi', 'Jamachi Maurice Mauricennadi', 'Digital advertising specialist with experience in campaign execution', 'Seasoned professional with background in digital ad operations. Proven ability to manage campaigns across platforms.', 'dark_luxury', '', 'jmauricennadi@gmail.com', 'Freelance', 'Digital Advertising Professional', 'https://github.com/FushionHub', 'Remote', '[]', '[]', '[]', NULL, NULL, NULL, 3, 1, '2026-10-05 17:09:30', '2026-10-17 09:32:25'),
(3, 100000, 'smoke', 'Smoke Tester', 'Smoke regression test', 'Smoke test bio for regression.', 'creative_neon', '', 'smoke@test.local', '', 'QA Engineer', '', '', '[\"PHP\",\"JavaScript\",\"QA\"]', '[]', '[]', '{\"linkedin\":\"\",\"twitter\":\"\",\"instagram\":\"\",\"github\":\"\",\"youtube\":\"\"}', NULL, '', 3, 1, '2026-10-14 15:28:54', '2026-10-17 09:32:23');

-- --------------------------------------------------------

--
-- Table structure for table `user_recommendations`
--

DROP TABLE IF EXISTS `user_recommendations`;
CREATE TABLE `user_recommendations` (
  `id` int NOT NULL,
  `recommender_id` int NOT NULL,
  `target_user_id` int NOT NULL,
  `relationship` varchar(100) COLLATE latin1_swedish_ci DEFAULT 'Colleague / Client',
  `recommendation_text` text COLLATE latin1_swedish_ci NOT NULL,
  `rating` tinyint DEFAULT '5',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_reports`
--

DROP TABLE IF EXISTS `user_reports`;
CREATE TABLE `user_reports` (
  `id` int NOT NULL,
  `reporter_id` int NOT NULL,
  `reported_user_id` int NOT NULL,
  `reason` varchar(255) COLLATE latin1_swedish_ci NOT NULL,
  `details` text COLLATE latin1_swedish_ci,
  `status` enum('pending','reviewed','dismissed') COLLATE latin1_swedish_ci DEFAULT 'pending',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_vcards`
--

DROP TABLE IF EXISTS `user_vcards`;
CREATE TABLE `user_vcards` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `username` varchar(100) COLLATE latin1_swedish_ci NOT NULL,
  `headline` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `bio` text COLLATE latin1_swedish_ci,
  `template` varchar(50) COLLATE latin1_swedish_ci DEFAULT 'cyber_dark',
  `phone` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `whatsapp` varchar(50) COLLATE latin1_swedish_ci DEFAULT NULL,
  `company` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `job_title` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `location` varchar(150) COLLATE latin1_swedish_ci DEFAULT NULL,
  `website` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `github` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `skills_json` json DEFAULT NULL,
  `projects_json` json DEFAULT NULL,
  `experiences_json` json DEFAULT NULL,
  `resume_file` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `views_count` int DEFAULT '0',
  `is_public` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `user_vcards`
--

INSERT INTO `user_vcards` (`id`, `user_id`, `username`, `headline`, `bio`, `template`, `phone`, `whatsapp`, `company`, `job_title`, `location`, `website`, `linkedin`, `twitter`, `github`, `instagram`, `skills_json`, `projects_json`, `experiences_json`, `resume_file`, `views_count`, `is_public`, `created_at`, `updated_at`) VALUES
(1, 3, 'jamachimauricennadi', '', '', 'cyber_dark', '+1 (555) 019-2834', '+15550192834', '', '', '', 'https://adsbooster.net', NULL, NULL, NULL, NULL, '[\"Meta Ads\", \"TikTok Media Buying\", \"ROAS Scaling\", \"UGC Creative\", \"Copywriting\"]', '[{\"link\": \"https://adsbooster.net\", \"title\": \"DTC Fashion Brand Scale\", \"metric\": \"4.2x ROAS\", \"description\": \"Scaled monthly ad spend from $10k to $120k at 4.2x blended ROAS.\"}]', '[{\"role\": \"Senior Media Buyer\", \"period\": \"2023 - Present\", \"company\": \"Growth Agency\", \"summary\": \"Directing omnichannel Meta and TikTok ad budgets for fast-growing brands.\"}]', NULL, 0, 1, '2026-09-25 11:57:33', '2026-09-25 12:01:56'),
(2, 2, 'jmauricennadi', 'Digital advertising specialist with experience in campaign execution', 'Seasoned professional with background in digital ad operations. Proven ability to manage campaigns across platforms.', 'dark_luxury', '', '', 'Freelance', 'Digital Advertising Professional', 'Remote', 'https://github.com/FushionHub', NULL, NULL, NULL, NULL, '[]', '[]', NULL, NULL, 1, 1, '2026-10-05 17:10:59', '2026-10-05 17:10:59'),
(3, 100000, 'smoke', 'Smoke regression test', 'Smoke test bio for regression.', 'creative_neon', '', '', '', 'QA Engineer', '', 'http://localhost/seopp/portfolio.php?u=smoke', '', '', '', '', '[\"PHP\", \"JavaScript\", \"QA\"]', '[]', NULL, NULL, 1, 1, '2026-10-14 15:28:54', '2026-10-14 15:28:54');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_logs`
--

DROP TABLE IF EXISTS `visitor_logs`;
CREATE TABLE `visitor_logs` (
  `id` bigint NOT NULL,
  `user_id` int DEFAULT NULL,
  `ip` varchar(45) COLLATE latin1_swedish_ci DEFAULT NULL,
  `user_agent` text COLLATE latin1_swedish_ci,
  `browser` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `os` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `device_type` enum('desktop','mobile') COLLATE latin1_swedish_ci DEFAULT NULL,
  `request_uri` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `country` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `visitor_logs`
--

INSERT INTO `visitor_logs` (`id`, `user_id`, `ip`, `user_agent`, `browser`, `os`, `device_type`, `request_uri`, `country`, `created_at`) VALUES
(1, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:18:20'),
(2, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:18:45'),
(3, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:21:26'),
(4, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:21:39'),
(5, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/seopp/', '', '2026-09-16 14:22:12'),
(6, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:24:20'),
(7, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/seopp/', '', '2026-09-16 14:24:27'),
(8, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:26:00'),
(9, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:26:19'),
(10, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/seopp/', '', '2026-09-16 14:26:27'),
(11, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:27:18'),
(12, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/seopp/', '', '2026-09-16 14:49:17'),
(13, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:49:22'),
(14, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:50:10'),
(15, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:50:29'),
(16, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:50:51'),
(17, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:51:53'),
(18, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:52:55'),
(19, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:56:48'),
(20, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:56:58'),
(21, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 14:57:19'),
(22, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 14:57:26'),
(23, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 14:57:35'),
(24, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 14:57:39'),
(25, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 14:57:54'),
(26, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:57:57'),
(27, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/blog-details.php', '', '2026-09-16 14:58:15'),
(28, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:58:23'),
(29, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 14:58:49'),
(30, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 14:58:53'),
(31, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 14:59:05'),
(32, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-09-16 15:04:16'),
(33, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/services.php', '', '2026-09-16 15:04:36'),
(34, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-09-16 15:04:56'),
(35, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 15:04:58'),
(36, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 15:05:00'),
(37, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 15:05:01'),
(38, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 15:05:11'),
(39, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 15:05:29'),
(40, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/seopp/', '', '2026-09-16 15:07:05'),
(41, NULL, '::1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/seopp/', '', '2026-09-16 15:07:15'),
(42, NULL, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/seopp/', '', '2026-09-16 15:07:18'),
(43, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 16:00:00'),
(44, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 16:00:19'),
(45, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-09-16 16:00:26'),
(46, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:01:30'),
(47, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:05:13'),
(48, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:05:22'),
(49, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:09:29'),
(50, NULL, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/index.php', '', '2026-09-16 16:11:02'),
(51, NULL, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/index.php', '', '2026-09-16 16:11:20'),
(52, NULL, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/index.php', '', '2026-09-16 16:11:24'),
(53, NULL, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/index.php', '', '2026-09-16 16:11:28'),
(54, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:11:38'),
(55, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:11:56'),
(56, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:12:08'),
(57, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:12:15'),
(58, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:14:55'),
(59, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/about.php', '', '2026-09-16 16:15:06'),
(60, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/about.php', '', '2026-09-16 16:16:07'),
(61, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:16:16'),
(62, NULL, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/index.php', '', '2026-09-16 16:17:17'),
(63, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:17:19'),
(64, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:30:00'),
(65, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:30:23'),
(66, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-16 16:34:05'),
(67, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 16:35:57'),
(68, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-16 16:36:17'),
(69, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-16 16:37:12'),
(70, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 16:37:53'),
(71, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 16:39:35'),
(72, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 16:40:22'),
(73, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 16:40:26'),
(74, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 16:40:39'),
(75, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 16:40:44'),
(76, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 16:40:51'),
(77, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 16:41:47'),
(78, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 17:06:10'),
(79, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 17:07:16'),
(80, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 17:07:21'),
(81, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 17:09:03'),
(82, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 17:09:08'),
(83, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-16 17:09:42'),
(84, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 17:11:00'),
(85, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-16 17:11:03'),
(86, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-16 17:11:08'),
(87, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 17:11:14'),
(88, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 17:14:18'),
(89, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-16 17:14:52'),
(90, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-16 17:14:59'),
(91, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-16 17:15:07'),
(92, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-16 17:28:10'),
(93, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-16 17:28:12'),
(94, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-16 17:28:15'),
(95, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-17 06:35:27'),
(96, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-17 06:36:06'),
(97, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-17 06:36:15'),
(98, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-17 06:38:18'),
(99, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:38:23'),
(100, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/social-connect.php?platform=meta', '', '2026-09-17 06:38:49'),
(101, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/social-connect.php?platform=meta', '', '2026-09-17 06:39:48'),
(102, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:40:28'),
(103, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/pricing-plan.php', '', '2026-09-17 06:40:36'),
(104, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/pricing-plan.php', '', '2026-09-17 06:40:42'),
(105, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:41:11'),
(106, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/create-ad.php', '', '2026-09-17 06:41:21'),
(107, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:43:26'),
(108, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/billing.php', '', '2026-09-17 06:43:32'),
(109, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/billing.php', '', '2026-09-17 06:44:12'),
(110, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:45:17'),
(111, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace.php', '', '2026-09-17 06:45:27'),
(112, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:45:31'),
(113, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/ai-settings.php', '', '2026-09-17 06:45:35'),
(114, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:47:34'),
(115, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:48:51'),
(116, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 06:49:45'),
(117, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-17 12:31:45'),
(118, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 12:32:32'),
(119, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/social-connect.php?platform=meta', '', '2026-09-17 12:32:41'),
(120, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 12:32:47'),
(121, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/social-connect.php?platform=google_calendar', '', '2026-09-17 12:32:51'),
(122, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 12:32:57'),
(123, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/post-creator.php', '', '2026-09-17 12:33:01'),
(124, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/post-creator.php?tab=manual', '', '2026-09-17 12:36:50'),
(125, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard.php', '', '2026-09-17 12:36:56'),
(126, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/dashboard.php', '', '2026-09-17 12:37:02'),
(127, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/billing.php', '', '2026-09-17 12:37:33'),
(128, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/billing.php', '', '2026-09-17 12:37:59'),
(129, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/dashboard.php', '', '2026-09-17 12:38:00'),
(130, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/pricing-plan.php', '', '2026-09-17 12:38:09'),
(131, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/search.php?q=dating', '', '2026-09-17 12:38:37'),
(132, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/create-ad.php', '', '2026-09-17 12:38:48'),
(133, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/post-creator.php', '', '2026-09-17 13:08:05'),
(134, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/create-ad.php', '', '2026-09-17 13:08:18'),
(135, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/create-ad.php', '', '2026-09-17 13:08:43'),
(136, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/post-creator.php', '', '2026-09-17 13:09:14'),
(137, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/post-creator.php?tab=manual', '', '2026-09-17 13:09:47'),
(138, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/post-creator.php', '', '2026-09-17 13:10:15'),
(139, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/marketplace.php', '', '2026-09-17 13:21:57'),
(140, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/marketplace.php?tab=services', '', '2026-09-17 13:22:01'),
(141, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/marketplace.php?tab=companies', '', '2026-09-17 13:22:04'),
(142, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/marketplace.php?tab=services', '', '2026-09-17 13:22:06'),
(143, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/marketplace.php', '', '2026-09-17 13:22:08'),
(144, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/social-connect.php?platform=meta', '', '2026-09-17 13:22:11'),
(145, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/social-connect.php?platform=meta', '', '2026-09-17 13:22:36'),
(146, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/ai-settings.php', '', '2026-09-17 13:23:19'),
(147, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/calendar.php', '', '2026-09-17 13:23:49'),
(148, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/calendar.php?month=10&year=2026', '', '2026-09-17 13:23:54'),
(149, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/calendar.php?month=11&year=2026', '', '2026-09-17 13:23:57'),
(150, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/calendar.php?month=10&year=2026', '', '2026-09-17 13:24:31'),
(151, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/calendar.php', '', '2026-09-17 13:24:31'),
(152, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/billing.php', '', '2026-09-17 13:24:38'),
(153, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/tickets.php', '', '2026-09-17 13:25:24'),
(154, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/pricing-plan.php', '', '2026-09-17 13:26:21'),
(155, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/referrals.php', '', '2026-09-17 13:39:01'),
(156, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/analytics.php', '', '2026-09-17 13:40:49'),
(157, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/post-creator.php', '', '2026-09-17 13:41:19'),
(158, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/post-creator.php?tab=manual', '', '2026-09-17 13:41:24'),
(159, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/post-creator.php', '', '2026-09-17 13:41:28'),
(160, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/social-connect.php?platform=meta', '', '2026-09-17 13:41:44'),
(161, 2, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/calendar.php', '', '2026-09-17 13:42:46'),
(162, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-17 16:23:09'),
(163, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-09-17 16:23:13'),
(164, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-09-17 16:23:37'),
(165, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-09-17 16:23:50'),
(166, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-09-17 16:23:57'),
(167, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/about.php', '', '2026-09-17 16:24:04'),
(168, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/faq.php', '', '2026-09-17 16:24:18'),
(169, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/about.php', '', '2026-09-17 16:24:30'),
(170, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-09-17 16:24:31'),
(171, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-17 16:24:33'),
(172, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-17 16:24:36'),
(173, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-18 15:12:03'),
(174, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-18 15:14:19'),
(175, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-18 15:14:56'),
(176, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-18 15:54:30'),
(177, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-18 15:54:38'),
(178, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-21 19:41:53'),
(179, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-21 20:35:11'),
(180, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-23 16:02:05'),
(181, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-23 16:02:11'),
(182, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/register.php', '', '2026-09-23 16:02:25'),
(183, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-23 16:02:27'),
(184, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-23 16:02:46'),
(185, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-23 16:03:06'),
(186, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-09-23 16:03:25'),
(187, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/register.php?ref=0e076164998d42e9', '', '2026-09-23 16:04:50'),
(188, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:11'),
(189, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:20'),
(190, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:28'),
(191, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:32'),
(192, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:38'),
(193, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:41'),
(194, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:43'),
(195, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:46'),
(196, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:52'),
(197, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:06:54'),
(198, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:07:30'),
(199, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/onboarding.php', '', '2026-09-23 16:07:32'),
(200, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 14:47:16'),
(201, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-24 14:47:51'),
(202, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-24 14:53:48'),
(203, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/index.php', '', '2026-09-24 16:19:57'),
(204, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(205, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/register.php', '', '2026-09-24 16:19:57'),
(206, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(207, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(208, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(209, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(210, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(211, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(212, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(213, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(214, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(215, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(216, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(217, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(218, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-24 16:19:57'),
(219, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-24 16:56:47'),
(220, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-09-24 17:00:40'),
(221, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-24 20:58:47'),
(222, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-24 21:52:52'),
(223, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-24 22:26:39'),
(224, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=ad-campaign-performance-audit-signs', '', '2026-09-24 22:27:12'),
(225, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=ad-campaign-performance-audit-signs', '', '2026-09-24 22:28:58'),
(226, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=ad-campaign-performance-audit-signs', '', '2026-09-24 22:29:51');
INSERT INTO `visitor_logs` (`id`, `user_id`, `ip`, `user_agent`, `browser`, `os`, `device_type`, `request_uri`, `country`, `created_at`) VALUES
(227, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=ad-campaign-performance-audit-signs', '', '2026-09-24 22:29:52'),
(228, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=ad-campaign-performance-audit-signs', '', '2026-09-24 22:29:53'),
(229, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-24 22:29:57'),
(230, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog.php', '', '2026-09-25 11:11:59'),
(231, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog.php?category=Advertising', '', '2026-09-25 11:12:13'),
(232, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog.php?category=all', '', '2026-09-25 11:12:16'),
(233, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog.php?category=all', '', '2026-09-25 11:12:38'),
(234, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=agencies-scale-client-management', '', '2026-09-25 11:12:42'),
(235, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=ad-campaign-performance-audit-signs', '', '2026-09-25 11:12:59'),
(236, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=agencies-scale-client-management', '', '2026-09-25 11:13:19'),
(237, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog.php?category=all', '', '2026-09-25 11:13:22'),
(238, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog.php?category=Advertising', '', '2026-09-25 11:13:23'),
(239, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog.php', '', '2026-09-25 11:13:24'),
(240, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=agencies-scale-client-management', '', '2026-09-25 11:17:05'),
(241, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=agencies-scale-client-management', '', '2026-09-25 11:53:22'),
(242, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=meta-ads-vs-tiktok-ads-roi', '', '2026-09-25 11:53:43'),
(243, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=social-media-scheduling-guide-2026', '', '2026-09-25 11:53:49'),
(244, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog-details.php?slug=meta-ads-vs-tiktok-ads-roi', '', '2026-09-25 11:54:06'),
(245, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-25 11:54:11'),
(246, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/blog.php', '', '2026-09-25 12:22:15'),
(247, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-25 12:22:21'),
(248, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-25 12:25:04'),
(249, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/faq.php', '', '2026-09-25 12:25:13'),
(250, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-25 12:25:32'),
(251, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/portfolio.php?u=3', '', '2026-09-25 12:39:16'),
(252, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-09-25 12:39:57'),
(253, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-09-25 12:40:17'),
(254, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/job-details.php?id=4', '', '2026-09-25 12:40:26'),
(255, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-09-25 12:41:01'),
(256, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-09-25 12:41:10'),
(257, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php?q=&category=&type=&location=', '', '2026-09-25 12:41:15'),
(258, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-09-25 12:41:44'),
(259, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-09-25 13:12:28'),
(260, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-09-25 13:13:35'),
(261, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/portfolio.php?u=3', '', '2026-09-25 13:14:25'),
(262, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/portfolio.php?u=3', '', '2026-09-25 13:14:54'),
(263, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/faq.php', '', '2026-09-25 13:50:01'),
(264, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/jobs.php', '', '2026-09-25 13:50:01'),
(265, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/job-details.php?id=1', '', '2026-09-25 13:50:01'),
(266, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-25 13:50:01'),
(267, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-25 13:50:01'),
(268, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-25 13:50:01'),
(269, NULL, '::1', '', 'Unknown', 'Unknown', 'desktop', '/seopp/login.php', '', '2026-09-25 13:50:01'),
(270, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:04:41'),
(271, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:05:03'),
(272, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:05:55'),
(273, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:05:59'),
(274, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:25:32'),
(275, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:53:16'),
(276, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:53:30'),
(277, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:53:37'),
(278, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:53:38'),
(279, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:57:15'),
(280, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 16:57:16'),
(281, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/reviews.php', '', '2026-09-25 16:57:37'),
(282, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-25 16:57:46'),
(283, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/reviews.php', '', '2026-09-25 16:57:54'),
(284, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/index.php', '', '2026-09-25 16:58:15'),
(285, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-09-25 17:08:26'),
(286, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/portfolio.php?u=contact', '', '2026-09-25 17:10:07'),
(287, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-09-25 17:10:53'),
(288, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-10-02 15:09:50'),
(289, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-10-02 15:10:08'),
(290, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/', '', '2026-10-03 19:18:54'),
(291, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/contact.php', '', '2026-10-03 19:19:46'),
(292, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/about.php', '', '2026-10-03 19:20:02'),
(293, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/index.php', '', '2026-10-03 19:20:58'),
(294, 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', 'Chrome', 'Windows 10/11', 'desktop', '/jobs.php', '', '2026-10-03 19:22:19'),
(295, 3, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/reviews.php', '', '2026-10-03 19:24:46'),
(296, 3, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/index.php', '', '2026-10-03 19:25:07'),
(297, 3, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/reviews.php', '', '2026-10-03 19:28:28'),
(298, 3, '127.0.0.1', 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1', 'Safari', 'macOS', 'mobile', '/reviews.php', '', '2026-10-03 19:28:47'),
(299, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-05 17:08:01'),
(300, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-10-05 17:08:09'),
(301, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-10-05 17:08:18'),
(302, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login.php', '', '2026-10-05 17:08:30'),
(303, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-05 17:08:36'),
(304, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/portfolio.php?u=jmauricennadi', '', '2026-10-05 17:09:52'),
(305, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/portfolio.php', '', '2026-10-05 17:11:02'),
(306, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/vcard.php', '', '2026-10-05 17:11:27'),
(307, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-05 17:35:21'),
(308, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login', '', '2026-10-05 20:14:38'),
(309, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login', '', '2026-10-05 20:14:56'),
(310, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/images/thumbs/about-five-img1.png', '', '2026-10-05 20:15:21'),
(311, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-05 20:15:21'),
(312, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/images/thumbs/about-five-img1.png', '', '2026-10-05 20:15:54'),
(313, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-05 20:15:54'),
(314, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/images/thumbs/about-five-img1.png', '', '2026-10-05 20:16:24'),
(315, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-05 20:16:24'),
(316, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-05 20:22:41'),
(317, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-05 20:22:41'),
(318, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-05 20:22:43'),
(319, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-07 18:20:13'),
(320, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-07 18:20:13'),
(321, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-07 18:20:13'),
(322, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-07 18:20:13'),
(323, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/terms', '', '2026-10-07 18:20:34'),
(324, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/privacy', '', '2026-10-07 18:21:38'),
(325, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/favicon.ico', '', '2026-10-07 18:22:51'),
(326, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/privacy', '', '2026-10-07 18:22:54'),
(327, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/favicon.ico', '', '2026-10-07 18:25:03'),
(328, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 18:25:25'),
(329, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 18:25:25'),
(330, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 18:25:26'),
(331, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 18:25:26'),
(332, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_96438d9db25649eaa5cca589dd0c3a41.mp4', '', '2026-10-07 18:25:56'),
(333, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_96438d9db25649eaa5cca589dd0c3a41.mp4', '', '2026-10-07 18:25:56'),
(334, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_96438d9db25649eaa5cca589dd0c3a41.mp4', '', '2026-10-07 18:25:57'),
(335, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_96438d9db25649eaa5cca589dd0c3a41.mp4', '', '2026-10-07 18:25:57'),
(336, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_9cf5e4d10c9ebc2f2d7d4addbdab1712.mp4', '', '2026-10-07 18:26:53'),
(337, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-07 18:27:30'),
(338, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-07 19:01:24'),
(339, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 19:01:31'),
(340, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 19:01:32'),
(341, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 19:01:32'),
(342, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 19:01:32'),
(343, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_96438d9db25649eaa5cca589dd0c3a41.mp4', '', '2026-10-07 19:01:45'),
(344, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_9cf5e4d10c9ebc2f2d7d4addbdab1712.mp4', '', '2026-10-07 19:01:51'),
(345, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_82e85a6091570b6e1ba81ca46777d170.mp4', '', '2026-10-07 19:01:56'),
(346, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/admin-login', '', '2026-10-07 19:02:32'),
(347, 2, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/admin-login', '', '2026-10-07 19:07:46'),
(348, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/login', '', '2026-10-07 19:08:05'),
(349, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-07 19:11:47'),
(350, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-07 19:11:47'),
(351, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-07 19:11:48'),
(352, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-07 19:11:48'),
(353, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:13:19'),
(354, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:13:20'),
(355, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:13:21'),
(356, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:13:21'),
(357, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:15:22'),
(358, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:15:22'),
(359, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/js/swiper-bundle.min.js.map', '', '2026-10-07 19:15:22'),
(360, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:15:23'),
(361, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:15:23'),
(362, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:16:24'),
(363, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/js/swiper-bundle.min.js.map', '', '2026-10-07 19:16:25'),
(364, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:16:25'),
(365, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:16:25'),
(366, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:17:19'),
(367, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/js/swiper-bundle.min.js.map', '', '2026-10-07 19:17:20'),
(368, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:17:20'),
(369, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:17:20'),
(370, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:18:05'),
(371, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/js/swiper-bundle.min.js.map', '', '2026-10-07 19:18:05'),
(372, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:18:06'),
(373, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:18:06'),
(374, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:18:46'),
(375, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/js/swiper-bundle.min.js.map', '', '2026-10-07 19:18:47'),
(376, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:18:47'),
(377, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:18:47'),
(378, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:29:41'),
(379, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/js/swiper-bundle.min.js.map', '', '2026-10-07 19:29:41'),
(380, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:29:42'),
(381, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:29:42'),
(382, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:30:18'),
(383, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-07 19:30:18'),
(384, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-11 16:12:52'),
(385, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-11 16:13:03'),
(386, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-11 16:13:03'),
(387, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-11 16:13:03'),
(388, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/favicon.ico', '', '2026-10-11 16:13:15'),
(389, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-11 16:13:17'),
(390, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-11 16:13:17'),
(391, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-11 16:13:18'),
(392, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-11 16:13:18'),
(393, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-11 16:14:09'),
(394, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:14:57'),
(395, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-11 16:14:57'),
(396, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:14:58'),
(397, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:14:58'),
(398, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-11 16:14:58'),
(399, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_8e69a95c1a07fba50468ef08107a69da.mp4', '', '2026-10-11 16:14:58'),
(400, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:15:07'),
(401, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:15:14'),
(402, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:15:19'),
(403, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:15:19'),
(404, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:15:20'),
(405, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/videos/ugc_827832ff03ea7a6ea52551e4bfda2121.mp4', '', '2026-10-11 16:15:20'),
(406, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-12 11:11:58'),
(407, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-12 11:20:45'),
(408, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 11:21:01'),
(409, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/403', '', '2026-10-12 11:21:01'),
(410, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/nonexistent-xyz', '', '2026-10-12 11:22:24'),
(411, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/403', '', '2026-10-12 11:22:24'),
(412, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/database', '', '2026-10-12 11:22:25'),
(413, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron', '', '2026-10-12 11:22:25'),
(414, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/keys.local.php', '', '2026-10-12 11:22:25'),
(415, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/config/apikeys', '', '2026-10-12 11:24:19'),
(416, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/.env', '', '2026-10-12 11:24:19'),
(417, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/prompts/x', '', '2026-10-12 11:24:20'),
(418, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 11:24:20'),
(419, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/404', '', '2026-10-12 11:24:20'),
(420, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/signup', '', '2026-10-12 11:24:20'),
(421, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/database/export_master_sql', '', '2026-10-12 11:24:33'),
(422, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/pull_campaign_metrics', '', '2026-10-12 11:24:35'),
(423, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cache/x', '', '2026-10-12 11:24:35'),
(424, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/scratch/x', '', '2026-10-12 11:24:36'),
(425, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/config/apikeys', '', '2026-10-12 11:24:36'),
(426, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 11:24:57'),
(427, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 12:32:56'),
(428, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 12:33:27'),
(429, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 12:33:57'),
(430, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 12:38:30'),
(431, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 12:43:55'),
(432, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 12:50:21'),
(433, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 12:50:57'),
(434, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 12:51:20'),
(435, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/terms', '', '2026-10-12 12:56:58'),
(436, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/privacy', '', '2026-10-12 12:56:58'),
(437, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/dmca', '', '2026-10-12 12:56:58'),
(438, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/ai-disclaimer', '', '2026-10-12 12:56:58'),
(439, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/refund-policy', '', '2026-10-12 12:56:58'),
(440, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cookie-policy', '', '2026-10-12 12:56:58'),
(441, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 13:04:23'),
(442, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 13:11:46'),
(443, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 13:15:09'),
(444, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/terms', '', '2026-10-12 13:15:27'),
(445, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/privacy', '', '2026-10-12 13:15:28'),
(446, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/dmca', '', '2026-10-12 13:15:28'),
(447, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/ai-disclaimer', '', '2026-10-12 13:15:28'),
(448, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/refund-policy', '', '2026-10-12 13:15:28'),
(449, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cookie-policy', '', '2026-10-12 13:15:28'),
(450, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/index', '', '2026-10-12 13:15:28'),
(451, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/config/apikeys', '', '2026-10-12 13:15:28'),
(452, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/database', '', '2026-10-12 13:15:29'),
(453, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron', '', '2026-10-12 13:15:29'),
(454, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/keys.local', '', '2026-10-12 13:15:29'),
(455, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/scratch', '', '2026-10-12 13:15:29'),
(456, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/uploads/videos/.htaccess', '', '2026-10-12 13:15:29'),
(457, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/config/keys.local', '', '2026-10-12 13:16:31'),
(458, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 14:42:50'),
(459, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/terms', '', '2026-10-12 14:43:09'),
(460, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/privacy', '', '2026-10-12 14:43:09'),
(461, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/dmca', '', '2026-10-12 14:43:09'),
(462, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/ai-disclaimer', '', '2026-10-12 14:43:09'),
(463, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/refund-policy', '', '2026-10-12 14:43:09');
INSERT INTO `visitor_logs` (`id`, `user_id`, `ip`, `user_agent`, `browser`, `os`, `device_type`, `request_uri`, `country`, `created_at`) VALUES
(464, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cookie-policy', '', '2026-10-12 14:43:09'),
(465, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 14:43:58'),
(466, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-12 16:59:56'),
(467, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-12 16:59:57'),
(468, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/pull_campaign_metrics', '', '2026-10-12 20:05:51'),
(469, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/auto_refill_check', '', '2026-10-12 20:05:52'),
(470, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/ab_test_winner', '', '2026-10-12 20:05:52'),
(471, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/auto_buyer_daemon', '', '2026-10-12 20:05:54'),
(472, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/campaign_doctor', '', '2026-10-12 20:05:56'),
(473, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/publish_scheduled_posts', '', '2026-10-12 20:05:57'),
(474, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index', '', '2026-10-12 20:28:23'),
(475, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 20:36:18'),
(476, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/terms', '', '2026-10-12 20:36:30'),
(477, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/privacy', '', '2026-10-12 20:36:31'),
(478, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/dmca', '', '2026-10-12 20:36:31'),
(479, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/ai-disclaimer', '', '2026-10-12 20:36:31'),
(480, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/refund-policy', '', '2026-10-12 20:36:31'),
(481, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cookie-policy', '', '2026-10-12 20:36:32'),
(482, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/google-calendar-sync', '', '2026-10-12 20:36:33'),
(483, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/campaign-doctor', '', '2026-10-12 20:36:34'),
(484, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-12 20:37:13'),
(485, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/jobs', '', '2026-10-12 20:37:17'),
(486, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?tab=generate_image', '', '2026-10-12 20:37:55'),
(487, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?tab=image_editor', '', '2026-10-12 20:37:55'),
(488, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?tab=creative_gallery', '', '2026-10-12 20:37:55'),
(489, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?tab=manual', '', '2026-10-12 20:37:56'),
(490, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?tab=ai', '', '2026-10-12 20:37:56'),
(491, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?from=2026-09-12&to=2026-10-12&network=&export=csv', '', '2026-10-12 20:37:56'),
(492, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?month=9&year=2026', '', '2026-10-12 20:37:57'),
(493, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?month=11&year=2026', '', '2026-10-12 20:37:57'),
(494, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/?month=10&year=2026', '', '2026-10-12 20:37:58'),
(495, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 20:39:28'),
(496, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/pull_campaign_metrics', '', '2026-10-12 20:44:12'),
(497, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/auto_refill_check', '', '2026-10-12 20:44:13'),
(498, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/ab_test_winner', '', '2026-10-12 20:44:13'),
(499, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/auto_buyer_daemon', '', '2026-10-12 20:44:13'),
(500, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/campaign_doctor', '', '2026-10-12 20:44:13'),
(501, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron/publish_scheduled_posts', '', '2026-10-12 20:44:13'),
(502, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-12 20:44:56'),
(503, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/terms', '', '2026-10-12 20:45:05'),
(504, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/privacy', '', '2026-10-12 20:45:05'),
(505, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/dmca', '', '2026-10-12 20:45:06'),
(506, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/ai-disclaimer', '', '2026-10-12 20:45:06'),
(507, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/refund-policy', '', '2026-10-12 20:45:06'),
(508, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cookie-policy', '', '2026-10-12 20:45:06'),
(509, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/search', '', '2026-10-12 20:45:08'),
(510, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/blog', '', '2026-10-12 20:45:08'),
(511, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/blog-details?id=1', '', '2026-10-12 20:45:08'),
(512, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/config/apikeys', '', '2026-10-12 20:45:09'),
(513, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/database', '', '2026-10-12 20:45:09'),
(514, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/cron', '', '2026-10-12 20:45:09'),
(515, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/scratch', '', '2026-10-12 20:45:09'),
(516, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/uploads/videos/.htaccess', '', '2026-10-12 20:45:09'),
(517, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/config/keys.local', '', '2026-10-12 20:45:09'),
(518, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 20:45:21'),
(519, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 20:45:44'),
(520, NULL, '::1', 'Mozilla/5.0 (Windows NT; Windows NT 10.0; en-GB) WindowsPowerShell/5.1.22621.6133', 'Unknown', 'Windows 10/11', 'desktop', '/seopp/login', '', '2026-10-12 20:48:50'),
(521, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/about', '', '2026-10-12 20:50:15'),
(522, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/contact', '', '2026-10-12 20:50:42'),
(523, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/index', '', '2026-10-12 20:50:50'),
(524, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-13 14:20:07'),
(525, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-13 14:20:07'),
(526, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-13 14:20:07'),
(527, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-13 14:22:27'),
(528, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-13 16:07:08'),
(529, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-13 16:36:49'),
(530, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-13 17:20:55'),
(531, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-14 14:26:35'),
(532, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-14 14:27:10'),
(533, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-14 14:27:11'),
(534, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-14 14:27:11'),
(535, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/portfolio', '', '2026-10-14 14:53:09'),
(536, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/portfolio', '', '2026-10-14 15:24:41'),
(537, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-14 16:57:15'),
(538, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-14 18:04:23'),
(539, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-15 08:28:39'),
(540, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-15 14:03:51'),
(541, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-15 14:12:22'),
(542, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/blog', '', '2026-10-15 14:12:23'),
(543, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/jobs', '', '2026-10-15 14:12:24'),
(544, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/job-details?id=1', '', '2026-10-15 14:12:25'),
(545, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-15 14:12:25'),
(546, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-15 14:13:01'),
(547, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-15 14:44:13'),
(548, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/blog', '', '2026-10-15 14:44:13'),
(549, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/jobs', '', '2026-10-15 14:44:14'),
(550, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/job-details?id=1', '', '2026-10-15 14:44:14'),
(551, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-15 14:44:15'),
(552, 100000, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/admin-login', '', '2026-10-15 14:44:16'),
(553, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-15 14:44:43'),
(554, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/totally-missing-page', '', '2026-10-15 15:28:06'),
(555, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/blog', '', '2026-10-15 15:28:07'),
(556, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-15 15:29:37'),
(557, NULL, '::1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/nope-page', '', '2026-10-15 15:29:37'),
(558, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-15 16:57:28'),
(559, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-15 16:57:51'),
(560, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-15 16:57:51'),
(561, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/blog', '', '2026-10-15 16:57:52'),
(562, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/jobs', '', '2026-10-15 16:57:52'),
(563, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/about', '', '2026-10-15 16:57:53'),
(564, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/this-page-does-not-exist', '', '2026-10-15 16:57:55'),
(565, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-15 16:58:37'),
(566, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/portfolio', '', '2026-10-15 16:59:11'),
(567, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/canva-editor', '', '2026-10-15 16:59:13'),
(568, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/image-editor', '', '2026-10-15 16:59:14'),
(569, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-16 18:39:08'),
(570, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-16 18:39:32'),
(571, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-16 18:40:23'),
(572, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-16 18:40:23'),
(573, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/blog', '', '2026-10-16 18:40:24'),
(574, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/jobs', '', '2026-10-16 18:40:24'),
(575, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/about', '', '2026-10-16 18:40:25'),
(576, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/terms', '', '2026-10-16 18:40:25'),
(577, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/contact', '', '2026-10-16 18:40:26'),
(578, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/portfolio', '', '2026-10-16 18:40:33'),
(579, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/no-such-page', '', '2026-10-16 18:40:36'),
(580, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-16 19:36:07'),
(581, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-17 04:17:26'),
(582, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-17 08:29:53'),
(583, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/vcard', '', '2026-10-17 08:31:00'),
(584, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/portfolio/smoke', '', '2026-10-17 08:32:23'),
(585, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/portfolio/contact', '', '2026-10-17 08:32:24'),
(586, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/portfolio/jmauricennadi', '', '2026-10-17 08:32:25'),
(587, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-17 08:37:38'),
(588, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 08:37:41'),
(589, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 08:37:41'),
(590, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 08:37:41'),
(591, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard', '', '2026-10-17 08:37:55'),
(592, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard', '', '2026-10-17 08:38:02'),
(593, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/create-ad', '', '2026-10-17 08:38:09'),
(594, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/faq', '', '2026-10-17 08:38:13'),
(595, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-17 08:44:23'),
(596, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 08:44:23'),
(597, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 08:44:23'),
(598, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 08:44:23'),
(599, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-17 09:12:17'),
(600, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 09:12:17'),
(601, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 09:12:18'),
(602, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 09:12:18'),
(603, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-17 09:12:21'),
(604, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 09:12:24'),
(605, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 09:12:24'),
(606, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 09:12:24'),
(607, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-17 09:16:37'),
(608, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 09:16:37'),
(609, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 09:16:37'),
(610, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 09:16:37'),
(611, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/js/swiper-bundle.min.js.map', '', '2026-10-17 09:16:49'),
(612, 1, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Edg/155.0.0.0 Mobile Safari/537.36', 'Edge', 'Android', 'mobile', '/', '', '2026-10-17 09:18:26'),
(613, 1, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Edg/155.0.0.0 Mobile Safari/537.36', 'Edge', 'Android', 'mobile', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 09:18:27'),
(614, 1, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Edg/155.0.0.0 Mobile Safari/537.36', 'Edge', 'Android', 'mobile', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 09:18:27'),
(615, 1, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Edg/155.0.0.0 Mobile Safari/537.36', 'Edge', 'Android', 'mobile', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 09:18:28'),
(616, 1, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Edg/155.0.0.0 Mobile Safari/537.36', 'Edge', 'Android', 'mobile', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 09:18:28'),
(617, 1, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Edg/155.0.0.0 Mobile Safari/537.36', 'Edge', 'Android', 'mobile', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 09:18:28'),
(618, 1, '127.0.0.1', 'Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Edg/155.0.0.0 Mobile Safari/537.36', 'Edge', 'Android', 'mobile', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 09:18:28'),
(619, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/js/swiper-bundle.min.js.map', '', '2026-10-17 09:18:28'),
(620, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/favicon.ico', '', '2026-10-17 09:21:19'),
(621, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/developer-docs', '', '2026-10-17 09:21:29'),
(622, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/ai-media-buyer', '', '2026-10-17 09:21:43'),
(623, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-17 09:22:07'),
(624, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 09:22:07'),
(625, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 09:22:07'),
(626, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 09:22:07'),
(627, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-17 09:22:19'),
(628, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 09:22:19'),
(629, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 09:22:19'),
(630, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 09:22:19'),
(631, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/pricing-plan', '', '2026-10-17 17:02:52'),
(632, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/ai-disclaimer', '', '2026-10-17 17:03:10'),
(633, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/ugc-video-studio', '', '2026-10-17 17:03:43'),
(634, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/ecommerce-sync', '', '2026-10-17 17:04:46'),
(635, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/admin-login', '', '2026-10-17 17:07:50'),
(636, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/admin-login', '', '2026-10-17 17:11:01'),
(637, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-17 17:12:23'),
(638, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-17 17:12:23'),
(639, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-17 17:12:23'),
(640, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-17 17:13:02'),
(641, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-17 17:13:02'),
(642, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-17 17:15:40'),
(643, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-17 17:15:41'),
(644, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-17 17:16:51'),
(645, 100000, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/', '', '2026-10-17 17:18:05'),
(646, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-17 17:18:05'),
(647, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/register', '', '2026-10-17 17:18:06'),
(648, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/blog', '', '2026-10-17 17:18:06'),
(649, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/jobs', '', '2026-10-17 17:18:06'),
(650, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/about', '', '2026-10-17 17:18:06'),
(651, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/terms', '', '2026-10-17 17:18:07'),
(652, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/this-is-404', '', '2026-10-17 17:18:07'),
(653, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-17 17:31:00'),
(654, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img3.png', '', '2026-10-17 17:31:00'),
(655, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img2.png', '', '2026-10-17 17:31:00'),
(656, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/assets/assets/images/thumbs/project-img1.png', '', '2026-10-17 17:31:00'),
(657, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard', '', '2026-10-17 17:31:06'),
(658, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/dashboard', '', '2026-10-17 17:31:08'),
(659, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-17 18:10:53'),
(660, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-17 18:11:03'),
(661, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-17 18:12:29'),
(662, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/favicon.ico', '', '2026-10-18 15:54:10'),
(663, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/ugc-video-studio', '', '2026-10-18 16:11:25'),
(664, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-18 16:18:00'),
(665, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/marketplace', '', '2026-10-18 16:42:07'),
(666, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/post-creator', '', '2026-10-18 16:54:13'),
(667, NULL, '127.0.0.1', 'curl/8.13.0', 'Unknown', 'Unknown', 'desktop', '/seopp/login', '', '2026-10-18 17:29:36'),
(668, 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0', 'Edge', 'Windows 10/11', 'desktop', '/', '', '2026-10-18 19:30:01');

-- --------------------------------------------------------

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
CREATE TABLE `webhooks` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `event_type` varchar(100) COLLATE latin1_swedish_ci DEFAULT NULL,
  `target_url` varchar(500) COLLATE latin1_swedish_ci DEFAULT NULL,
  `secret` varchar(255) COLLATE latin1_swedish_ci DEFAULT NULL,
  `is_active` tinyint DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `achievements`
--
ALTER TABLE `achievements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_achievements_key` (`achievement_key`);

--
-- Indexes for table `ad_campaigns`
--
ALTER TABLE `ad_campaigns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ad_campaigns_user` (`user_id`),
  ADD KEY `idx_ad_campaigns_status` (`status`),
  ADD KEY `idx_ad_campaigns_type` (`campaign_type`),
  ADD KEY `idx_ad_campaigns_created` (`created_at`);

--
-- Indexes for table `ad_campaign_variants`
--
ALTER TABLE `ad_campaign_variants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_campaign_variants_campaign` (`campaign_id`);

--
-- Indexes for table `agency_client_accounts`
--
ALTER TABLE `agency_client_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_client_access_token` (`access_token`),
  ADD KEY `idx_agency_clients_user` (`agency_user_id`);

--
-- Indexes for table `agency_client_approvals`
--
ALTER TABLE `agency_client_approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_approvals_agency` (`agency_user_id`),
  ADD KEY `idx_approvals_client` (`client_account_id`);

--
-- Indexes for table `agency_client_branding`
--
ALTER TABLE `agency_client_branding`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_agency_branding_agency` (`agency_user_id`),
  ADD KEY `idx_agency_branding_client` (`client_user_id`);

--
-- Indexes for table `agency_portals`
--
ALTER TABLE `agency_portals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_agency_subdomain` (`custom_subdomain`),
  ADD KEY `idx_agency_portal_user` (`agency_user_id`);

--
-- Indexes for table `ai_creatives`
--
ALTER TABLE `ai_creatives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ai_creatives_user` (`user_id`),
  ADD KEY `idx_ai_creatives_type` (`type`);

--
-- Indexes for table `ai_media_buyer_logs`
--
ALTER TABLE `ai_media_buyer_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_buyer_logs_user` (`user_id`);

--
-- Indexes for table `ai_media_buyer_rules`
--
ALTER TABLE `ai_media_buyer_rules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_media_buyer_user` (`user_id`);

--
-- Indexes for table `ai_video_creatives`
--
ALTER TABLE `ai_video_creatives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ai_video_user` (`user_id`);

--
-- Indexes for table `api_keys`
--
ALTER TABLE `api_keys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_api_keys_user` (`user_id`),
  ADD KEY `idx_api_keys_hash` (`key_hash`);

--
-- Indexes for table `api_rate_limits`
--
ALTER TABLE `api_rate_limits`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_key_window` (`key_id`,`window_minute`),
  ADD KEY `idx_window` (`window_minute`);

--
-- Indexes for table `audience_segments`
--
ALTER TABLE `audience_segments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_audience_segments_user` (`user_id`);

--
-- Indexes for table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_blog_posts_slug` (`slug`),
  ADD KEY `idx_blog_posts_status` (`status`),
  ADD KEY `idx_blog_posts_author` (`author_id`);

--
-- Indexes for table `calendar_sync_events`
--
ALTER TABLE `calendar_sync_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_calendar_sync_user` (`user_id`),
  ADD KEY `idx_calendar_sync_post` (`post_id`);

--
-- Indexes for table `campaign_metrics_daily`
--
ALTER TABLE `campaign_metrics_daily`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_campaign_metrics` (`campaign_id`,`variant_id`,`date`),
  ADD KEY `idx_campaign_metrics_date` (`date`);

--
-- Indexes for table `campaign_recommendations`
--
ALTER TABLE `campaign_recommendations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_campaign_rec_campaign` (`campaign_id`),
  ADD KEY `idx_campaign_rec_status` (`status`);

--
-- Indexes for table `campaign_run_logs`
--
ALTER TABLE `campaign_run_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_campaign_run_logs_campaign` (`campaign_id`),
  ADD KEY `idx_campaign_run_logs_created` (`created_at`);

--
-- Indexes for table `competitor_ad_analyses`
--
ALTER TABLE `competitor_ad_analyses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ad_analyses_user` (`user_id`);

--
-- Indexes for table `connected_accounts`
--
ALTER TABLE `connected_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_connected_accounts_user` (`user_id`),
  ADD KEY `idx_connected_accounts_platform` (`platform`);

--
-- Indexes for table `cookie_consents`
--
ALTER TABLE `cookie_consents`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_cookie_consents_ip` (`ip`),
  ADD KEY `idx_cookie_consents_uuid` (`consent_uuid`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `creator_bounties`
--
ALTER TABLE `creator_bounties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_bounties_brand` (`brand_user_id`),
  ADD KEY `idx_bounties_status` (`status`),
  ADD KEY `idx_bounties_creator` (`claimed_creator_id`);

--
-- Indexes for table `creator_bounty_submissions`
--
ALTER TABLE `creator_bounty_submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_bounty_subs_bounty` (`bounty_id`),
  ADD KEY `idx_bounty_subs_creator` (`creator_user_id`);

--
-- Indexes for table `cron_run_logs`
--
ALTER TABLE `cron_run_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_cron_logs_job` (`job_name`),
  ADD KEY `idx_cron_logs_status` (`status`),
  ADD KEY `idx_cron_logs_started` (`started_at`);

--
-- Indexes for table `dating_blocks`
--
ALTER TABLE `dating_blocks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_dating_blocks` (`blocker_id`,`blocked_id`),
  ADD KEY `idx_dating_blocks_blocked` (`blocked_id`);

--
-- Indexes for table `dating_pairs`
--
ALTER TABLE `dating_pairs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pair_unique` (`sender_id`,`receiver_id`),
  ADD KEY `idx_receiver` (`receiver_id`);

--
-- Indexes for table `dating_profiles`
--
ALTER TABLE `dating_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_dating_profiles_user` (`user_id`),
  ADD KEY `idx_dating_profiles_gender` (`gender`),
  ADD KEY `idx_dating_profiles_looking` (`looking_for`),
  ADD KEY `idx_dating_profiles_visible` (`is_visible`),
  ADD KEY `idx_dating_profiles_city` (`city`);

--
-- Indexes for table `dating_verification_uploads`
--
ALTER TABLE `dating_verification_uploads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_dating_verification_user` (`user_id`),
  ADD KEY `idx_dating_verification_status` (`status`);

--
-- Indexes for table `dynamic_content`
--
ALTER TABLE `dynamic_content`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_dynamic_content` (`page_slug`,`section_key`,`item_key`),
  ADD KEY `idx_dynamic_content_slug` (`page_slug`);

--
-- Indexes for table `ecommerce_campaign_packs`
--
ALTER TABLE `ecommerce_campaign_packs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ecom_packs_product` (`product_id`),
  ADD KEY `idx_ecom_packs_user` (`user_id`);

--
-- Indexes for table `ecommerce_products`
--
ALTER TABLE `ecommerce_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ecom_prods_store` (`store_id`),
  ADD KEY `idx_ecom_prods_user` (`user_id`);

--
-- Indexes for table `ecommerce_stores`
--
ALTER TABLE `ecommerce_stores`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ecom_stores_user` (`user_id`);

--
-- Indexes for table `email_campaigns`
--
ALTER TABLE `email_campaigns`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email_campaigns_admin` (`admin_id`),
  ADD KEY `idx_email_campaigns_status` (`status`);

--
-- Indexes for table `email_campaign_recipients`
--
ALTER TABLE `email_campaign_recipients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email_recipients_campaign` (`campaign_id`),
  ADD KEY `idx_email_recipients_user` (`user_id`);

--
-- Indexes for table `email_logs`
--
ALTER TABLE `email_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email_logs_recipient` (`recipient`),
  ADD KEY `idx_email_logs_type` (`type`);

--
-- Indexes for table `fraud_flags`
--
ALTER TABLE `fraud_flags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_fraud_flags_user` (`user_id`),
  ADD KEY `idx_fraud_flags_type` (`flag_type`),
  ADD KEY `idx_fraud_flags_severity` (`severity`),
  ADD KEY `idx_fraud_flags_status` (`status`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_invoices_txn` (`transaction_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status` (`status`),
  ADD KEY `category` (`category`);

--
-- Indexes for table `jobs_services`
--
ALTER TABLE `jobs_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `type` (`type`),
  ADD KEY `category` (`category`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `marketplace_items`
--
ALTER TABLE `marketplace_items`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_marketplace_items_slug` (`slug`),
  ADD KEY `idx_marketplace_items_user` (`user_id`),
  ADD KEY `idx_marketplace_items_type` (`item_type`),
  ADD KEY `idx_marketplace_items_status` (`status`),
  ADD KEY `idx_marketplace_items_category` (`category`),
  ADD KEY `idx_marketplace_items_boosted` (`is_boosted`);

--
-- Indexes for table `marketplace_reviews`
--
ALTER TABLE `marketplace_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_marketplace_reviews_item` (`item_id`),
  ADD KEY `idx_marketplace_reviews_reviewer` (`reviewer_user_id`),
  ADD KEY `idx_marketplace_reviews_rating` (`rating`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_notifications_user` (`user_id`),
  ADD KEY `idx_notifications_read` (`is_read`),
  ADD KEY `idx_notifications_type` (`type`),
  ADD KEY `idx_notifications_created` (`created_at`);

--
-- Indexes for table `p2p_conversations`
--
ALTER TABLE `p2p_conversations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_a` (`user_a`),
  ADD KEY `user_b` (`user_b`);

--
-- Indexes for table `p2p_deals`
--
ALTER TABLE `p2p_deals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proposer_id` (`proposer_id`),
  ADD KEY `receiver_id` (`receiver_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `p2p_messages`
--
ALTER TABLE `p2p_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_p2p_messages_sender` (`sender_id`),
  ADD KEY `idx_p2p_messages_receiver` (`receiver_id`),
  ADD KEY `idx_p2p_messages_read` (`is_read`),
  ADD KEY `conversation_id` (`conversation_id`);

--
-- Indexes for table `payout_requests`
--
ALTER TABLE `payout_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `policy_rules`
--
ALTER TABLE `policy_rules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_policy_rules_platform` (`platform`),
  ADD KEY `idx_policy_rules_type` (`rule_type`),
  ADD KEY `idx_policy_rules_severity` (`severity`),
  ADD KEY `idx_policy_rules_active` (`is_active`);

--
-- Indexes for table `policy_scan_logs`
--
ALTER TABLE `policy_scan_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_policy_scan_user` (`user_id`),
  ADD KEY `idx_policy_scan_campaign` (`campaign_id`),
  ADD KEY `idx_policy_scan_post` (`post_id`),
  ADD KEY `idx_policy_scan_score` (`compliance_score`);

--
-- Indexes for table `post_metrics_daily`
--
ALTER TABLE `post_metrics_daily`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_post_metrics` (`post_id`,`date`),
  ADD KEY `idx_post_metrics_date` (`date`);

--
-- Indexes for table `pricing_plans`
--
ALTER TABLE `pricing_plans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pricing_plans_status` (`status`),
  ADD KEY `idx_pricing_plans_cycle` (`billing_cycle`);

--
-- Indexes for table `pricing_plan_currency_overrides`
--
ALTER TABLE `pricing_plan_currency_overrides`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_plan_currency_plan` (`plan_id`),
  ADD KEY `idx_plan_currency_code` (`currency_code`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_referrals_referrer` (`referrer_id`),
  ADD KEY `idx_referrals_referred` (`referred_id`),
  ADD KEY `idx_referrals_status` (`status`);

--
-- Indexes for table `scheduled_posts`
--
ALTER TABLE `scheduled_posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_scheduled_posts_user` (`user_id`),
  ADD KEY `idx_scheduled_posts_status` (`status`),
  ADD KEY `idx_scheduled_posts_time` (`scheduled_time`);

--
-- Indexes for table `server_tracking_events`
--
ALTER TABLE `server_tracking_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tracking_events_pixel` (`pixel_id`),
  ADD KEY `idx_tracking_events_user` (`user_id`);

--
-- Indexes for table `server_tracking_pixels`
--
ALTER TABLE `server_tracking_pixels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_pixel_token` (`pixel_token`),
  ADD KEY `idx_tracking_pixels_user` (`user_id`);

--
-- Indexes for table `service_check_log`
--
ALTER TABLE `service_check_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_key_time` (`check_key`,`checked_at`);

--
-- Indexes for table `site_reviews`
--
ALTER TABLE `site_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `status` (`status`),
  ADD KEY `is_featured` (`is_featured`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`setting_key`),
  ADD KEY `idx_site_settings_group` (`setting_group`);

--
-- Indexes for table `social_inbox_messages`
--
ALTER TABLE `social_inbox_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_inbox_user` (`user_id`),
  ADD KEY `idx_inbox_status` (`status`);

--
-- Indexes for table `social_inbox_rules`
--
ALTER TABLE `social_inbox_rules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_inbox_rules_user` (`user_id`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_support_tickets_user` (`user_id`),
  ADD KEY `idx_support_tickets_status` (`status`),
  ADD KEY `idx_support_tickets_type` (`ticket_type`),
  ADD KEY `idx_support_tickets_priority` (`priority`),
  ADD KEY `idx_support_tickets_report_target` (`report_target_user_id`);

--
-- Indexes for table `team_invitations`
--
ALTER TABLE `team_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_team_invitations_token` (`invite_token`),
  ADD KEY `idx_team_invitations_owner` (`owner_id`),
  ADD KEY `idx_team_invitations_email` (`email`),
  ADD KEY `idx_team_invitations_status` (`status`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_user_id` (`parent_user_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `email` (`email`);

--
-- Indexes for table `ticket_messages`
--
ALTER TABLE `ticket_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ticket_messages_ticket` (`ticket_id`),
  ADD KEY `idx_ticket_messages_sender` (`sender_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_transactions_invoice` (`invoice_number`),
  ADD KEY `idx_transactions_user` (`user_id`),
  ADD KEY `idx_transactions_status` (`status`),
  ADD KEY `idx_transactions_gateway` (`gateway`),
  ADD KEY `idx_transactions_created` (`created_at`);

--
-- Indexes for table `translations`
--
ALTER TABLE `translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_translations` (`locale`,`translation_key`),
  ADD KEY `idx_translations_locale` (`locale`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD UNIQUE KEY `uq_users_referral` (`referral_code`),
  ADD KEY `idx_users_role` (`role`),
  ADD KEY `idx_users_status` (`status`),
  ADD KEY `idx_users_parent` (`parent_user_id`),
  ADD KEY `idx_users_plan` (`plan_id`);

--
-- Indexes for table `user_achievements`
--
ALTER TABLE `user_achievements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_achievements_user` (`user_id`),
  ADD KEY `idx_user_achievements_achievement` (`achievement_id`);

--
-- Indexes for table `user_deals`
--
ALTER TABLE `user_deals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `conversation_id` (`conversation_id`),
  ADD KEY `proposer_id` (`proposer_id`),
  ADD KEY `recipient_id` (`recipient_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `user_follows`
--
ALTER TABLE `user_follows`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_follow` (`follower_id`,`following_id`),
  ADD KEY `follower_id` (`follower_id`),
  ADD KEY `following_id` (`following_id`);

--
-- Indexes for table `user_portfolios`
--
ALTER TABLE `user_portfolios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `username_2` (`username`),
  ADD KEY `is_public` (`is_public`);

--
-- Indexes for table `user_recommendations`
--
ALTER TABLE `user_recommendations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `recommender_id` (`recommender_id`),
  ADD KEY `target_user_id` (`target_user_id`);

--
-- Indexes for table `user_reports`
--
ALTER TABLE `user_reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reporter_id` (`reporter_id`),
  ADD KEY `reported_user_id` (`reported_user_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `user_vcards`
--
ALTER TABLE `user_vcards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `username_2` (`username`),
  ADD KEY `is_public` (`is_public`);

--
-- Indexes for table `visitor_logs`
--
ALTER TABLE `visitor_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visitor_logs_user` (`user_id`),
  ADD KEY `idx_visitor_logs_ip` (`ip`),
  ADD KEY `idx_visitor_logs_created` (`created_at`);

--
-- Indexes for table `webhooks`
--
ALTER TABLE `webhooks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_webhooks_user` (`user_id`),
  ADD KEY `idx_webhooks_event` (`event_type`),
  ADD KEY `idx_webhooks_active` (`is_active`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `achievements`
--
ALTER TABLE `achievements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ad_campaigns`
--
ALTER TABLE `ad_campaigns`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ad_campaign_variants`
--
ALTER TABLE `ad_campaign_variants`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `agency_client_accounts`
--
ALTER TABLE `agency_client_accounts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `agency_client_approvals`
--
ALTER TABLE `agency_client_approvals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `agency_client_branding`
--
ALTER TABLE `agency_client_branding`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `agency_portals`
--
ALTER TABLE `agency_portals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ai_creatives`
--
ALTER TABLE `ai_creatives`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `ai_media_buyer_logs`
--
ALTER TABLE `ai_media_buyer_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ai_media_buyer_rules`
--
ALTER TABLE `ai_media_buyer_rules`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ai_video_creatives`
--
ALTER TABLE `ai_video_creatives`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `api_keys`
--
ALTER TABLE `api_keys`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `api_rate_limits`
--
ALTER TABLE `api_rate_limits`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `audience_segments`
--
ALTER TABLE `audience_segments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `blog_posts`
--
ALTER TABLE `blog_posts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `calendar_sync_events`
--
ALTER TABLE `calendar_sync_events`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaign_metrics_daily`
--
ALTER TABLE `campaign_metrics_daily`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaign_recommendations`
--
ALTER TABLE `campaign_recommendations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaign_run_logs`
--
ALTER TABLE `campaign_run_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `competitor_ad_analyses`
--
ALTER TABLE `competitor_ad_analyses`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `connected_accounts`
--
ALTER TABLE `connected_accounts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `cookie_consents`
--
ALTER TABLE `cookie_consents`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `creator_bounties`
--
ALTER TABLE `creator_bounties`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `creator_bounty_submissions`
--
ALTER TABLE `creator_bounty_submissions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cron_run_logs`
--
ALTER TABLE `cron_run_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `dating_blocks`
--
ALTER TABLE `dating_blocks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dating_pairs`
--
ALTER TABLE `dating_pairs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dating_profiles`
--
ALTER TABLE `dating_profiles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dating_verification_uploads`
--
ALTER TABLE `dating_verification_uploads`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dynamic_content`
--
ALTER TABLE `dynamic_content`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ecommerce_campaign_packs`
--
ALTER TABLE `ecommerce_campaign_packs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ecommerce_products`
--
ALTER TABLE `ecommerce_products`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ecommerce_stores`
--
ALTER TABLE `ecommerce_stores`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `email_campaigns`
--
ALTER TABLE `email_campaigns`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_campaign_recipients`
--
ALTER TABLE `email_campaign_recipients`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `email_logs`
--
ALTER TABLE `email_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `fraud_flags`
--
ALTER TABLE `fraud_flags`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobs_services`
--
ALTER TABLE `jobs_services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `marketplace_items`
--
ALTER TABLE `marketplace_items`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `marketplace_reviews`
--
ALTER TABLE `marketplace_reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `p2p_conversations`
--
ALTER TABLE `p2p_conversations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `p2p_deals`
--
ALTER TABLE `p2p_deals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `p2p_messages`
--
ALTER TABLE `p2p_messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `payout_requests`
--
ALTER TABLE `payout_requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `policy_rules`
--
ALTER TABLE `policy_rules`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `policy_scan_logs`
--
ALTER TABLE `policy_scan_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post_metrics_daily`
--
ALTER TABLE `post_metrics_daily`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pricing_plans`
--
ALTER TABLE `pricing_plans`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pricing_plan_currency_overrides`
--
ALTER TABLE `pricing_plan_currency_overrides`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `scheduled_posts`
--
ALTER TABLE `scheduled_posts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `server_tracking_events`
--
ALTER TABLE `server_tracking_events`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `server_tracking_pixels`
--
ALTER TABLE `server_tracking_pixels`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service_check_log`
--
ALTER TABLE `service_check_log`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=151;

--
-- AUTO_INCREMENT for table `site_reviews`
--
ALTER TABLE `site_reviews`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `social_inbox_messages`
--
ALTER TABLE `social_inbox_messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `social_inbox_rules`
--
ALTER TABLE `social_inbox_rules`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `team_invitations`
--
ALTER TABLE `team_invitations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `team_members`
--
ALTER TABLE `team_members`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ticket_messages`
--
ALTER TABLE `ticket_messages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `translations`
--
ALTER TABLE `translations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=999905;

--
-- AUTO_INCREMENT for table `user_achievements`
--
ALTER TABLE `user_achievements`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_deals`
--
ALTER TABLE `user_deals`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_follows`
--
ALTER TABLE `user_follows`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_portfolios`
--
ALTER TABLE `user_portfolios`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_recommendations`
--
ALTER TABLE `user_recommendations`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_reports`
--
ALTER TABLE `user_reports`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_vcards`
--
ALTER TABLE `user_vcards`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `visitor_logs`
--
ALTER TABLE `visitor_logs`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=669;

--
-- AUTO_INCREMENT for table `webhooks`
--
ALTER TABLE `webhooks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

-- --------------------------------------------------------

--
-- Structure for view `tickets`
--
DROP TABLE IF EXISTS `tickets`;

DROP VIEW IF EXISTS `tickets`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tickets`  AS SELECT `support_tickets`.`id` AS `id`, `support_tickets`.`user_id` AS `user_id`, lpad(`support_tickets`.`id`,6,'0') AS `ticket_number`, `support_tickets`.`ticket_type` AS `type`, `support_tickets`.`priority` AS `priority`, `support_tickets`.`subject` AS `subject`, `support_tickets`.`status` AS `status`, `support_tickets`.`created_at` AS `created_at`, `support_tickets`.`updated_at` AS `updated_at` FROM `support_tickets` ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ad_campaigns`
--
ALTER TABLE `ad_campaigns`
  ADD CONSTRAINT `fk_ad_campaigns_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ad_campaign_variants`
--
ALTER TABLE `ad_campaign_variants`
  ADD CONSTRAINT `fk_campaign_variants_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `agency_client_branding`
--
ALTER TABLE `agency_client_branding`
  ADD CONSTRAINT `fk_agency_branding_agency` FOREIGN KEY (`agency_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_agency_branding_client` FOREIGN KEY (`client_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ai_creatives`
--
ALTER TABLE `ai_creatives`
  ADD CONSTRAINT `fk_ai_creatives_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `api_keys`
--
ALTER TABLE `api_keys`
  ADD CONSTRAINT `fk_api_keys_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `audience_segments`
--
ALTER TABLE `audience_segments`
  ADD CONSTRAINT `fk_audience_segments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `blog_posts`
--
ALTER TABLE `blog_posts`
  ADD CONSTRAINT `fk_blog_posts_author` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `calendar_sync_events`
--
ALTER TABLE `calendar_sync_events`
  ADD CONSTRAINT `fk_calendar_sync_post` FOREIGN KEY (`post_id`) REFERENCES `scheduled_posts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_calendar_sync_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `campaign_metrics_daily`
--
ALTER TABLE `campaign_metrics_daily`
  ADD CONSTRAINT `fk_campaign_metrics_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `campaign_recommendations`
--
ALTER TABLE `campaign_recommendations`
  ADD CONSTRAINT `fk_campaign_rec_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `campaign_run_logs`
--
ALTER TABLE `campaign_run_logs`
  ADD CONSTRAINT `fk_campaign_run_logs_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `connected_accounts`
--
ALTER TABLE `connected_accounts`
  ADD CONSTRAINT `fk_connected_accounts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `dating_blocks`
--
ALTER TABLE `dating_blocks`
  ADD CONSTRAINT `fk_dating_blocks_blocked` FOREIGN KEY (`blocked_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_dating_blocks_blocker` FOREIGN KEY (`blocker_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `dating_profiles`
--
ALTER TABLE `dating_profiles`
  ADD CONSTRAINT `fk_dating_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `dating_verification_uploads`
--
ALTER TABLE `dating_verification_uploads`
  ADD CONSTRAINT `fk_dating_verification_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `email_campaigns`
--
ALTER TABLE `email_campaigns`
  ADD CONSTRAINT `fk_email_campaigns_admin` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `email_campaign_recipients`
--
ALTER TABLE `email_campaign_recipients`
  ADD CONSTRAINT `fk_email_recipients_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `email_campaigns` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_email_recipients_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `fraud_flags`
--
ALTER TABLE `fraud_flags`
  ADD CONSTRAINT `fk_fraud_flags_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `marketplace_items`
--
ALTER TABLE `marketplace_items`
  ADD CONSTRAINT `fk_marketplace_items_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `marketplace_reviews`
--
ALTER TABLE `marketplace_reviews`
  ADD CONSTRAINT `fk_marketplace_reviews_item` FOREIGN KEY (`item_id`) REFERENCES `marketplace_items` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_marketplace_reviews_reviewer` FOREIGN KEY (`reviewer_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `p2p_messages`
--
ALTER TABLE `p2p_messages`
  ADD CONSTRAINT `fk_p2p_messages_receiver` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_p2p_messages_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `policy_scan_logs`
--
ALTER TABLE `policy_scan_logs`
  ADD CONSTRAINT `fk_policy_scan_campaign` FOREIGN KEY (`campaign_id`) REFERENCES `ad_campaigns` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_policy_scan_post` FOREIGN KEY (`post_id`) REFERENCES `scheduled_posts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_policy_scan_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `post_metrics_daily`
--
ALTER TABLE `post_metrics_daily`
  ADD CONSTRAINT `fk_post_metrics_post` FOREIGN KEY (`post_id`) REFERENCES `scheduled_posts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `pricing_plan_currency_overrides`
--
ALTER TABLE `pricing_plan_currency_overrides`
  ADD CONSTRAINT `fk_plan_currency_plan` FOREIGN KEY (`plan_id`) REFERENCES `pricing_plans` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `referrals`
--
ALTER TABLE `referrals`
  ADD CONSTRAINT `fk_referrals_referred` FOREIGN KEY (`referred_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_referrals_referrer` FOREIGN KEY (`referrer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `scheduled_posts`
--
ALTER TABLE `scheduled_posts`
  ADD CONSTRAINT `fk_scheduled_posts_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD CONSTRAINT `fk_support_tickets_report_target` FOREIGN KEY (`report_target_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_support_tickets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `team_invitations`
--
ALTER TABLE `team_invitations`
  ADD CONSTRAINT `fk_team_invitations_owner` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ticket_messages`
--
ALTER TABLE `ticket_messages`
  ADD CONSTRAINT `fk_ticket_messages_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_ticket_messages_ticket` FOREIGN KEY (`ticket_id`) REFERENCES `support_tickets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `fk_transactions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_parent` FOREIGN KEY (`parent_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_users_plan` FOREIGN KEY (`plan_id`) REFERENCES `pricing_plans` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `user_achievements`
--
ALTER TABLE `user_achievements`
  ADD CONSTRAINT `fk_user_achievements_achievement` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_user_achievements_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `visitor_logs`
--
ALTER TABLE `visitor_logs`
  ADD CONSTRAINT `fk_visitor_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `webhooks`
--
ALTER TABLE `webhooks`
  ADD CONSTRAINT `fk_webhooks_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
