-- ============================================================
-- Adsbooster.net - Complete Database Schema
-- Engine: InnoDB | Collation: utf8mb4_unicode_ci
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ============================================================
-- DATABASE
-- ============================================================
CREATE DATABASE IF NOT EXISTS adsbooster
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE adsbooster;

-- ============================================================
-- CORE / PLATFORM
-- ============================================================

CREATE TABLE IF NOT EXISTS site_settings (
  setting_key VARCHAR(255) NOT NULL,
  setting_value TEXT,
  setting_group VARCHAR(100) DEFAULT 'general',
  PRIMARY KEY (setting_key),
  INDEX idx_site_settings_group (setting_group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dynamic_content (
  id INT AUTO_INCREMENT PRIMARY KEY,
  page_slug VARCHAR(100) NOT NULL,
  section_key VARCHAR(100) NOT NULL,
  item_key VARCHAR(100) NOT NULL,
  content_value TEXT,
  media_url VARCHAR(500),
  UNIQUE KEY uq_dynamic_content (page_slug, section_key, item_key),
  INDEX idx_dynamic_content_slug (page_slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(255),
  email VARCHAR(255) NOT NULL,
  password VARCHAR(255) NULL,
  google_id VARCHAR(255) NULL,
  role ENUM('user','team_member','admin') DEFAULT 'user',
  parent_user_id INT NULL,
  account_type ENUM('individual','agency_owner','agency_client') DEFAULT 'individual',
  ad_credits DECIMAL(10,2) DEFAULT 0.00,
  ai_credits INT DEFAULT 0,
  ai_preferred_provider VARCHAR(50) NULL,
  plan_id INT NULL,
  billing_cycle VARCHAR(20),
  plan_expiry DATE NULL,
  onboarding_completed TINYINT DEFAULT 0,
  status ENUM('active','suspended','pending') DEFAULT 'active',
  is_verified_seller TINYINT DEFAULT 0,
  referral_code VARCHAR(20) NULL,
  referred_by VARCHAR(20) NULL,
  auto_refill_enabled TINYINT DEFAULT 0,
  auto_refill_threshold DECIMAL(10,2) DEFAULT 0.00,
  auto_refill_amount DECIMAL(10,2) DEFAULT 0.00,
  auto_refill_gateway VARCHAR(20) NULL,
  totp_secret VARCHAR(255) NULL,
  totp_enabled TINYINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_users_email (email),
  UNIQUE KEY uq_users_referral (referral_code),
  INDEX idx_users_role (role),
  INDEX idx_users_status (status),
  INDEX idx_users_parent (parent_user_id),
  INDEX idx_users_plan (plan_id),
  CONSTRAINT fk_users_parent FOREIGN KEY (parent_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS visitor_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  ip VARCHAR(45),
  user_agent TEXT,
  browser VARCHAR(100),
  os VARCHAR(100),
  device_type ENUM('desktop','mobile'),
  request_uri VARCHAR(500),
  country VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_visitor_logs_user (user_id),
  INDEX idx_visitor_logs_ip (ip),
  INDEX idx_visitor_logs_created (created_at),
  CONSTRAINT fk_visitor_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cookie_consents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ip VARCHAR(45),
  consent_uuid VARCHAR(100),
  necessary TINYINT DEFAULT 1,
  preferences TINYINT DEFAULT 0,
  analytics TINYINT DEFAULT 0,
  marketing TINYINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  INDEX idx_cookie_consents_ip (ip),
  INDEX idx_cookie_consents_uuid (consent_uuid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(500),
  slug VARCHAR(500),
  excerpt TEXT,
  body LONGTEXT,
  featured_image VARCHAR(500),
  author_id INT NULL,
  published_at DATETIME NULL,
  status ENUM('draft','published') DEFAULT 'draft',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_blog_posts_slug (slug),
  INDEX idx_blog_posts_status (status),
  INDEX idx_blog_posts_author (author_id),
  CONSTRAINT fk_blog_posts_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SOCIAL & AI
-- ============================================================

CREATE TABLE IF NOT EXISTS connected_accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  platform VARCHAR(50) NOT NULL,
  access_token TEXT,
  refresh_token TEXT NULL,
  token_expiry DATETIME NULL,
  platform_user_id VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_connected_accounts_user (user_id),
  INDEX idx_connected_accounts_platform (platform),
  CONSTRAINT fk_connected_accounts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS scheduled_posts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  platform VARCHAR(50),
  post_type ENUM('manual','ai_generated'),
  caption TEXT,
  media_url VARCHAR(500),
  media_type ENUM('image','ugc_video','reel','text_only','document','pdf'),
  scheduled_time DATETIME,
  google_calendar_event_id VARCHAR(255) NULL,
  status ENUM('scheduled','published','failed','cancelled') DEFAULT 'scheduled',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_scheduled_posts_user (user_id),
  INDEX idx_scheduled_posts_status (status),
  INDEX idx_scheduled_posts_time (scheduled_time),
  CONSTRAINT fk_scheduled_posts_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_creatives (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('text','image','video'),
  prompt TEXT,
  result_output TEXT,
  credits_used INT DEFAULT 1,
  metadata JSON NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ai_creatives_user (user_id),
  INDEX idx_ai_creatives_type (type),
  CONSTRAINT fk_ai_creatives_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS calendar_sync_events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  post_id INT NULL,
  google_event_id VARCHAR(255),
  event_title VARCHAR(500),
  event_start DATETIME,
  event_end DATETIME,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_calendar_sync_user (user_id),
  INDEX idx_calendar_sync_post (post_id),
  CONSTRAINT fk_calendar_sync_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_calendar_sync_post FOREIGN KEY (post_id) REFERENCES scheduled_posts(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- ADVERTISING
-- ============================================================

CREATE TABLE IF NOT EXISTS ad_campaigns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  campaign_name VARCHAR(500),
  campaign_type ENUM('meta','instagram','tiktok','google_ads','snapchat','combo_pack'),
  objective VARCHAR(100),
  budget_type ENUM('daily','lifetime'),
  budget_amount DECIMAL(10,2),
  targeting_spec JSON NULL,
  headline VARCHAR(500),
  primary_text TEXT,
  destination_url VARCHAR(500),
  creative_media_url VARCHAR(500) NULL,
  status ENUM('pending','active','paused','completed','rejected') DEFAULT 'pending',
  autopilot_enabled TINYINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_ad_campaigns_user (user_id),
  INDEX idx_ad_campaigns_status (status),
  INDEX idx_ad_campaigns_type (campaign_type),
  INDEX idx_ad_campaigns_created (created_at),
  CONSTRAINT fk_ad_campaigns_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS campaign_metrics_daily (
  id INT AUTO_INCREMENT PRIMARY KEY,
  campaign_id INT NOT NULL,
  variant_id INT NULL,
  date DATE NOT NULL,
  impressions INT DEFAULT 0,
  clicks INT DEFAULT 0,
  spend DECIMAL(10,2) DEFAULT 0,
  conversions INT DEFAULT 0,
  ctr DECIMAL(5,2) DEFAULT 0,
  cpc DECIMAL(10,2) DEFAULT 0,
  UNIQUE KEY uq_campaign_metrics (campaign_id, variant_id, date),
  INDEX idx_campaign_metrics_date (date),
  CONSTRAINT fk_campaign_metrics_campaign FOREIGN KEY (campaign_id) REFERENCES ad_campaigns(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS post_metrics_daily (
  id INT AUTO_INCREMENT PRIMARY KEY,
  post_id INT NOT NULL,
  date DATE NOT NULL,
  reach INT DEFAULT 0,
  likes INT DEFAULT 0,
  comments INT DEFAULT 0,
  shares INT DEFAULT 0,
  saves INT DEFAULT 0,
  UNIQUE KEY uq_post_metrics (post_id, date),
  INDEX idx_post_metrics_date (date),
  CONSTRAINT fk_post_metrics_post FOREIGN KEY (post_id) REFERENCES scheduled_posts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS campaign_recommendations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  campaign_id INT NOT NULL,
  recommendation_type VARCHAR(100),
  message TEXT,
  suggested_action TEXT,
  status ENUM('pending','applied','dismissed','auto_applied') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_campaign_rec_campaign (campaign_id),
  INDEX idx_campaign_rec_status (status),
  CONSTRAINT fk_campaign_rec_campaign FOREIGN KEY (campaign_id) REFERENCES ad_campaigns(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ad_campaign_variants (
  id INT AUTO_INCREMENT PRIMARY KEY,
  campaign_id INT NOT NULL,
  variant_label VARCHAR(50),
  headline VARCHAR(500),
  primary_text TEXT,
  creative_media_url VARCHAR(500) NULL,
  traffic_split_pct INT DEFAULT 25,
  is_winner TINYINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_campaign_variants_campaign (campaign_id),
  CONSTRAINT fk_campaign_variants_campaign FOREIGN KEY (campaign_id) REFERENCES ad_campaigns(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audience_segments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(255),
  criteria_json JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audience_segments_user (user_id),
  CONSTRAINT fk_audience_segments_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- COMMERCE
-- ============================================================

CREATE TABLE IF NOT EXISTS pricing_plans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(255),
  description TEXT,
  price DECIMAL(10,2),
  duration VARCHAR(50) NULL,
  billing_cycle ENUM('monthly','yearly','pay_as_you_go'),
  features_json JSON,
  is_featured TINYINT DEFAULT 0,
  sort_order INT DEFAULT 0,
  status ENUM('active','inactive') DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_pricing_plans_status (status),
  INDEX idx_pricing_plans_cycle (billing_cycle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Add FK for users.plan_id after pricing_plans exists
ALTER TABLE users
  ADD CONSTRAINT fk_users_plan FOREIGN KEY (plan_id) REFERENCES pricing_plans(id) ON DELETE SET NULL;

CREATE TABLE IF NOT EXISTS pricing_plan_currency_overrides (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plan_id INT NOT NULL,
  currency_code VARCHAR(3),
  price DECIMAL(10,2),
  INDEX idx_plan_currency_plan (plan_id),
  INDEX idx_plan_currency_code (currency_code),
  CONSTRAINT fk_plan_currency_plan FOREIGN KEY (plan_id) REFERENCES pricing_plans(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  gateway ENUM('paystack','flutterwave'),
  type ENUM('plan_subscription','ad_credit_topup','ai_credit_topup'),
  amount DECIMAL(10,2),
  currency VARCHAR(3) DEFAULT 'USD',
  status ENUM('pending','successful','failed','refunded') DEFAULT 'pending',
  invoice_number VARCHAR(50),
  invoice_path VARCHAR(500) NULL,
  gateway_reference VARCHAR(255) NULL,
  reference VARCHAR(255) NULL,
  metadata JSON NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  UNIQUE KEY uq_transactions_invoice (invoice_number),
  INDEX idx_transactions_user (user_id),
  INDEX idx_transactions_status (status),
  INDEX idx_transactions_gateway (gateway),
  INDEX idx_transactions_created (created_at),
  CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SUPPORT
-- ============================================================

CREATE TABLE IF NOT EXISTS support_tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  ticket_type ENUM('support','bug_report','billing'),
  priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
  subject VARCHAR(500),
  status ENUM('open','in_progress','resolved','closed') DEFAULT 'open',
  report_target_user_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_support_tickets_user (user_id),
  INDEX idx_support_tickets_status (status),
  INDEX idx_support_tickets_type (ticket_type),
  INDEX idx_support_tickets_priority (priority),
  INDEX idx_support_tickets_report_target (report_target_user_id),
  CONSTRAINT fk_support_tickets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_support_tickets_report_target FOREIGN KEY (report_target_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ticket_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT NOT NULL,
  sender_id INT NOT NULL,
  message TEXT,
  attachment_path VARCHAR(500) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_ticket_messages_ticket (ticket_id),
  INDEX idx_ticket_messages_sender (sender_id),
  CONSTRAINT fk_ticket_messages_ticket FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE,
  CONSTRAINT fk_ticket_messages_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS p2p_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  sender_id INT NOT NULL,
  receiver_id INT NOT NULL,
  message TEXT,
  is_read TINYINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_p2p_messages_sender (sender_id),
  INDEX idx_p2p_messages_receiver (receiver_id),
  INDEX idx_p2p_messages_read (is_read),
  CONSTRAINT fk_p2p_messages_sender FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_p2p_messages_receiver FOREIGN KEY (receiver_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- MARKETPLACE
-- ============================================================

CREATE TABLE IF NOT EXISTS marketplace_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  item_type ENUM('product','service','company'),
  listing_type VARCHAR(50) NULL,
  title VARCHAR(500),
  slug VARCHAR(500),
  category VARCHAR(255),
  price DECIMAL(10,2) NULL,
  featured_image VARCHAR(500),
  image_url VARCHAR(500) NULL,
  description TEXT,
  seller_verified TINYINT DEFAULT 0,
  contact_email VARCHAR(255),
  website_url VARCHAR(500) NULL,
  status ENUM('active','inactive','pending') DEFAULT 'pending',
  featured TINYINT DEFAULT 0,
  views_count INT DEFAULT 0,
  rating DECIMAL(3,2) DEFAULT 0,
  is_boosted TINYINT DEFAULT 0,
  boost_expires_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_marketplace_items_slug (slug),
  INDEX idx_marketplace_items_user (user_id),
  INDEX idx_marketplace_items_type (item_type),
  INDEX idx_marketplace_items_status (status),
  INDEX idx_marketplace_items_category (category),
  INDEX idx_marketplace_items_boosted (is_boosted),
  CONSTRAINT fk_marketplace_items_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS marketplace_reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  item_id INT NOT NULL,
  reviewer_user_id INT NOT NULL,
  rating TINYINT,
  comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_marketplace_reviews_item (item_id),
  INDEX idx_marketplace_reviews_reviewer (reviewer_user_id),
  INDEX idx_marketplace_reviews_rating (rating),
  CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
  CONSTRAINT fk_marketplace_reviews_item FOREIGN KEY (item_id) REFERENCES marketplace_items(id) ON DELETE CASCADE,
  CONSTRAINT fk_marketplace_reviews_reviewer FOREIGN KEY (reviewer_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- DATING
-- ============================================================

CREATE TABLE IF NOT EXISTS dating_profiles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  gender ENUM('male','female','other'),
  looking_for ENUM('male','female','everyone'),
  age INT,
  city VARCHAR(255),
  country VARCHAR(255),
  bio TEXT,
  interests JSON NULL,
  photo_url VARCHAR(500),
  is_visible TINYINT DEFAULT 1,
  is_photo_verified TINYINT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_dating_profiles_user (user_id),
  INDEX idx_dating_profiles_gender (gender),
  INDEX idx_dating_profiles_looking (looking_for),
  INDEX idx_dating_profiles_visible (is_visible),
  INDEX idx_dating_profiles_city (city),
  CONSTRAINT fk_dating_profiles_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dating_blocks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  blocker_id INT NOT NULL,
  blocked_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dating_blocks (blocker_id, blocked_id),
  INDEX idx_dating_blocks_blocked (blocked_id),
  CONSTRAINT fk_dating_blocks_blocker FOREIGN KEY (blocker_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_dating_blocks_blocked FOREIGN KEY (blocked_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dating_verification_uploads (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  selfie_url VARCHAR(500),
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  reviewed_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_dating_verification_user (user_id),
  INDEX idx_dating_verification_status (status),
  CONSTRAINT fk_dating_verification_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TEAM
-- ============================================================

CREATE TABLE IF NOT EXISTS team_invitations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  owner_id INT NOT NULL,
  email VARCHAR(255),
  role ENUM('admin','editor','viewer') DEFAULT 'viewer',
  invite_token VARCHAR(100),
  status ENUM('pending','accepted','expired') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_team_invitations_token (invite_token),
  INDEX idx_team_invitations_owner (owner_id),
  INDEX idx_team_invitations_email (email),
  INDEX idx_team_invitations_status (status),
  CONSTRAINT fk_team_invitations_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- ADVANCED FEATURES
-- ============================================================

CREATE TABLE IF NOT EXISTS policy_rules (
  id INT AUTO_INCREMENT PRIMARY KEY,
  platform VARCHAR(50),
  rule_type ENUM('text','image','url'),
  pattern VARCHAR(500),
  severity ENUM('low','medium','high','critical'),
  description TEXT,
  is_active TINYINT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_policy_rules_platform (platform),
  INDEX idx_policy_rules_type (rule_type),
  INDEX idx_policy_rules_severity (severity),
  INDEX idx_policy_rules_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS policy_scan_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  campaign_id INT NULL,
  post_id INT NULL,
  compliance_score INT,
  issues_json JSON,
  scanned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_policy_scan_user (user_id),
  INDEX idx_policy_scan_campaign (campaign_id),
  INDEX idx_policy_scan_post (post_id),
  INDEX idx_policy_scan_score (compliance_score),
  CONSTRAINT fk_policy_scan_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_policy_scan_campaign FOREIGN KEY (campaign_id) REFERENCES ad_campaigns(id) ON DELETE SET NULL,
  CONSTRAINT fk_policy_scan_post FOREIGN KEY (post_id) REFERENCES scheduled_posts(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS campaign_run_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  campaign_id INT NOT NULL,
  action VARCHAR(100),
  details TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_campaign_run_logs_campaign (campaign_id),
  INDEX idx_campaign_run_logs_created (created_at),
  CONSTRAINT fk_campaign_run_logs_campaign FOREIGN KEY (campaign_id) REFERENCES ad_campaigns(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS referrals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  referrer_id INT NOT NULL,
  referred_id INT NOT NULL,
  status ENUM('pending','rewarded') DEFAULT 'pending',
  reward_credits DECIMAL(10,2) DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_referrals_referrer (referrer_id),
  INDEX idx_referrals_referred (referred_id),
  INDEX idx_referrals_status (status),
  CONSTRAINT fk_referrals_referrer FOREIGN KEY (referrer_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_referrals_referred FOREIGN KEY (referred_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS agency_client_branding (
  id INT AUTO_INCREMENT PRIMARY KEY,
  agency_user_id INT NOT NULL,
  client_user_id INT NOT NULL,
  logo_url VARCHAR(500) NULL,
  accent_color VARCHAR(7) DEFAULT '#00FF00',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_agency_branding_agency (agency_user_id),
  INDEX idx_agency_branding_client (client_user_id),
  CONSTRAINT fk_agency_branding_agency FOREIGN KEY (agency_user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_agency_branding_client FOREIGN KEY (client_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type VARCHAR(100),
  title VARCHAR(255),
  body TEXT,
  link VARCHAR(500) NULL,
  is_read TINYINT DEFAULT 0,
  read_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_notifications_user (user_id),
  INDEX idx_notifications_read (is_read),
  INDEX idx_notifications_type (type),
  INDEX idx_notifications_created (created_at),
  CONSTRAINT fk_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS achievements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  achievement_key VARCHAR(100) NOT NULL,
  title VARCHAR(255),
  description TEXT,
  icon VARCHAR(100),
  UNIQUE KEY uq_achievements_key (achievement_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_achievements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  achievement_id INT NOT NULL,
  earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_achievements_user (user_id),
  INDEX idx_user_achievements_achievement (achievement_id),
  CONSTRAINT fk_user_achievements_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_user_achievements_achievement FOREIGN KEY (achievement_id) REFERENCES achievements(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS api_keys (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  key_hash VARCHAR(255),
  key_prefix VARCHAR(10),
  scopes JSON,
  last_used_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_api_keys_user (user_id),
  INDEX idx_api_keys_hash (key_hash),
  CONSTRAINT fk_api_keys_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS webhooks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  event_type VARCHAR(100),
  target_url VARCHAR(500),
  secret VARCHAR(255),
  is_active TINYINT DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_webhooks_user (user_id),
  INDEX idx_webhooks_event (event_type),
  INDEX idx_webhooks_active (is_active),
  CONSTRAINT fk_webhooks_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS invoices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  transaction_id INT NOT NULL,
  invoice_number VARCHAR(50),
  file_path VARCHAR(500),
  generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_invoices_txn (transaction_id),
  CONSTRAINT fk_invoices_txn FOREIGN KEY (transaction_id) REFERENCES transactions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS email_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  recipient VARCHAR(255),
  subject VARCHAR(500),
  type VARCHAR(100),
  status VARCHAR(50),
  sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email_logs_recipient (recipient),
  INDEX idx_email_logs_type (type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS email_campaigns (
  id INT AUTO_INCREMENT PRIMARY KEY,
  admin_id INT NOT NULL,
  subject VARCHAR(500),
  body TEXT,
  status ENUM('draft','sending','sent') DEFAULT 'draft',
  sent_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email_campaigns_admin (admin_id),
  INDEX idx_email_campaigns_status (status),
  CONSTRAINT fk_email_campaigns_admin FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS email_campaign_recipients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  campaign_id INT NOT NULL,
  user_id INT NOT NULL,
  opened TINYINT DEFAULT 0,
  clicked TINYINT DEFAULT 0,
  sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_email_recipients_campaign (campaign_id),
  INDEX idx_email_recipients_user (user_id),
  CONSTRAINT fk_email_recipients_campaign FOREIGN KEY (campaign_id) REFERENCES email_campaigns(id) ON DELETE CASCADE,
  CONSTRAINT fk_email_recipients_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cron_run_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  job_name VARCHAR(255),
  started_at DATETIME,
  finished_at DATETIME NULL,
  status ENUM('running','success','failed') DEFAULT 'running',
  notes TEXT NULL,
  INDEX idx_cron_logs_job (job_name),
  INDEX idx_cron_logs_status (status),
  INDEX idx_cron_logs_started (started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fraud_flags (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  flag_type VARCHAR(100),
  description TEXT,
  severity ENUM('low','medium','high'),
  status ENUM('flagged','reviewed','dismissed') DEFAULT 'flagged',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME NULL,
  INDEX idx_fraud_flags_user (user_id),
  INDEX idx_fraud_flags_type (flag_type),
  INDEX idx_fraud_flags_severity (severity),
  INDEX idx_fraud_flags_status (status),
  CONSTRAINT fk_fraud_flags_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS translations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  locale VARCHAR(10) NOT NULL,
  translation_key VARCHAR(255) NOT NULL,
  value TEXT,
  UNIQUE KEY uq_translations (locale, translation_key),
  INDEX idx_translations_locale (locale)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEED DATA: site_settings
-- ============================================================

INSERT INTO site_settings (setting_key, setting_value, setting_group) VALUES
  ('site_name',               'Adsbooster.net',          'general'),
  ('site_slogan',             'Multi-Network AI Advertising Platform', 'general'),
  ('site_email',              'support@adsbooster.net',   'general'),
  ('site_phone',              '+1 (555) 123-4567',        'general'),
  ('site_address',            'New York, NY 10002, United States', 'general'),
  ('currency_symbol',         '$',                        'general'),
  ('site_logo',               '/assets/images/logo/logo-green.png',  'general'),
  ('site_favicon',            '/assets/images/logo/favicon.png',   'general'),
  ('paystack_test_key',       'sk_test_XXXXXXXXXXXXXXXXXXXXXXX',   'payment'),
  ('paystack_live_key',       'sk_live_XXXXXXXXXXXXXXXXXXXXXXX',   'payment'),
  ('flutterwave_test_key',    'FLWSECK_TEST-XXXXXXXXXXXXXXXXXXXX', 'payment'),
  ('flutterwave_live_key',    'FLWSECK_LIVE-XXXXXXXXXXXXXXXXXXXX', 'payment'),
  ('google_client_id',        'YOUR_GOOGLE_CLIENT_ID',    'integrations'),
  ('google_client_secret',    'YOUR_GOOGLE_CLIENT_SECRET','integrations'),
  ('consent_mode_default',    'denied',                   'privacy'),
  ('auto_refill_reward_credits', '10',                    'referrals'),
  ('referral_reward_amount',  '50',                       'referrals'),
  ('policy_compliance_threshold', '70',                   'policies'),
  ('groq_api_key',            '',                         'ai_providers'),
  ('groq_model',              'llama-3.3-70b-versatile', 'ai_providers'),
  ('gemini_api_key',          '',                         'ai_providers'),
  ('gemini_model',            'gemini-2.0-flash-exp',    'ai_providers'),
  ('openrouter_api_key',      '',                         'ai_providers'),
  ('openrouter_model',        'meta-llama/llama-3.3-70b-versatile:free', 'ai_providers'),
  ('firecrawl_api_key',       '',                         'ai_providers'),
  ('ai_credits_per_dollar',   '10',                       'ai_providers'),
  ('meta_description',        'Multi-network advertising platform with AI-powered creatives', 'seo'),
  ('meta_keywords',           'adsbooster, advertising, AI, social media, marketing', 'seo');

-- ============================================================
-- SEED DATA: achievements
-- ============================================================

INSERT INTO achievements (achievement_key, title, description, icon) VALUES
  ('first_campaign',        'First Campaign',        'Created your first ad campaign',            'campaign'),
  ('first_combo_pack',      'Combo Pack Pioneer',    'Launched your first combo pack campaign',   'combo'),
  ('ten_posts_scheduled',   'Content Machine',       'Scheduled 10 posts across platforms',       'calendar'),
  ('first_referral_reward', 'Social Butterfly',       'Earned your first referral reward',         'referral'),
  ('verified_seller',       'Trusted Seller',        'Became a verified seller on the marketplace','badge'),
  ('policy_scan_streak',    'Compliance Champion',   'Maintained a perfect policy scan streak',   'shield');

-- ============================================================
-- SEED DATA: default admin user
-- Password: admin123  (bcrypt hash)
-- ============================================================

INSERT INTO users (full_name, email, password, role, status, created_at)
VALUES (
  'Admin User',
  'admin@adsbooster.net',
  '$2y$12$irEt/SvnQZ0W/omxTowevOXehKEWMNucp6PLa0O6MY9H0krgg/cPC',
  'admin',
  'active',
  NOW()
);

-- ============================================================
-- WALLETS (used by PaymentProcessor)
-- ============================================================

CREATE TABLE IF NOT EXISTS wallets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  currency VARCHAR(3) DEFAULT 'USD',
  balance DECIMAL(12,2) DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_wallets_user_currency (user_id, currency),
  INDEX idx_wallets_user (user_id),
  CONSTRAINT fk_wallets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS wallet_transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  type ENUM('credit','debit') DEFAULT 'credit',
  amount DECIMAL(12,2),
  currency VARCHAR(3) DEFAULT 'USD',
  reference VARCHAR(255),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_wallet_tx_user (user_id),
  INDEX idx_wallet_tx_reference (reference),
  CONSTRAINT fk_wallet_tx_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEED DATA: blog posts
-- ============================================================

INSERT INTO blog_posts (title, slug, excerpt, body, author_id, published_at, status) VALUES
  ('How to Launch Your First Multi-Platform Ad Campaign', 'launch-first-multi-platform-campaign',
   'Learn how to create and launch ads across Meta, Instagram, TikTok, and more from a single dashboard.',
   '<p>Running ads across multiple platforms used to require separate tools and endless configuration. With Adsbooster, you can launch campaigns on Meta, Instagram, TikTok, Google Ads, and Snapchat from one unified dashboard.</p><p>In this guide, we walk you through connecting your accounts, setting targeting parameters, and launching your first combo pack campaign.</p>',
   1, NOW(), 'published'),
  ('AI-Powered Ad Creatives: The Future of Marketing', 'ai-powered-ad-creatives',
   'Discover how AI is transforming ad creative generation and how you can leverage it for better ROI.',
   '<p>Artificial Intelligence is revolutionizing the way businesses create marketing content. From generating compelling headlines to producing eye-catching visuals, AI tools are making it faster and cheaper to produce high-quality ad creatives.</p><p>At Adsbooster, we integrate with Groq, Gemini, and OpenRouter to give you access to cutting-edge AI models for text, image, and video generation.</p>',
   1, NOW(), 'published'),
  ('Maximizing ROI with A/B Testing in Your Ad Campaigns', 'maximizing-roi-ab-testing',
   'A comprehensive guide to setting up and analyzing A/B tests for your advertising campaigns.',
   '<p>A/B testing is one of the most powerful tools in a marketer''s toolkit. By testing different variations of your ad creative, headline, or targeting, you can identify what works best and optimize your spend.</p><p>This guide covers how to set up split tests in Adsbooster, interpret results, and apply learnings to scale your campaigns.</p>',
   1, NOW(), 'published'),
  ('Social Media Scheduling: Best Practices for 2026', 'social-media-scheduling-2026',
   'Stay ahead of the curve with these social media scheduling strategies and tools.',
   '<p>Social media scheduling has evolved significantly. With AI-powered content suggestions and cross-platform publishing, you can maintain a consistent presence without spending hours manually posting.</p><p>Learn how to use Adsbooster''s Post Creator to schedule content across all your connected platforms with optimal timing.</p>',
   1, NOW(), 'published'),
  ('The Complete Guide to Google Business Profile Optimization', 'google-business-profile-optimization',
   'Optimize your Google Business Profile to attract more local customers and improve your online visibility.',
   '<p>Your Google Business Profile is often the first impression potential customers have of your business. Optimizing it with accurate information, compelling photos, and regular updates can significantly impact your local search rankings.</p><p>Connect your Google Business account to Adsbooster to manage posts and updates alongside your other social channels.</p>',
   1, NOW(), 'published'),
  ('Referral Programs That Work: Growing Your Business organically', 'referral-programs-that-work',
   'How to build and scale a referral program that drives organic growth for your advertising platform.',
   '<p>Word-of-mouth marketing remains one of the most effective channels. A well-designed referral program can turn your satisfied users into brand ambassadors, driving new sign-ups at a fraction of the cost of paid acquisition.</p><p>Discover how Adsbooster''s built-in referral system rewards both referrers and new users with bonus credits.</p>',
   1, NOW(), 'published');

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- MIGRATION: Add 'document'/'pdf' to scheduled_posts.media_type
-- ============================================================
ALTER TABLE scheduled_posts MODIFY COLUMN media_type ENUM('image','ugc_video','reel','text_only','document','pdf') DEFAULT NULL;

-- ============================================================
-- SEED DATA: AI provider settings
-- ============================================================
INSERT IGNORE INTO site_settings (setting_key, setting_value) VALUES
  ('ai_provider_text', 'groq'),
  ('ai_provider_image', 'gemini'),
  ('ai_provider_video', 'openrouter'),
  ('groq_api_key', ''),
  ('gemini_api_key', ''),
  ('openrouter_api_key', ''),
  ('firecrawl_api_key', ''),
  ('site_slogan', 'Multi-Network AI Advertising Platform');
