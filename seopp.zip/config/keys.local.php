<?php
declare(strict_types=1);

/**
 * LOCAL DEVELOPMENT CREDENTIALS — NOT FOR PRODUCTION.
 *
 * This file is excluded from version control (see .gitignore) and is blocked
 * from being served over HTTP (see .htaccess). It is loaded by
 * `config/apikeys.php` and only fills constants that are still empty.
 *
 * In production, delete this file and supply the same values as environment
 * variables, or set them in the `site_settings` table from Admin → Settings.
 */

return [
    // ── AI ──
    // Dev-only values. Rotate them before deploying anywhere public, then
    // switch to environment variables (preferred) or site_settings rows.
    'GROQ_API_KEY'       => getenv('GROQ_API_KEY') ?: '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',
    'GEMINI_API_KEY'     => getenv('GEMINI_API_KEY') ?: '',
    'OPENROUTER_API_KEY' => getenv('OPENROUTER_API_KEY') ?: '',

    // ── AI video renderers (optional — Storyboard Studio works without any) ──
    'REPLICATE_API_TOKEN' => getenv('REPLICATE_API_TOKEN') ?: '',
    'FAL_KEY'             => getenv('FAL_KEY') ?: '',
    'RUNWAY_API_KEY'      => getenv('RUNWAY_API_KEY') ?: '',
    'LUMA_API_KEY'        => getenv('LUMA_API_KEY') ?: '',

    // ── Payments ──
    'PAYSTACK_PUBLIC_KEY' => getenv('PAYSTACK_PUBLIC_KEY') ?: '',
    'PAYSTACK_SECRET_KEY' => getenv('PAYSTACK_SECRET_KEY') ?: '',
    'FLUTTERWAVE_PUBLIC_KEY' => getenv('FLUTTERWAVE_PUBLIC_KEY') ?: '',
    'FLUTTERWAVE_SECRET_KEY' => getenv('FLUTTERWAVE_SECRET_KEY') ?: '',

    // ── Email ──
    'SMTP_HOST'  => getenv('SMTP_HOST') ?: '',
    'SMTP_SECURE' => getenv('SMTP_SECURE') ?: 'tls',
    'SMTP_PORT'  => getenv('SMTP_PORT') ?: '587',
    'SMTP_USER'  => getenv('SMTP_USER') ?: '',
    'SMTP_PASS'  => getenv('SMTP_PASS') ?: '',
    'FROM_EMAIL' => getenv('FROM_EMAIL') ?: '',
];
